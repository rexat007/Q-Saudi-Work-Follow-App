import {tripEntryTarget,newProjectEntryTarget} from './utils/tripEntryPresentation';
import {ProfileContinuity} from './components/auth/ProfileContinuity';
import {readWorkspaceContinuation} from './runtime/workspaceProvisioningResume';
import {AdaptiveOperationalReports} from './components/reports/AdaptiveOperationalReports';
import {useUserActiveWorkspaceSync} from './hooks/useUserActiveWorkspaceSync';
import { batch4RelationText, batch4ReferenceText } from './i18n/batch4Presentation';
import React, { useState, useEffect, useRef } from 'react';
import { 
  Building2, 
  Truck, 
  Calculator, 
  Layers, 
  UserCheck, 
  Navigation, 
  Clock, 
  AlertTriangle, 
  AlertOctagon,
  FileText, 
  RefreshCw, 
  Database, 
  ShieldCheck, 
  WifiOff, 
  Code, 
  CheckCircle2, 
  ChevronLeft, 
  ChevronRight,
  ExternalLink,
  BookOpen,
  Boxes,
  Share2,
  Lock,
  ShieldAlert,
  FileSpreadsheet,
  LayoutDashboard,
  Scale,
  Sparkles,
  Menu,
  Sliders,
  ChevronDown,
  Loader2
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { ENTITY_RELATIONS, MANDATORY_PRINCIPLES, EntityRelationInfo } from './entityRelations';
import { ARCHITECTURE_DOCS, DocItem } from './docsData';
import FirestoreArchitectureView from './components/FirestoreArchitectureView';
import { ProjectSetupWizard } from './components/wizard/ProjectSetupWizard';
import { Sidebar } from './components/navigation/Sidebar';
import { PricingEngineView } from './components/pricing/PricingEngineView';
import { FieldOperationsView, FieldTab } from './components/field/FieldOperationsView';
import { ReportsEngineView } from './components/reports/ReportsEngineView';
import { OperationsDashboardView } from './components/dashboard/OperationsDashboardView';
import { AdminConsoleView } from './components/admin/AdminConsoleView';
import { LegacyMigrationView } from './components/migration/LegacyMigrationView';
import { SecurityAuditView } from './components/security/SecurityAuditView';
import { AuthButton } from './components/auth/AuthButton';
import { PWAInstallButton } from './components/offline/PWAInstallButton';
import { OfflineIndicator } from './components/offline/OfflineIndicator';
import { OutboxDrawer } from './components/offline/OutboxDrawer';
import { SystemToolsDrawer } from './components/navigation/SystemToolsDrawer';
import { MobileNavDrawer } from './components/navigation/MobileNavDrawer';
import { UnauthorizedBanner } from './components/navigation/UnauthorizedBanner';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import { outboxService } from './services/offline/outbox.service';
import { conflictResolutionService } from './services/offline/conflictResolution.service';
import { Wifi, Inbox } from 'lucide-react';
import { useI18n } from './i18n';
import { LanguageSwitcher } from './components/i18n/LanguageSwitcher';
import { 
  NavTabId, 
  navigationService, 
  SYSTEM_ROLES, 
  ROLE_PROFILES 
} from './services/navigation.service';
import { UserRole, AuthUserContext } from './types/common';
import { useAuth } from './firebase/authContext';
import { AccountStatusGate } from './components/auth/AccountStatusGate';
import { projectRepository } from './repositories/project.repository';
import { ProjectEntity } from './types/entities';

export default function App() {
  const { direction, t } = useI18n();
  const isRtl = direction === 'rtl';
  const { user, userProfile, isAuthReady, isProfileLoading, refreshUserProfile, profileAuthority } = useAuth();

  // Determine authoritative role from server profile when signed in
  const effectiveRole: UserRole = userProfile 
    ? (userProfile.role || 'VIEWER') 
    : 'VIEWER';

  // Role and Navigation state (currentRole acts as visual preview selector when unauthenticated or testing UI layout)
  const [currentRole, setCurrentRole] = useState<UserRole>('VIEWER');
  const [activeTab, setActiveTab] = useState<NavTabId>('WIZARD');
  const [isSystemToolsOpen, setIsSystemToolsOpen] = useState<boolean>(false);
  const [isMobileNavOpen, setIsMobileNavOpen] = useState<boolean>(false);

  const [projects, setProjects] = useState<ProjectEntity[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string>('');
  const [setupEntry, setSetupEntry] = useState<{projectId:string;actorId:string;layer:'ROSTER'}>();
  const [loadingProjects, setLoadingProjects] = useState<boolean>(true);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false);

  // Sync role when userProfile is loaded
  useEffect(() => {
    if (userProfile) {
      const realRole = userProfile.role || 'VIEWER';
      setCurrentRole(realRole);
    }
  }, [userProfile]);

  // Server-authoritative Auth Context: strictly derived from real authenticated session
  const activeAuthContext: AuthUserContext | undefined = user
    ? {
        userId: user.uid,
        displayName: userProfile?.fullName || user.displayName || user.email || t('auth.fallback.system_user'),
        email: user.email || '',
        role: effectiveRole,
        assignedProjectIds: userProfile?.assignedProjectIds || [],
        linkedDriverId: userProfile?.linkedDriverId,
      }
    : undefined;

  const profileUnavailable=Boolean(user && profileAuthority && profileAuthority!=='AVAILABLE' && profileAuthority!=='ABSENT_CONFIRMED');
  useUserActiveWorkspaceSync(profileUnavailable||userProfile?.status!=='ACTIVE'?undefined:activeAuthContext);
  const operationalProject=projects.find(project=>project.projectId===selectedProjectId);

  const assignedProjectScopeKey = JSON.stringify([...new Set(userProfile?.assignedProjectIds || [])].sort());

  const inventoryScope = JSON.stringify([user?.uid, effectiveRole, assignedProjectScopeKey, profileAuthority, userProfile?.status]);
  // A navigation request cannot survive a principal/authorization change while the Wizard is unmounted.
  useEffect(() => { setSetupEntry(undefined); }, [inventoryScope]);
  const inventoryScopeRef = useRef(inventoryScope);
  inventoryScopeRef.current = inventoryScope;
  const inventoryGeneration = useRef(0);
  const publishCanonicalProject = (project: ProjectEntity) => {
    if (inventoryScopeRef.current !== inventoryScope || profileUnavailable || !user || userProfile?.status !== 'ACTIVE') return;
    if (effectiveRole !== 'SUPER_ADMIN' && !userProfile?.assignedProjectIds?.includes(project.projectId)) return;
    inventoryGeneration.current++;
    setProjects(previous => {
      const existing = previous.find(value => value.projectId === project.projectId);
      if (existing && (existing.version ?? 0) > (project.version ?? 0)) return previous;
      return existing ? previous.map(value => value.projectId === project.projectId ? project : value) : [...previous, project];
    });
    setLoadingProjects(false);
  };

  // One-shot project fetch (Inventory cards only require eventual consistency)
  useEffect(() => {
    if (!user || profileAuthority !== 'AVAILABLE' || userProfile?.status !== 'ACTIVE') {
      inventoryGeneration.current++;
      setProjects([]);
      setLoadingProjects(false);
      return;
    }
    const assignedProjectIds: string[] = JSON.parse(assignedProjectScopeKey);
    const isSuperAdmin = effectiveRole === 'SUPER_ADMIN';
    setProjects(previous => previous.filter(project => isSuperAdmin || assignedProjectIds.includes(project.projectId)));
    setLoadingProjects(true);
    
    let active = true;
    const generation = ++inventoryGeneration.current;
    void projectRepository.listAll(assignedProjectIds, isSuperAdmin)
      .then(list => {
        if (active && generation === inventoryGeneration.current && inventoryScopeRef.current === inventoryScope) {
          setProjects(list || []);
          setLoadingProjects(false);
        }
      })
      .catch(err => {
        console.error('Error in project list:', err);
        if (active) setLoadingProjects(false);
      });

    return () => { active = false; };
  }, [inventoryScope]);

  // Synchronize and reconcile selectedProjectId without restarting project subscription
  useEffect(() => {
    if (projects && projects.length > 0) {
      setSelectedProjectId((prev) => {
        // Guard: If we are intentionally on the WIZARD tab creating a new project, keep selectedProjectId empty
        if (activeTab === 'WIZARD' && prev === '') {
          return '';
        }
        const stillExists = projects.some(p => p.projectId === prev);
        return stillExists ? prev : projects[0].projectId;
      });
    } else {
      setSelectedProjectId('');
    }
  }, [projects, activeTab]);

  const resumedWorkspaceNavigation=useRef<string|null>(null);
  // Resume navigation only after the current server-scoped Project inventory authorizes it.
  useEffect(()=>{if(!user?.uid||loadingProjects)return;const saved=readWorkspaceContinuation(user.uid);if(saved&&resumedWorkspaceNavigation.current!==`${saved.actorId}:${saved.createdAt}`&&projects.some(p=>p.projectId===saved.projectId)){resumedWorkspaceNavigation.current=`${saved.actorId}:${saved.createdAt}`;setSelectedProjectId(saved.projectId);setActiveTab('WIZARD');}},[user?.uid,loadingProjects,projects]);

  // Runtime referenced navigation labels to ensure 100% translation coverage
  const _navigationLabels = [
    t('navigation.labels.projects'),
    t('navigation.labels.txt_3fe43d'),
    t('navigation.labels.txt_9a0a23'),
    t('navigation.labels.txt_230d9e'),
    t('navigation.labels.txt_601c17'),
    t('navigation.labels.txt_152452'),
    t('navigation.labels.txt_6c2131'),
    t('navigation.labels.txt_61c13d'),
    t('navigation.labels.txt_b4b841'),
    t('navigation.labels.reports'),
    t('navigation.labels.txt_185076'),
    t('navigation.labels.trips'),
    t('navigation.labels.txt_45b282'),
    t('navigation.labels.txt_7265aa'),
    t('navigation.labels.import'),
    t('navigation.labels.txt_3711ef'),
    t('navigation.labels.txt_1a75fa'),
    t('navigation.labels.txt_2439c4'),
    t('navigation.labels.txt_70f585'),
    t('navigation.labels.txt_50c969'),
    t('navigation.labels.pricing'),
    t('navigation.labels.projects_2'),
    t('navigation.labels.txt_11ed5e'),
    t('navigation.labels.txt_1b8b59'),
    t('navigation.labels.txt_198d0f'),
    t('navigation.labels.txt_4452c7'),
    t('navigation.labels.txt_13cd84'),
    t('navigation.labels.txt_276201'),
  ];

  // Entities & Docs state for Secondary Tools
  const [selectedEntityId, setSelectedEntityId] = useState<string>('Trip');
  const [selectedDocId, setSelectedDocId] = useState<string>('architecture');
  const [docsSubTab, setDocsSubTab] = useState<'SPECS' | 'FIRESTORE' | 'RELATIONS' | 'PRINCIPLES'>('SPECS');

  // Offline-first PWA and Outbox states
  const [isOutboxOpen, setIsOutboxOpen] = useState<boolean>(false);
  const { isOnline } = useOnlineStatus();
  const [pendingCount, setPendingCount] = useState<number>(0);
  const [conflictCount, setConflictCount] = useState<number>(0);

  // Polling for offline queue and conflicts
  useEffect(() => {
    const updateCount = async () => {
      try {
        const [ops, confs] = await Promise.all([
          outboxService.getOperations(),
          conflictResolutionService.getConflicts(),
        ]);
        const pending = ops.filter(o => o.status === 'PENDING' || o.status === 'FAILED' || o.status === 'SENDING' || o.status === 'AWAITING_RECEIPT').length;
        const openConflicts = confs.filter(c => c.status === 'OPEN').length;
        setPendingCount(pending);
        setConflictCount(openConflicts);
      } catch (e) {
        // ignore
      }
    };
    updateCount();
    const interval = setInterval(updateCount, 2500); // Revert to baseline 2500ms for IndexedDB-only poll
    return () => clearInterval(interval);
  }, []);

  // Handle role change and route guard check
  const handleRoleChange = (newRole: UserRole) => {
    // Prevent role mutation for authenticated users
    if (user) return;
    setCurrentRole(newRole);
    if (!navigationService.isTabAuthorizedForRole(activeTab, newRole)) {
      const defaultTab = navigationService.getDefaultTabForRole(newRole);
      setActiveTab(defaultTab);
    }
  };

  const presentationRole: UserRole = user ? effectiveRole : currentRole;
  const roleProfile = navigationService.getRoleProfile(presentationRole);
  const authorizedPrimaryTabs = navigationService.getAuthorizedPrimaryTabs(presentationRole);
  const authorizedTools = navigationService.getAuthorizedSystemTools(presentationRole);
  const isCurrentTabAuthorized = navigationService.isTabAuthorizedForRole(activeTab, presentationRole);

  const selectedEntity = ENTITY_RELATIONS.find(e => e.id === selectedEntityId) || ENTITY_RELATIONS[6]; // Trip by default
  const selectedDoc = ARCHITECTURE_DOCS.find(d => d.id === selectedDocId) || ARCHITECTURE_DOCS[0];

  const getEntityIcon = (id: string) => {
    switch (id) {
      case 'Project': return <Building2 className="w-5 h-5 text-indigo-600" />;
      case 'Carrier': return <Building2 className="w-5 h-5 text-amber-600" />;
      case 'Pricing Rule': return <Calculator className="w-5 h-5 text-emerald-600" />;
      case 'Material': return <Layers className="w-5 h-5 text-orange-600" />;
      case 'Truck': return <Truck className="w-5 h-5 text-cyan-600" />;
      case 'Driver': return <UserCheck className="w-5 h-5 text-blue-600" />;
      case 'Trip': return <Navigation className="w-5 h-5 text-red-600" />;
      case 'Trip Event': return <Clock className="w-5 h-5 text-violet-600" />;
      case 'Exception': return <AlertTriangle className="w-5 h-5 text-rose-600" />;
      case 'Audit Log': return <FileText className="w-5 h-5 text-slate-700" />;
      case 'Sync Operation': return <RefreshCw className="w-5 h-5 text-teal-600" />;
      default: return <Boxes className="w-5 h-5 text-gray-600" />;
    }
  };

  const getDocIcon = (iconName: string) => {
    switch (iconName) {
      case 'Layers': return <Layers className="w-4 h-4 text-indigo-500" />;
      case 'Database': return <Database className="w-4 h-4 text-blue-500" />;
      case 'Code': return <Code className="w-4 h-4 text-emerald-500" />;
      case 'ShieldCheck': return <ShieldCheck className="w-4 h-4 text-amber-500" />;
      case 'WifiOff': return <WifiOff className="w-4 h-4 text-rose-500" />;
      case 'Calculator': return <Calculator className="w-4 h-4 text-teal-500" />;
      case 'CheckCircle2': return <CheckCircle2 className="w-4 h-4 text-purple-500" />;
      default: return <FileText className="w-4 h-4 text-gray-500" />;
    }
  };

  const getTabNavIcon = (iconName: string) => {
    switch (iconName) {
      case 'Scale': return <Scale className="w-4 h-4 text-amber-500" />;
      case 'Building2': return <Building2 className="w-4 h-4 text-indigo-500" />;
      case 'Boxes': return <Boxes className="w-4 h-4 text-amber-500" />;
      case 'LayoutDashboard': return <LayoutDashboard className="w-4 h-4 text-emerald-500" />;
      case 'FileText': return <FileText className="w-4 h-4 text-blue-500" />;
      default: return <Boxes className="w-4 h-4 text-stone-500" />;
    }
  };

  // Determine initial field tab for role
  const getFieldInitialTab = (role: UserRole): FieldTab => {
    switch (role) {
      case 'DRIVER': return 'DRIVER_VIEW';
      case 'SCALE_OPERATOR': return 'LOADING_STATION';
      case 'SITE_SUPERVISOR': return 'UNLOADING_STATION';
      case 'SUPERVISOR': return 'SUPERVISION';
      case 'DISPATCHER': return 'LOADING_STATION';
      default: return 'LOADING_STATION';
    }
  };

  // Separate authentication and account verification from main application shell
    if (!isAuthReady || (user && isProfileLoading && !userProfile)) {
    return (
      <div className="min-h-screen bg-[#0f1115] text-[#f8fafc] flex flex-col items-center justify-center p-4 font-sans" dir={direction}>
        <div className="bg-[#15181e] border border-white/10 rounded-2xl p-8 shadow-2xl flex flex-col items-center space-y-4 max-w-sm w-full text-center">
          <div className="w-12 h-12 rounded-xl bg-[#10b981]/10 border border-[#10b981]/30 flex items-center justify-center">
            <Loader2 className="w-6 h-6 text-[#10b981] animate-spin" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white mb-1">Q-Saudi Work Follow</h2>
            <p className="text-xs text-stone-400 font-mono">
              {t("authentication.labels.txt_49cb21")}
            </p>
          </div>
        </div>
      </div>
    );
  }

  if(!user&&profileAuthority==='UNAVAILABLE_TRANSIENT')return <ProfileContinuity blocked onRetry={refreshUserProfile}/>;

  if (!user) {
    return (
      <AccountStatusGate
        status="UNAUTHENTICATED"
        onRefresh={refreshUserProfile}
      />
    );
  }

  if(profileUnavailable && !userProfile) return <ProfileContinuity blocked onRetry={refreshUserProfile}/>;

  // Gate authenticated users if account status is not ACTIVE
  if (user && (!userProfile || userProfile.status !== 'ACTIVE')) {
    return (
      <AccountStatusGate
        status={userProfile?.status || (profileAuthority==='ABSENT_CONFIRMED'?'NO_PROFILE':'PROFILE_UNAVAILABLE')}
        userEmail={user.email || ''}
        userName={userProfile?.fullName || user.displayName || ''}
        onRefresh={refreshUserProfile}
      />
    );
  }

  return (
    <ProfileContinuity blocked={profileUnavailable} onRetry={refreshUserProfile}><div className="min-h-screen bg-[#0f1115] text-[#f8fafc] font-sans flex flex-col antialiased selection:bg-[#10b981] selection:text-[#0f1115]" dir={direction}>
      {/* Top Application Header */}
      <header className="bg-[#0f1115] border-b-2 border-white/10 sticky top-0 z-30 shadow-2xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            {/* Left: Brand & Mobile Menu Toggle */}
            <div className="flex items-center gap-3">
              {/* Mobile Menu Hamburger */}
              <button
                id="btn-mobile-nav-toggle"
                onClick={() => setIsMobileNavOpen(true)}
                className="lg:hidden p-2 rounded text-white/70 hover:text-white hover:bg-white/5 border border-white/10 min-w-[44px] min-h-[44px] flex items-center justify-center font-mono"
                title={t('navigation.mobile.main_menu')}
              >
                <Menu className="w-5 h-5 text-[#10b981]" />
              </button>

              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#10b981] text-[#0f1115] flex items-center justify-center font-black font-display text-xl shadow-md tracking-tighter">
                  Q
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h1 className="text-base sm:text-lg font-black font-display tracking-tight text-[#f8fafc] uppercase">
                      Q Saudi Work Follow
                    </h1>
                    <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#10b981]/15 text-[#10b981] border border-[#10b981]/30 uppercase tracking-widest">
                      INDUSTRIAL_CORE
                    </span>
                  </div>
                  <span className="label text-[10px] tracking-widest text-[#10b981] font-mono uppercase block">
                    {t('navigation.labels.enterprise_architecture')}
                  </span>
                </div>
              </div>
            </div>

            {/* Right: Telemetry Status, Role Switcher, Language, Outbox & Auth */}
            <div className="flex flex-wrap min-w-0 max-w-full items-center gap-2">
              {/* Telemetry Status Pill */}
              <div className="hidden md:flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#1a1d23] border border-white/10 text-[11px] font-mono">
                <span className="text-white/40">STATUS:</span>
                <span className="text-[#10b981] font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#10b981] animate-pulse"></span>
                  STABLE_AUTH
                </span>
              </div>

              {/* Active Role Selector / Simulator */}
              <div className={`relative flex min-w-0 max-w-full items-center bg-[#1a1d23] rounded px-1 py-0.5 border ${userProfile ? 'border-[#10b981]/30 opacity-75' : 'border-white/10'}`}>
                <div className="flex min-w-0 max-w-full items-center gap-1.5 px-2 py-1">
                  {userProfile ? (
                    <Lock className="w-3.5 h-3.5 text-[#10b981] shrink-0" />
                  ) : (
                    <UserCheck className="w-3.5 h-3.5 text-[#10b981] shrink-0" />
                  )}
                  <select
                    id="header-role-selector"
                    value={presentationRole}
                    onChange={(e) => handleRoleChange(e.target.value as UserRole)}
                    className="min-w-0 max-w-[220px] sm:max-w-[320px] bg-transparent text-[#f8fafc] font-bold font-mono text-xs focus:outline-hidden cursor-pointer disabled:cursor-not-allowed"
                    title={t('navigation.labels.switch_active_role')}
                    disabled={Boolean(user)}
                  >
                    {SYSTEM_ROLES.map((role) => (
                      <option key={role} value={role} className="bg-[#1a1d23] text-[#f8fafc] font-mono">
                        {role} ({t(`navigation.roles.${role.toLowerCase()}_label`)})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Language Switcher */}
              <LanguageSwitcher />

              {/* Outbox & Network Status Pill */}
              <button
                id="header-outbox-btn"
                onClick={() => setIsOutboxOpen(true)}
                className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs font-mono font-bold transition-all border ${
                  isOnline 
                    ? 'bg-[#1a1d23] hover:bg-white/5 border-[#10b981]/40 text-[#10b981]' 
                    : 'bg-[#1a1d23] hover:bg-white/5 border-amber-500 text-amber-400 animate-pulse'
                }`}
                title={t("navigation.status.txt_4c0b8d")}
              >
                {isOnline ? <Wifi className="w-3.5 h-3.5 text-[#10b981]" /> : <WifiOff className="w-3.5 h-3.5 text-amber-400" />}
                <Inbox className="w-3 h-3 text-white/50" />
                <span className={`px-1.5 py-0.2 rounded text-[10px] font-mono font-bold ${
                  pendingCount > 0 ? 'bg-[#10b981] text-[#0f1115]' : 'bg-white/10 text-[#f8fafc]'
                }`}>
                  {pendingCount}
                </span>
              </button>

              {/* Conflict Alert Pill */}
              {conflictCount > 0 && (
                <button
                  id="header-conflicts-btn"
                  onClick={() => setIsOutboxOpen(true)}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded text-xs font-mono font-bold bg-purple-950/60 hover:bg-purple-900/80 border border-purple-500/50 text-purple-300 shadow-sm animate-pulse transition-all"
                  title={t("navigation.labels.txt_10324c")}
                >
                  <ShieldAlert className="w-3.5 h-3.5 text-purple-400" />
                  <span>{conflictCount} {t('navigation.labels.conflicts_count')}</span>
                </button>
              )}

              {/* PWA Install Button */}
              <PWAInstallButton />

              {/* Firebase Authentication Button */}
              <AuthButton />
            </div>
          </div>
        </div>
      </header>

      <div className="flex-1 flex flex-col lg:flex-row min-h-0 w-full relative">
        {/* Primary Vertical Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          currentRole={presentationRole}
          onChangeRole={handleRoleChange}
          projects={projects}
          selectedProjectId={selectedProjectId}
          setSelectedProjectId={setSelectedProjectId}
          onOpenSystemTools={() => setIsSystemToolsOpen(true)}
          isCollapsed={isSidebarCollapsed}
          setIsCollapsed={setIsSidebarCollapsed}
        />

        {/* Content Wrapper */}
        <div className="flex-1 flex flex-col min-w-0 bg-[#0f1115]">
          {/* Sub-Header: Active Profile & Isolation Scope Ribbon */}
          <div className="bg-[#14171c] text-white/60 py-1.5 px-4 text-[11px] font-mono border-b border-white/10">
            <div className="w-full flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap min-w-0 max-w-full items-center gap-3">
                <span className="flex min-w-0 items-center gap-1 text-white/60">
                  <Lock className="w-3 h-3 text-[#10b981]" />
                  <span className="text-white/40">USER:</span>
                  <strong className="text-[#f8fafc] font-bold">{activeAuthContext?.displayName || t('auth.fallback.unregistered_user')}</strong>
                </span>
                <span className="text-white/20">•</span>
                <span className="text-white/60">
                  <span className="text-white/40">SCOPE:</span>{' '}
                  <strong className="text-[#10b981] font-mono font-bold">
                    {roleProfile.assignedProjectIds.join(', ')}
                  </strong>
                </span>
              </div>

              <div className="flex items-center gap-3 text-white/60">
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-[#10b981]" />
                  <span>SSOT // MULTI-TENANT ISOLATION</span>
                </span>
                <span className="hidden md:inline text-white/20">•</span>
                <span className="hidden md:inline text-white/50">SERVER-AUTHORITATIVE CORE</span>
              </div>
            </div>
          </div>

          {/* Main Content Area with Strict Route Guards & Industrial Dot Matrix */}
          <main className="flex-1 w-full px-4 sm:px-6 lg:px-8 py-6 industrial-dot-matrix overflow-y-auto">
            {/* Route Guard Enforcement: If activeTab is forbidden for currentRole */}
            {!isCurrentTabAuthorized ? (
              <UnauthorizedBanner
                requestedTab={activeTab}
                currentRole={presentationRole}
                onRedirectToDefault={() => {
                  const defTab = navigationService.getDefaultTabForRole(presentationRole);
                  setActiveTab(defTab);
                }}
              />
            ) : (
              <>
                {/* ================= TAB: OPERATIONS DASHBOARD (STRICT AUTHORIZATION, 7 LAYERS) ================= */}
                {activeTab === 'OPERATIONS_DASHBOARD' && (
                  operationalProject?.operationalConfiguration ? <AdaptiveOperationalReports key={selectedProjectId} projectId={selectedProjectId} configuration={operationalProject?.operationalConfiguration}/> : <OperationsDashboardView
                    authContext={activeAuthContext}
                    profileAvailable={!profileUnavailable && !isProfileLoading && userProfile?.status==='ACTIVE' && userProfile?.isActive!==false}
                    authorityKey={inventoryScope}
                  />
                )}

                {/* ================= TAB: REPORTS ENGINE (OPERATIONAL, WEIGHBRIDGE, SETTLEMENT, INGESTION) ================= */}
                {activeTab === 'REPORTS_ENGINE' && (
                  <ReportsEngineView operationalConfiguration={operationalProject?.operationalConfiguration} operationalProjectId={operationalProject?.operationalConfiguration?selectedProjectId:undefined} />
                )}

                {/* ================= TAB: FIELD OPERATIONS (LOADING, UNLOADING, SUPERVISION, DRIVER) ================= */}
                {activeTab === 'FIELD_OPERATIONS' && (
                  <FieldOperationsView 
                    initialTab={getFieldInitialTab(presentationRole)}
                    initialRole={presentationRole}
                    projects={projects}
                    selectedProjectId={selectedProjectId}
                    setSelectedProjectId={setSelectedProjectId}
                    onNavigateToWizard={newProjectEntryTarget(activeAuthContext)?() => {
                      const target=newProjectEntryTarget(activeAuthContext);
                      if(!target)return;
                      setSetupEntry(undefined);
                      setSelectedProjectId(target.projectId);
                      setActiveTab(target.tab);
                    }:undefined}
                    onManageFleet={projectId => {
                      const target = tripEntryTarget(activeAuthContext, projects.find(p=>p.projectId===projectId), 'FLEET');
                      if(!target) return;
                      setSelectedProjectId(target.projectId);
                      setSetupEntry({projectId:target.projectId,actorId:activeAuthContext!.userId,layer:'ROSTER'});
                      setActiveTab(target.tab);
                    }}
                    authContext={activeAuthContext}
                  />
                )}

                {/* ================= TAB: PROJECT SETUP WIZARD (7 STEPS) / UNIFIED WORKSPACE ================= */}
                {activeTab === 'WIZARD' && (
                  <ProjectSetupWizard 
                    projects={projects}
                    onProjectChanged={publishCanonicalProject}
                    entryIntent={setupEntry}
                    onEntryIntentConsumed={intent => setSetupEntry(current => current === intent ? undefined : current)}
                    onOpenProjectOperations={projectId => {
                      const target=tripEntryTarget(activeAuthContext,projects.find(p=>p.projectId===projectId),'OPERATIONS');
                      if(!target)return;
                      setSetupEntry(undefined);
                      setSelectedProjectId(target.projectId);
                      setActiveTab(target.tab);
                    }}
                    authContext={activeAuthContext!}
                    selectedProjectId={selectedProjectId}
                    onSelectProject={(projId) => setSelectedProjectId(projId || '')}
                  />
                )}

                {/* ================= TAB: SECURITY AUDIT & COMPLIANCE (16 DOMAINS & EXHAUSTIVE RBAC) ================= */}
                {activeTab === 'SECURITY_AUDIT' && (
                  <SecurityAuditView />
                )}

                {/* ================= TAB: LEGACY MIGRATION (20 COLS, PREVIEW-FIRST, MASTER MATCHING) ================= */}
                {activeTab === 'LEGACY_MIGRATION' && (
                  <LegacyMigrationView />
                )}

                {/* ================= TAB: ADMIN CONSOLE (11 SECTIONS & VERSIONED PRICING RULES) ================= */}
                {activeTab === 'ADMIN_CONSOLE' && (
                  <AdminConsoleView />
                )}

                {/* ================= TAB: PRICING ENGINE & AUTOMATED TESTS ================= */}
                {activeTab === 'PRICING_ENGINE' && (
                  <PricingEngineView />
                )}

                {/* ================= TAB: FIRESTORE ARCHITECTURE & DOMAIN LAYERS ================= */}
                {activeTab === 'FIRESTORE_ARCH' && (
                  <FirestoreArchitectureView />
                )}

                {/* ================= TAB: RELATIONSHIPS EXPLORER ================= */}
                {activeTab === 'RELATIONS' && (
                  <div className="space-y-6">
                    <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-4">
                        <div>
                          <h2 className="text-base font-bold text-stone-900 flex items-center gap-2">
                            <Boxes className="w-5 h-5 text-indigo-600" />
                            <span>{t("navigation.labels.txt_4df8c5")}</span>
                          </h2>
                          <p className="text-xs text-stone-500 mt-1">
                            {t("navigation.labels.txt_23bdd6")}
                          </p>
                        </div>
                        <div className="text-xs font-medium text-stone-400 bg-stone-50 px-3 py-1.5 rounded-lg border border-stone-200/60">
                          {t("navigation.labels.txt_46b695")}<strong className="text-stone-700">Multi-Project Logistics FSM</strong>
                        </div>
                      </div>

                      {/* Entity Pills Carousel/Grid */}
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 pt-2 border-t border-stone-100">
                        {ENTITY_RELATIONS.map(entity => {
                          const isSelected = entity.id === selectedEntityId;
                          return (
                            <button
                              key={entity.id}
                              id={`entity-btn-${entity.id}`}
                              onClick={() => setSelectedEntityId(entity.id)}
                              className={`flex items-center gap-2.5 p-2.5 rounded-xl text-right transition-all border ${
                                isSelected 
                                  ? 'bg-stone-900 text-white border-stone-900 shadow-xs' 
                                  : 'bg-stone-50/70 hover:bg-stone-100/80 text-stone-700 border-stone-200/70'
                              }`}
                            >
                              <div className={`p-1.5 rounded-lg shrink-0 ${isSelected ? 'bg-stone-800' : 'bg-white shadow-xs'}`}>
                                {getEntityIcon(entity.id)}
                              </div>
                              <div className="min-w-0">
                                <div className="text-xs font-bold truncate">{entity.nameEn}</div>
                                <div className={`text-[10px] truncate ${isSelected ? 'text-stone-300' : 'text-stone-500'}`}>
                                  {batch4RelationText(t, entity.id, 'nameAr', entity.nameAr).split(' ')[0]}
                                </div>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Selected Entity Deep-Dive Card */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                      {/* Left Column: Entity Definition & Rules */}
                      <div className="lg:col-span-1 bg-white rounded-2xl border border-stone-200 p-6 shadow-xs flex flex-col justify-between">
                        <div>
                          <div className="flex items-center justify-between border-b border-stone-100 pb-4 mb-4">
                            <div className="flex items-center gap-3">
                              <div className="p-2.5 bg-stone-100 rounded-xl">
                                {getEntityIcon(selectedEntity.id)}
                              </div>
                              <div>
                                <span className="text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 rounded bg-stone-100 text-stone-600">
                                  {selectedEntity.category}
                                </span>
                                <h3 className="text-lg font-bold text-stone-900 mt-1">
                                  {batch4RelationText(t, selectedEntity.id, 'nameAr', selectedEntity.nameAr)}
                                </h3>
                              </div>
                            </div>
                          </div>

                          <p className="text-xs leading-relaxed text-stone-600 mb-4 bg-stone-50 p-3 rounded-xl border border-stone-200/60">
                            {batch4RelationText(t, selectedEntity.id, 'shortDescAr', selectedEntity.shortDescAr)}
                          </p>

                          <div className="space-y-4">
                            <div>
                              <h4 className="text-xs font-bold text-stone-900 mb-1.5 flex items-center gap-1.5">
                                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                                <span>{t("navigation.labels.txt_777008")}</span>
                              </h4>
                              <p className="text-xs text-stone-600 leading-normal">
                                {batch4RelationText(t, selectedEntity.id, 'roleInSystemAr', selectedEntity.roleInSystemAr)}
                              </p>
                            </div>

                            <div>
                              <h4 className="text-xs font-bold text-stone-900 mb-1.5 flex items-center gap-1.5">
                                <Database className="w-3.5 h-3.5 text-blue-600" />
                                <span>{t("navigation.labels.txt_41e146")}</span>
                              </h4>
                              <div className="flex flex-wrap gap-1.5">
                                {selectedEntity.keyAttributes.map((attr, idx) => (
                                  <span key={idx} className="font-mono text-[11px] px-2 py-0.5 bg-stone-100 text-stone-700 rounded-md border border-stone-200/60">
                                    {attr}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="mt-6 pt-4 border-t border-stone-100">
                          <h4 className="text-xs font-bold text-stone-900 mb-2 flex items-center gap-1.5">
                            <Lock className="w-3.5 h-3.5 text-amber-600" />
                            <span>{t("navigation.labels.txt_4ada99")}</span>
                          </h4>
                          <ul className="space-y-1.5">
                            {selectedEntity.rulesEnforcedAr.map((rule, idx) => (
                              <li key={idx} className="text-xs text-stone-600 flex items-start gap-1.5">
                                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                                <span>{batch4RelationText(t, selectedEntity.id, 'rule:' + idx, rule)}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      {/* Right Column: Direct Domain Connections */}
                      <div className="lg:col-span-2 bg-white rounded-2xl border border-stone-200 p-6 shadow-xs">
                        <div className="flex items-center justify-between pb-4 mb-4 border-b border-stone-100">
                          <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
                            <Share2 className="w-4 h-4 text-indigo-600" />
                            <span>{t('relations.direct_connections', { count: selectedEntity.relationships.length })}</span>
                          </h3>
                          <span className="text-xs text-stone-400">
                            {t("navigation.labels.txt_5dc573")}
                          </span>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                          {selectedEntity.relationships.map((rel, idx) => {
                            const targetEntity = ENTITY_RELATIONS.find(e => e.id === rel.target);
                            return (
                              <div 
                                key={idx}
                                onClick={() => setSelectedEntityId(rel.target)}
                                className="group p-3.5 rounded-xl border border-stone-200/80 bg-stone-50/40 hover:bg-stone-50 hover:border-indigo-300 transition-all cursor-pointer flex flex-col justify-between"
                              >
                                <div>
                                  <div className="flex items-center justify-between mb-2">
                                    <div className="flex items-center gap-2">
                                      <div className="p-1 rounded bg-white border border-stone-200">
                                        {getEntityIcon(rel.target)}
                                      </div>
                                      <span className="text-xs font-bold text-stone-900 group-hover:text-indigo-600 transition-colors">
                                        {targetEntity ? batch4RelationText(t, targetEntity.id, 'nameAr', targetEntity.nameAr) : rel.target}
                                      </span>
                                    </div>
                                    <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-100">
                                      {rel.type}
                                    </span>
                                  </div>
                                  <p className="text-xs text-stone-600 leading-relaxed">
                                    {batch4RelationText(t, selectedEntity.id, 'relation:' + rel.target, rel.descAr)}
                                  </p>
                                </div>
                                <div className="mt-3 pt-2 border-t border-stone-200/40 flex items-center justify-end text-[10px] font-bold text-stone-400 group-hover:text-indigo-600 gap-1 transition-colors">
                                  <span>{t('relations.view_entity', { entity: rel.target })}</span>
                                  <ChevronLeft className="w-3 h-3" />
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        {/* Architecture Context Banner */}
                        <div className="mt-6 p-4 rounded-xl bg-stone-900 text-stone-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                          <div>
                            <div className="text-xs font-bold text-amber-400 mb-0.5">
                              {t("navigation.labels.txt_6dd618")}
                            </div>
                            <div className="text-xs text-stone-300">
                              {t("navigation.labels.txt_791f1b")}
                            </div>
                          </div>
                          <button
                            onClick={() => {
                              setActiveTab('DOCS');
                              setSelectedDocId('architecture');
                            }}
                            className="shrink-0 px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-medium border border-stone-700 flex items-center gap-1.5 transition-colors"
                          >
                            <span>{t("navigation.labels.view")}</span>
                            <ChevronLeft className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* ================= TAB: THE 12 INVARIANT PRINCIPLES ================= */}
                {activeTab === 'PRINCIPLES' && (
                  <div className="space-y-6">
                    <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-xs">
                      <div className="max-w-3xl">
                        <h2 className="text-lg font-bold text-stone-900 flex items-center gap-2">
                          <ShieldCheck className="w-5 h-5 text-emerald-600" />
                          <span>{t("navigation.labels.txt_4c8195")}</span>
                        </h2>
                        <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                          {t("navigation.labels.txt_17c5e1")}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {MANDATORY_PRINCIPLES.map(principle => (
                        <div 
                          key={principle.num}
                          className="bg-white rounded-xl border border-stone-200 p-5 shadow-xs flex flex-col justify-between hover:border-stone-300 transition-all"
                        >
                          <div>
                            <div className="flex items-center justify-between mb-3">
                              <span className="w-7 h-7 rounded-lg bg-stone-900 text-amber-400 font-mono text-xs font-bold flex items-center justify-center">
                                #{principle.num}
                              </span>
                              <span className="text-[10px] font-bold text-stone-400 bg-stone-100 px-2 py-0.5 rounded">
                                {t('batch4.presentation.invariant_rule')}
                              </span>
                            </div>
                            <h3 className="text-sm font-bold text-stone-900 mb-2">
                              {batch4RelationText(t, 'principle_' + principle.num, 'title', principle.title)}
                            </h3>
                            <p className="text-xs text-stone-600 leading-relaxed">
                              {batch4RelationText(t, 'principle_' + principle.num, 'desc', principle.desc)}
                            </p>
                          </div>
                          
                          <div className="mt-4 pt-3 border-t border-stone-100 flex items-center gap-1.5 text-[11px] font-medium text-emerald-700">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>{t("navigation.labels.txt_c37ba7")}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* ================= TAB: SPECIFICATION DOCUMENTS VIEWER ================= */}
                {activeTab === 'DOCS' && (
                  <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                    {/* Sidebar Documents List */}
                    <div className="lg:col-span-1 space-y-2">
                      <div className="bg-white rounded-xl border border-stone-200 p-3 shadow-xs">
                        <div className="text-xs font-bold text-stone-900 px-2 py-1 mb-1">
                          {t("navigation.labels.txt_8cf69f")}
                        </div>
                        <div className="space-y-1">
                          {ARCHITECTURE_DOCS.map(doc => {
                            const isSelected = doc.id === selectedDocId;
                            return (
                              <button
                                key={doc.id}
                                id={`doc-nav-${doc.id}`}
                                onClick={() => setSelectedDocId(doc.id)}
                                className={`w-full text-right px-3 py-2.5 rounded-lg text-xs font-medium transition-all flex items-center justify-between ${
                                  isSelected 
                                    ? 'bg-stone-900 text-white shadow-xs' 
                                    : 'text-stone-700 hover:bg-stone-100'
                                }`}
                              >
                                <div className="flex items-center gap-2 min-w-0">
                                  {getDocIcon(doc.iconName)}
                                  <span className="truncate">{batch4ReferenceText(t, doc.id, 'titleAr', doc.titleAr)}</span>
                                </div>
                                <span className={`font-mono text-[10px] shrink-0 ${isSelected ? 'text-stone-400' : 'text-stone-400'}`}>
                                  .md
                                </span>
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Document Summary Pill */}
                      <div className="bg-stone-50 rounded-xl border border-stone-200 p-4 text-xs text-stone-600">
                        <div className="font-bold text-stone-900 mb-1 flex items-center gap-1.5">
                          <FileText className="w-3.5 h-3.5 text-stone-500" />
                          <span>{t("navigation.labels.txt_72b405")}</span>
                        </div>
                        <p className="leading-relaxed">
                          {batch4ReferenceText(t, selectedDoc.id, 'summaryAr', selectedDoc.summaryAr)}
                        </p>
                        <div className="mt-3 pt-2 border-t border-stone-200/60 font-mono text-[11px] text-stone-500">
                          {t('docs.path_label')}: {selectedDoc.filename}
                        </div>
                      </div>
                    </div>

                    {/* Document Reader Main Panel */}
                    <div className="lg:col-span-3 bg-white rounded-2xl border border-stone-200 p-6 shadow-xs">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 mb-6 border-b border-stone-100 gap-3">
                        <div>
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-mono text-xs px-2 py-0.5 rounded bg-stone-100 text-stone-700 border border-stone-200">
                              {selectedDoc.filename}
                            </span>
                            <span className="text-xs text-stone-400">•</span>
                            <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                              {t('batch4.reference.production_ready_spec')}
                            </span>
                          </div>
                          <h2 className="text-lg font-bold text-stone-900">
                            {batch4ReferenceText(t, selectedDoc.id, 'titleAr', selectedDoc.titleAr)} ({selectedDoc.titleEn})
                          </h2>
                        </div>

                        <div className="flex items-center gap-2 text-xs">
                          <span className="text-stone-500">
                            {t("navigation.labels.txt_3a0110")}
                          </span>
                        </div>
                      </div>

                      {/* Markdown Display */}
                      <div className="prose prose-stone max-w-none prose-headings:font-bold prose-h1:text-xl prose-h2:text-base prose-h3:text-sm prose-p:text-xs prose-p:leading-relaxed prose-li:text-xs prose-code:font-mono prose-code:text-xs prose-code:bg-stone-100 prose-code:px-1 prose-code:py-0.5 prose-code:rounded prose-pre:bg-stone-900 prose-pre:text-stone-100 prose-pre:p-4 prose-pre:rounded-xl">
                        <ReactMarkdown>
                          {selectedDoc.content}
                        </ReactMarkdown>
                      </div>
                    </div>
                  </div>
                )}
              </>
            )}
          </main>

      {/* Industrial Production Footer */}
      <footer className="bg-[#0c0e12] border-t border-white/10 mt-auto py-4 font-mono text-xs text-white/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-black font-display text-[#f8fafc]">Q Saudi Work Follow</span>
            <span className="text-white/20">•</span>
            <span className="text-[#10b981]">2024 System Infrastructure</span>
          </div>
          <div className="flex items-center gap-3 text-[11px] text-white/40">
            <span>Firestore SSOT</span>
            <span>|</span>
            <span>Sheets Projection</span>
            <span>|</span>
            <span>IndexedDB Offline-First</span>
          </div>
        </div>
      </footer>

        </div>
      </div>

      {/* Floating Offline Status Pill & Sync Banner */}
      <OfflineIndicator pendingCount={pendingCount} onOpenOutbox={() => setIsOutboxOpen(true)} />

      {/* Outbox Drawer (Operations Queue, Manual Sync, Network Simulator) */}
      <OutboxDrawer isOpen={isOutboxOpen} onClose={() => setIsOutboxOpen(false)} />

      {/* Secondary System & Developer Tools Drawer */}
      <SystemToolsDrawer
        isOpen={isSystemToolsOpen}
        onClose={() => setIsSystemToolsOpen(false)}
        activeTab={activeTab}
        onSelectTab={(tabId) => {
          setActiveTab(tabId);
        }}
        currentRole={presentationRole}
      />

      {/* Mobile & Tablet Slide-Over Navigation Drawer */}
      <MobileNavDrawer
        isOpen={isMobileNavOpen}
        onClose={() => setIsMobileNavOpen(false)}
        activeTab={activeTab}
        onSelectTab={(tabId) => {
          setActiveTab(tabId);
        }}
        currentRole={presentationRole}
        onChangeRole={handleRoleChange}
        onOpenSystemTools={() => setIsSystemToolsOpen(true)}
        onOpenOutbox={() => setIsOutboxOpen(true)}
        isOnline={isOnline}
        pendingOutboxCount={pendingCount}
      />
    </div></ProfileContinuity>
  );
}
