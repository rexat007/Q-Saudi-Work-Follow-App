import { presentBatch4Message } from 'C:/Users/Hp/Documents/ChatGPT/Work Follow/ui5-postmerge-ui6-discovery-20261121/src/i18n/batch4Messages';
import { batch4ConflictValueLabel } from 'C:/Users/Hp/Documents/ChatGPT/Work Follow/ui5-postmerge-ui6-discovery-20261121/src/i18n/batch4Presentation';
import React, { useState, useEffect } from 'react';
import { 
  X, 
  Wifi, 
  WifiOff, 
  RefreshCw, 
  Database, 
  Layers, 
  Send, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Clock, 
  RotateCw, 
  Trash2, 
  HardDrive, 
  Server,
  Smartphone,
  ChevronDown,
  ChevronUp,
  Info,
  ShieldAlert,
  Scale,
  Lock,
  Play,
  FileCode,
  ShieldCheck
} from 'lucide-react';
import { outboxService } from 'C:/Users/Hp/Documents/ChatGPT/Work Follow/ui5-postmerge-ui6-discovery-20261121/src/services/offline/outbox.service';
import { offlineCacheService } from 'C:/Users/Hp/Documents/ChatGPT/Work Follow/ui5-postmerge-ui6-discovery-20261121/src/services/offline/offlineCache.service';
import { conflictResolutionService } from 'C:/Users/Hp/Documents/ChatGPT/Work Follow/ui5-postmerge-ui6-discovery-20261121/src/services/offline/conflictResolution.service';
import { ConflictResolutionModal } from 'C:/Users/Hp/Documents/ChatGPT/Work Follow/ui5-postmerge-ui6-discovery-20261121/src/components/offline/ConflictResolutionModal';
import { useOnlineStatus } from 'C:/Users/Hp/Documents/ChatGPT/Work Follow/ui5-postmerge-ui6-discovery-20261121/src/hooks/useOnlineStatus';
import { OutboxOperation, OutboxStatus, CacheStoreMetadata, OutboxStats } from 'C:/Users/Hp/Documents/ChatGPT/Work Follow/ui5-postmerge-ui6-discovery-20261121/src/types/offline';
import { ConflictRecord, ConflictType } from 'C:/Users/Hp/Documents/ChatGPT/Work Follow/ui5-postmerge-ui6-discovery-20261121/src/types/conflict';
import { useI18n } from 'C:/Users/Hp/Documents/ChatGPT/Work Follow/ui5-postmerge-ui6-discovery-20261121/src/i18n';


interface OutboxDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onNotification?: (notif: { type: 'SUCCESS' | 'ERROR' | 'SECURITY'; message: string }) => void;
}

export const OutboxDrawer: React.FC<OutboxDrawerProps> = ({
  isOpen,
  onClose,
  onNotification
}) => {
  const { t, direction } = useI18n();
  const { isOnline, isSimulatedOffline, toggleSimulatedOffline } = useOnlineStatus();

  const [activeTab, setActiveTab] = useState<'OUTBOX' | 'CONFLICTS' | 'CACHE'>('OUTBOX');
  const [statusFilter, setStatusFilter] = useState<OutboxStatus | 'ALL'>('ALL');
  const [operations, setOperations] = useState<OutboxOperation[]>([]);
  const [stats, setStats] = useState<OutboxStats>({ total: 0, pending: 0, sending: 0, synced: 0, failed: 0, conflict: 0 });
  const [cacheMeta, setCacheMeta] = useState<CacheStoreMetadata[]>([]);
  const [conflicts, setConflicts] = useState<ConflictRecord[]>([]);
  const [selectedConflict, setSelectedConflict] = useState<ConflictRecord | null>(null);
  const [isConflictModalOpen, setIsConflictModalOpen] = useState<boolean>(false);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [isRefreshingCache, setIsRefreshingCache] = useState<boolean>(false);
  const [expandedOpId, setExpandedOpId] = useState<string | null>(null);
  const loadData = async () => {
    try {
      const [ops, st, meta, confs] = await Promise.all([
        outboxService.getOperations(),
        outboxService.getStats(),
        offlineCacheService.getCacheMetadata(),
        conflictResolutionService.getConflicts(),
      ]);
      setOperations(ops);
      setStats(st);
      setCacheMeta(meta);
      setConflicts(confs);
    } catch (err) {
      console.error('Failed to load outbox/cache state:', err);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadData();
    }
    const unsubOutbox = outboxService.subscribe(() => {
      loadData();
    });
    const unsubConflicts = conflictResolutionService.subscribe(() => {
      loadData();
    });
    return () => {
      unsubOutbox();
      unsubConflicts();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSyncAll = async () => {
    if (!isOnline) {
      onNotification?.({
        type: 'ERROR',
        message: t('offline.messages.txt_36ec7e')
      });
      return;
    }

    setIsSyncing(true);
    try {
      const res = await outboxService.syncAll(isSimulatedOffline);
      await loadData();
      onNotification?.({
        type: 'SUCCESS',
        message: `اكتملت المزامنة: تمت معالجة ${res.processedCount} عملية (نجاح: ${res.syncedCount}، فشل: ${res.failedCount}، تعارض: ${res.conflictCount})`
      });
    } catch (err: any) {
      onNotification?.({
        type: 'ERROR',
        message: err.message || 'فشلت المزامنة'
      });
    } finally {
      setIsSyncing(false);
    }
  };

  const handleRetryOp = async (opId: string) => {
    await outboxService.retryOperation(opId);
    if (isOnline) {
      handleSyncAll();
    } else {
      onNotification?.({
        type: 'SUCCESS',
        message: t('offline.messages.txt_2165a5')
      });
    }
  };

  const handleClearSynced = async () => {
    await outboxService.clearSynced();
    await loadData();
    onNotification?.({
      type: 'SUCCESS',
      message: t('offline.status.success')
    });
  };

  const handleRefreshCache = async () => {
    setIsRefreshingCache(true);
    try {
      const res = await offlineCacheService.refreshCacheWithBump();
      await loadData();
      onNotification?.({
        type: 'SUCCESS',
        message: `تم تحديث وتخزين البيانات المحلية في IndexedDB بنجاح (الإصدار: v${res.newVersion})`
      });
    } catch (err: any) {
      onNotification?.({
        type: 'ERROR',
        message: err.message || 'فشل تحديث الذاكرة المحلية'
      });
    } finally {
      setIsRefreshingCache(false);
    }
  };

  const handleOpenConflictForOp = async (op: OutboxOperation) => {
    const confId = op.conflictDetails?.conflictId;
    let found = conflicts.find(c => c.conflictId === confId || c.operationId === op.operationId);
    if (!found) {
      // If not yet saved in memory, detect or build it
      const detected = conflictResolutionService.detectConflict(op);
      if (detected) {
        found = detected;
      }
    }
    if (found) {
      setSelectedConflict(found);
      setIsConflictModalOpen(true);
    }
  };

  const handleOpenConflictModal = (conflict: ConflictRecord) => {
    setSelectedConflict(conflict);
    setIsConflictModalOpen(true);
  };

  const filteredOps = operations.filter(op => {
    if (statusFilter === 'ALL') return true;
    return op.status === statusFilter;
  });

  const getStatusBadge = (status: OutboxStatus) => {
    switch (status) {
      case 'PENDING':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-300 text-[11px] font-bold">
            <Clock className="w-3 h-3" />
            <span>{t("offline.labels.txt_7eabcf")}</span>
          </span>
        );
      case 'SENDING':
      case 'AWAITING_RECEIPT':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-blue-50 text-blue-800 border border-blue-300 text-[11px] font-bold animate-pulse">
            <RotateCw className="w-3 h-3 animate-spin" />
            <span>{t(status==='AWAITING_RECEIPT'?'offline.recovery.awaiting_receipt':'offline.labels.txt_3bb240')}</span>
          </span>
        );
      case 'SYNCED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-300 text-[11px] font-bold">
            <CheckCircle2 className="w-3 h-3" />
            <span>{t("offline.labels.txt_731fc0")}</span>
          </span>
        );
      case 'FAILED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-rose-50 text-rose-800 border border-rose-300 text-[11px] font-bold">
            <XCircle className="w-3 h-3" />
            <span>{t("offline.status.txt_177559")}</span>
          </span>
        );
      case 'CONFLICT':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-purple-50 text-purple-800 border border-purple-300 text-[11px] font-bold">
            <AlertTriangle className="w-3 h-3" />
            <span>{t("offline.labels.txt_751d01")}</span>
          </span>
        );
    }
  };

  const STORE_LABELS: Record<string, string> = {
    projects: t('offline.labels.projects'),
    carriers: t('offline.labels.txt_262349'),
    materials: t("other.labels.materials_5"),
    trucks: t("entityResolution.labels.trucks"),
    drivers: t('offline.labels.txt_499f33'),
    pricingRules: t('offline.labels.pricing'),
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-start bg-black/50 backdrop-blur-xs transition-opacity" dir={direction}>
      <div className="w-full max-w-2xl h-full bg-stone-50 border-r rtl:border-l ltr:border-r border-stone-200 shadow-2xl flex flex-col overflow-hidden text-right rtl:text-right ltr:text-left">
        
        {/* Header */}
        <div className="bg-white border-b border-stone-200 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-100 text-amber-900">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-stone-900">{t("offline.labels.txt_5542eb")}</h2>
              <p className="text-xs text-stone-500">{t("offline.labels.txt_140117")}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Network State & Offline Simulation Banner */}
        <div className="bg-stone-900 text-white px-6 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            {isOnline ? (
              <span className="flex items-center gap-1.5 font-bold text-emerald-400">
                <Wifi className="w-4 h-4" />
                <span>{t("offline.labels.txt_3f37a7")}</span>
              </span>
            ) : (
              <span className="flex items-center gap-1.5 font-bold text-amber-400">
                <WifiOff className="w-4 h-4" />
                <span>{t("offline.labels.txt_74ecba")}</span>
              </span>
            )}
            <span className="text-stone-400">|</span>
            <span className="text-stone-300 font-mono text-[11px] flex items-center gap-1">
              <Smartphone className="w-3.5 h-3.5 text-stone-400" />
              <span>{t("residual.ui.device_label")}{outboxService.getDeviceId()}</span>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-stone-300 text-[11px]">{t("offline.labels.txt_31f297")}</span>
            <button
              onClick={toggleSimulatedOffline}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-colors ${
                isSimulatedOffline
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'bg-stone-800 hover:bg-stone-700 text-stone-300 border border-stone-700'
              }`}
            >
              {isSimulatedOffline ? t("residual.ui.stop_offline_simulation") : t("residual.ui.start_offline_simulation")}
            </button>
          </div>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-stone-200 bg-white px-6 pt-2 gap-2">
          <button
            onClick={() => setActiveTab('OUTBOX')}
            className={`flex items-center gap-2 pb-3 px-3 text-xs font-bold border-b-2 transition-colors ${
              activeTab === 'OUTBOX'
                ? 'border-amber-600 text-amber-900'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <Send className="w-4 h-4" />
            <span>{t("offline.labels.txt_66c55e")}</span>
            {stats.pending > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-amber-100 text-amber-900 text-[10px]">
                {stats.pending}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('CONFLICTS')}
            className={`flex items-center gap-2 pb-3 px-3 text-xs font-bold border-b-2 transition-colors ${
              activeTab === 'CONFLICTS'
                ? 'border-purple-600 text-purple-950'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <ShieldAlert className="w-4 h-4 text-purple-600" />
            <span>{t("offline.labels.txt_47ad3c")}</span>
            {conflicts.filter(c => c.status === 'OPEN').length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-purple-600 text-white text-[10px] animate-pulse">
                {conflicts.filter(c => c.status === 'OPEN').length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('CACHE')}
            className={`flex items-center gap-2 pb-3 px-3 text-xs font-bold border-b-2 transition-colors ${
              activeTab === 'CACHE'
                ? 'border-amber-600 text-amber-900'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>{t("offline.labels.txt_519208")}</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {activeTab === 'OUTBOX' && (
            <div className="space-y-4">
              {/* Quick Actions & Stats Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-xl border border-stone-200 shadow-2xs">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-bold text-stone-600">{t("offline.labels.filter")}</span>
                  {(['ALL', 'PENDING', 'SENDING', 'AWAITING_RECEIPT', 'SYNCED', 'FAILED', 'CONFLICT'] as const).map(st => (
                    <button
                      key={st}
                      onClick={() => setStatusFilter(st)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-colors ${
                        statusFilter === st
                          ? 'bg-amber-100 text-amber-900 border border-amber-300'
                          : 'bg-stone-100 hover:bg-stone-200 text-stone-600'
                      }`}
                    >
                      {st === 'ALL' ? `${t("admin_console.filter_all")} (${stats.total})` : `${st==='AWAITING_RECEIPT'?t('offline.recovery.awaiting_receipt'):st} (${stats[st.toLowerCase() as keyof OutboxStats] || 0})`}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  {stats.synced > 0 && (
                    <button
                      onClick={handleClearSynced}
                      className="px-2.5 py-1.5 rounded-lg border border-stone-300 hover:bg-stone-100 text-stone-700 text-xs font-medium flex items-center gap-1 transition-colors"
                      title={t("offline.labels.txt_4043c4")}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{t("offline.labels.txt_8b427e")}</span>
                    </button>
                  )}
                  <button
                    onClick={handleSyncAll}
                    disabled={isSyncing || !isOnline}
                    className="px-3.5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors"
                  >
                    <RotateCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                    <span>{isSyncing ? t("residual.ui.synchronizing") : t("residual.ui.synchronize_now")}</span>
                  </button>
                </div>
              </div>

              {/* Operations Cards List */}
              {filteredOps.length === 0 ? (
                <div className="bg-white rounded-xl border border-dashed border-stone-300 p-8 text-center space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
                  <p className="text-sm font-bold text-stone-800">{t("offline.labels.txt_9b46da")}</p>
                  <p className="text-xs text-stone-500">
                    {t("offline.labels.createTrip_2")}</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {filteredOps.map(op => {
                    const isExpanded = expandedOpId === op.operationId;
                    return (
                      <div
                        key={op.operationId}
                        className="bg-white rounded-xl border border-stone-200 shadow-2xs hover:border-amber-300 transition-all p-4 space-y-3"
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-stone-100 pb-2.5">
                          <div className="flex items-center gap-2">
                            {getStatusBadge(op.status)}
                            <span className="font-mono text-xs font-bold text-stone-800">{op.operationId}</span>
                            <span className="text-stone-300">|</span>
                            <span className="text-xs text-stone-600 font-medium">{t("residual.ui.operation_type_label")}{op.operationType}</span>
                          </div>

                          <div className="flex items-center gap-2 text-xs text-stone-500">
                            <Clock className="w-3.5 h-3.5" />
                            <span>{new Date(op.createdAt).toLocaleTimeString('ar-SA')} - {new Date(op.createdAt).toLocaleDateString('ar-SA')}</span>
                          </div>
                        </div>

                        {/* Summary Details */}
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs bg-stone-50 p-2.5 rounded-lg border border-stone-200/60">
                          <div>
                            <span className="text-stone-500 block text-[10px]">{t("operations.trip_number")}</span>
                            <span className="font-mono font-bold text-stone-900">{op.payload?.tripSerial || op.payload?.tripId || t("weighbridge.labels.txt_68c5e6")}</span>
                          </div>
                          <div>
                            <span className="text-stone-500 block text-[10px]">{t("field_operations.net_weight_label")}</span>
                            <span className="font-bold text-stone-900">
                              {op.payload?.grossWeight && op.payload?.tareWeight 
                                ? `${(op.payload.grossWeight - op.payload.tareWeight).toLocaleString()} ${t("shared.units.kg")}`
                                : t("weighbridge.labels.txt_68c5e6")}
                            </span>
                          </div>
                          <div>
                            <span className="text-stone-500 block text-[10px]">{t("offline.labels.txt_402c63")}</span>
                            {op.payload?.pricingSnapshot?.isPending || op.payload?.pricingStatus === 'PENDING' || op.payload?.pricingRuleId === 'UNRESOLVED_PENDING' ? (
                              <span className="inline-flex items-center gap-1 font-bold text-amber-800 bg-amber-100/70 px-1.5 py-0.5 rounded text-[11px] border border-amber-300">
                                <AlertTriangle className="w-3 h-3 text-amber-600" />
                                <span>{t("residual.ui.pending_settlement")}</span>
                              </span>
                            ) : (
                              <span className="font-bold text-amber-900">
                                {op.payload?.settlementAmount !== undefined ? `${op.payload.settlementAmount.toLocaleString()} ${t("shared.units.sar")}` : t("weighbridge.labels.txt_68c5e6")}
                              </span>
                            )}
                          </div>
                          <div>
                            <span className="text-stone-500 block text-[10px]">{t("offline.labels.txt_6526c5")}</span>
                            <span className="font-bold text-stone-900">{t("residual.ui.attempt_count", { count: op.retryCount })}</span>
                          </div>
                        </div>

                        {/* Pending Pricing Alert */}
                        {(op.payload?.pricingSnapshot?.isPending || op.payload?.pricingStatus === 'PENDING' || op.payload?.pricingRuleId === 'UNRESOLVED_PENDING') && (
                          <div className="text-xs bg-amber-50 border border-amber-300 rounded-lg p-2.5 text-amber-950 flex items-start gap-2">
                            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                            <div>
                              <div className="font-bold">{t("offline.status.pending_2")}</div>
                              <div className="text-[11px] text-amber-900 mt-0.5 leading-relaxed">
                                {t("residual.ui.pending_contract_settlement_notice")}</div>
                            </div>
                          </div>
                        )}

                        {/* Feedback / Error / ACK */}
                        {op.serverAck && (
                          <div className="text-xs bg-emerald-50 border border-emerald-200 rounded-lg p-2.5 text-emerald-900 flex items-start gap-2">
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                            <div>
                              <div className="font-bold">{t("offline.labels.txt_292ade")}</div>
                              <div>{presentBatch4Message(op.serverAck.messageAr, t)} {t("residual.ui.server_trip_number", { number: op.serverAck.tripSerial })}</div>
                            </div>
                          </div>
                        )}

                        {op.errorReason && (
                          <div className="text-xs bg-rose-50 border border-rose-200 rounded-lg p-2.5 text-rose-900 flex items-start gap-2">
                            <XCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                            <div>
                              <div className="font-bold">{t("legacyMigration.status.failed_2")}</div>
                              <div>{op.errorReason==='RECEIPT_REQUIRED'?t('offline.recovery.awaiting_receipt'):presentBatch4Message(op.errorReason, t)}</div>
                            </div>
                          </div>
                        )}

                        {op.conflictDetails && (
                          <div className="text-xs bg-purple-50 border border-purple-200 rounded-lg p-2.5 text-purple-900 flex items-start gap-2">
                            <AlertTriangle className="w-4 h-4 text-purple-600 shrink-0 mt-0.5" />
                            <div>
                              <div className="font-bold">{t("offline.labels.details")}</div>
                              <div>{presentBatch4Message(op.conflictDetails.messageAr, t)}</div>
                            </div>
                          </div>
                        )}

                        {/* Expandable Payload & Retry Actions */}
                        <div className="flex items-center justify-between pt-1">
                          <button
                            onClick={() => setExpandedOpId(isExpanded ? null : op.operationId)}
                            className="text-xs text-stone-600 hover:text-stone-900 flex items-center gap-1 font-medium"
                          >
                            {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                            <span>{isExpanded ? t("residual.ui.hide_payload") : t("residual.ui.show_payload")}</span>
                          </button>

                          <div className="flex items-center gap-2">
                            {op.status === 'CONFLICT' && (
                              <button
                                onClick={() => handleOpenConflictForOp(op)}
                                className="px-3.5 py-1.5 rounded-lg bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-colors"
                              >
                                <ShieldAlert className="w-3.5 h-3.5" />
                                <span>{t("offline.labels.txt_46be08")}</span>
                              </button>
                            )}

                            {(op.status === 'FAILED' || op.status === 'CONFLICT' || op.status === 'AWAITING_RECEIPT') && (
                              <button
                                onClick={() => handleRetryOp(op.operationId)}
                                className="px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-900 text-stone-200 text-xs font-bold flex items-center gap-1 shadow-2xs transition-colors"
                              >
                                <RotateCw className="w-3 h-3" />
                                <span>{t("offline.labels.txt_a748f4")}</span>
                              </button>
                            )}
                          </div>
                        </div>

                        {isExpanded && (
                          <div className="mt-2 p-3 bg-stone-900 text-stone-200 rounded-lg text-xs font-mono overflow-x-auto max-h-48 text-left" dir="ltr">
                            <pre>{JSON.stringify(op.payload, null, 2)}</pre>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {activeTab === 'CONFLICTS' && (
            <div className="space-y-4">
              {/* Mandatory Anti-LWW Rules & Pricing Invariance Banner */}
              <div className="bg-stone-900 text-white p-4.5 rounded-xl border border-stone-800 space-y-2 shadow-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
                    <ShieldAlert className="w-4 h-4" />
                    <span>{t("offline.labels.txt_21781d")}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-stone-800 text-purple-300 border border-purple-500/30">
                    {t("residual.ui.strict_audit_trail")}</span>
                </div>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] text-stone-300 pt-1">
                  <li className="flex items-start gap-1.5">
                    <span className="text-amber-400 font-bold">•</span>
                    <span><strong>{t("offline.labels.txt_44754a")}</strong> {t("offline.labels.txt_5753f6")}</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <span className="text-emerald-400 font-bold">•</span>
                    <span><strong>{t("offline.labels.txt_197045")}</strong> {t("residual.ui.binding_snapshot")}</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <span className="text-purple-400 font-bold">•</span>
                    <span><strong>{t("offline.labels.save")}</strong> {t("offline.labels.save_2")}</span>
                  </li>
                  <li className="flex items-start gap-1.5">
                    <span className="text-blue-400 font-bold">•</span>
                    <span><strong>{t("offline.labels.txt_6aae4c")}</strong> {t("residual.ui.future_rates_only")}</span>
                  </li>
                </ul>
              </div>

              {/* Conflicts List */}
              {conflicts.length === 0 ? (
                <div className="bg-white rounded-xl border border-stone-200 p-8 text-center space-y-2">
                  <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h4 className="text-sm font-bold text-stone-800">{t("offline.status.txt_60598f")}</h4>
                  <p className="text-xs text-stone-500 max-w-md mx-auto">
                    {t("offline.labels.txt_10b6c4")}</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {conflicts.map(conf => {
                    const isOpen = conf.status === 'OPEN';
                    return (
                      <div
                        key={conf.conflictId}
                        className={`bg-white rounded-xl border p-4.5 space-y-3 shadow-2xs transition-all ${
                          isOpen ? 'border-amber-300 ring-1 ring-amber-100' : 'border-stone-200 bg-stone-50/40'
                        }`}
                      >
                        {/* Header */}
                        <div className="flex items-start justify-between gap-3">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className={`px-2.5 py-0.5 rounded-md text-[11px] font-bold border ${
                                isOpen 
                                  ? 'bg-amber-100 text-amber-900 border-amber-300'
                                  : 'bg-emerald-100 text-emerald-900 border-emerald-300'
                              }`}>
                                {isOpen ? t("residual.ui.conflict_open") : t("residual.ui.conflict_resolved")}
                              </span>
                              <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-stone-100 text-stone-700">
                                {conf.conflictType}
                              </span>
                              <span className="text-[11px] font-mono text-stone-400">
                                {conf.conflictId}
                              </span>
                            </div>
                            <h4 className="text-xs font-bold text-stone-900 pt-0.5">{presentBatch4Message(conf.titleAr, t)}</h4>
                            <p className="text-xs text-stone-600 leading-relaxed">{presentBatch4Message(conf.descriptionAr, t)}</p>
                          </div>

                          {isOpen && (
                            <button
                              onClick={() => handleOpenConflictModal(conf)}
                              className="px-4 py-2 rounded-xl bg-purple-700 hover:bg-purple-800 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors shrink-0"
                            >
                              <ShieldAlert className="w-4 h-4" />
                              <span>{t("offline.labels.txt_46be08")}</span>
                            </button>
                          )}
                        </div>

                        {/* Pricing Invariance Highlight */}
                        {conf.pricingProtection && (
                          <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 text-xs flex items-center justify-between gap-3">
                            <div className="flex items-center gap-2">
                              <Lock className="w-4 h-4 text-emerald-700 shrink-0" />
                              <div>
                                <span className="font-bold text-emerald-950">{t("offline.labels.txt_6aaee2")}</span>
                                <span className="text-emerald-900">
                                  {t("residual.ui.snapshot_rate_label")}{conf.pricingProtection.snapshotRate} {t("shared.units.sar") + " | " + t("residual.ui.server_rate_label")}{conf.pricingProtection.serverCurrentRate} {t("shared.units.sar")}</span>
                              </div>
                            </div>
                            <span className="px-2 py-0.5 rounded bg-emerald-200/80 text-emerald-900 font-bold text-[10px]">
                              {t("residual.ui.contractually_protected_rate")}</span>
                          </div>
                        )}

                        {/* Diff Fields Mini View */}
                        <div className="bg-stone-50 rounded-lg p-2.5 border border-stone-200 text-xs">
                          <div className="text-[11px] font-bold text-stone-700 mb-1">{t("offline.labels.txt_231b48")}</div>
                          <div className="space-y-1">
                            {conf.diffFields.map((d, i) => (
                              <div key={i} className="flex items-center justify-between text-[11px] bg-white p-1.5 px-2.5 rounded border border-stone-200">
                                <span className="font-bold text-stone-800">{presentBatch4Message(d.fieldLabelAr, t)} ({d.field})</span>
                                <div className="flex items-center gap-2 font-mono">
                                  <span className="text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-200">
                                    {t("offline.labels.txt_24195a")}{String(d.localValue)}
                                  </span>
                                  <span className="text-stone-400">↔</span>
                                  <span className="text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200">
                                    {t("offline.labels.txt_69531e")}{batch4ConflictValueLabel(t, d.field, d.serverValue)}
                                  </span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Resolution Summary if RESOLVED */}
                        {conf.status === 'RESOLVED' && conf.resolution && (
                          <div className="bg-emerald-50/70 border border-emerald-200 rounded-lg p-3 text-xs space-y-1">
                            <div className="flex items-center justify-between font-bold text-emerald-950">
                              <span className="flex items-center gap-1">
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
                                <span>{t("residual.ui.approved_decision_label")}{conf.resolution.strategy}</span>
                              </span>
                              <span className="text-[10px] text-emerald-800">
                                {t("operations.by")}{conf.resolution.resolvedBy}
                              </span>
                            </div>
                            <div className="text-[11px] text-emerald-900">
                              <strong>{t("offline.labels.txt_a9b605")}</strong> {conf.resolution.justification}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {activeTab === 'CACHE' && (
            <div className="space-y-4">
              <div className="bg-white p-4 rounded-xl border border-stone-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-xs font-bold text-stone-900">{t("offline.labels.txt_6fc0d8")}</h3>
                  <p className="text-xs text-stone-500">
                    {t("residual.ui.cache_consistency_notice")}</p>
                </div>
                <button
                  onClick={handleRefreshCache}
                  disabled={isRefreshingCache}
                  className="px-3 py-1.5 rounded-lg bg-stone-800 hover:bg-stone-900 text-white text-xs font-bold flex items-center gap-1.5 shadow-2xs disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingCache ? 'animate-spin' : ''}`} />
                  <span>{isRefreshingCache ? t("entityResolution.labels.refreshing") : t("residual.ui.refresh_cache")}</span>
                </button>
              </div>

              {/* Cache Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {cacheMeta.map(meta => (
                  <div
                    key={meta.storeName}
                    className="bg-white rounded-xl border border-stone-200 p-4 shadow-2xs space-y-2 hover:border-amber-300 transition-colors"
                  >
                    <div className="flex items-center justify-between border-b border-stone-100 pb-2">
                      <span className="font-bold text-stone-900 text-xs">
                        {STORE_LABELS[meta.storeName] || meta.storeName}
                      </span>
                      <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 font-mono text-[10px] font-bold">
                        v{meta.version}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-stone-400 block text-[10px]">{t("offline.labels.txt_6464df")}</span>
                        <span className="font-bold text-stone-800">{meta.recordCount + " " + t("analytics.ui.records")}</span>
                      </div>
                      <div>
                        <span className="text-stone-400 block text-[10px]">{t("offline.labels.txt_7490af")}</span>
                        <span className="font-mono text-stone-700 text-[10px]">
                          {new Date(meta.timestamp).toLocaleTimeString('ar-SA')}
                        </span>
                      </div>
                    </div>

                    <div className="text-[10px] text-stone-400 pt-1 border-t border-stone-50 flex items-center justify-between">
                      <span>{t("residual.ui.storage_source_label")}{meta.lastSyncedBy || 'SYSTEM'}</span>
                      <span className="text-emerald-700 font-medium">{t("offline.labels.txt_41cc14")}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Offline Rule Compliance Notice */}
              <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-4 text-xs text-amber-900 space-y-2">
                <div className="flex items-center gap-1.5 font-bold">
                  <Info className="w-4 h-4 text-amber-700" />
                  <span>{t("offline.labels.txt_9a78d6")}</span>
                </div>
                <ul className="list-disc list-inside space-y-1 text-[11px] text-amber-800 pr-2">
                  <li>{t("offline.labels.txt_539bb6")}</li>
                  <li><strong>{t("offline.labels.txt_66cc97")}</strong> {t("offline.labels.createTripPricing")}</li>
                  <li>{t("offline.labels.txt_5cde42")}</li>
                </ul>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-white border-t border-stone-200 px-6 py-3 flex items-center justify-between">
          <span className="text-xs text-stone-500">
            {stats.pending > 0 
              ? t("residual.ui.pending_sync_count", { count: stats.pending })
              : t("residual.ui.all_synchronized")}
          </span>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg border border-stone-300 hover:bg-stone-100 text-stone-700 text-xs font-bold transition-colors"
          >
            {t("shared.actions.close")}</button>
        </div>

        {/* Explicit Conflict Resolution Modal */}
        <ConflictResolutionModal
          isOpen={isConflictModalOpen}
          conflict={selectedConflict}
          onClose={() => {
            setIsConflictModalOpen(false);
            setSelectedConflict(null);
          }}
          onResolved={(confId, msg) => {
            onNotification?.({
              type: 'SUCCESS',
              message: msg,
            });
            loadData();
          }}
        />

      </div>
    </div>
  );
};
