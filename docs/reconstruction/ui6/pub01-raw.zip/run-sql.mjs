import fs from 'node:fs';import path from 'node:path';import cp from 'node:child_process';import {createRequire} from 'node:module';
const e=path.resolve('../ui6-pub01-evidence-20261121'),bin=path.resolve('../release-blocker-pg-native/bin'),data=path.join(e,'pgdata'),port=55462,env={...process.env,CI:'1',QSA_BROWSER_TOOL_ROOT:'C:/Users/Hp/Documents/ChatGPT/Promise of Planet — وعد الكوكب/.u07-tools'};
const key=Object.keys(env).find(k=>k.toLowerCase()==='path')||'Path';env[key]=path.dirname(process.execPath)+';'+env[key];
const {Pool}=createRequire(path.resolve('package.json'))('pg');let started=false,owner;const result={port,data,ownedCluster:true};
const run=(name,exe,args)=>{const fd=fs.openSync(path.join(e,name+'.log'),'wx');const r=cp.spawnSync(exe,args,{env,windowsHide:true,stdio:['ignore',fd,fd]});fs.closeSync(fd);result[name]={exit:r.status};fs.writeFileSync(path.join(e,'sql-exits.json'),JSON.stringify(result,null,2));return r.status};
try{
 if(fs.existsSync(data))throw Error('PRESERVE_EXISTING_DATA');
 if(run('pg-init',path.join(bin,'initdb.exe'),['-D',data,'-U','postgres','-A','trust','--encoding=UTF8','--locale=C']))throw Error('INITDB_FAILED');
 if(run('pg-start',path.join(bin,'pg_ctl.exe'),['-D',data,'-l',path.join(e,'postgres.log'),'-o','-h 127.0.0.1 -p '+port,'-w','start']))throw Error('PG_START_FAILED');started=true;
 owner=new Pool({connectionString:'postgresql://postgres@127.0.0.1:'+port+'/postgres'});
 await owner.query('CREATE ROLE qsa_migrator LOGIN CREATEROLE; CREATE ROLE qsa_runtime LOGIN; CREATE ROLE qsa_auth LOGIN;');await owner.query('CREATE DATABASE ui6_continuity OWNER qsa_migrator');
 const url=u=>'postgresql://'+u+'@127.0.0.1:'+port+'/ui6_continuity';Object.assign(env,{QSA_TEST_DATABASE_ISOLATED:'1',TEST_DATABASE_URL:url('postgres'),DATABASE_URL:url('qsa_runtime'),AUTH_DATABASE_URL:url('qsa_auth'),MIGRATION_DATABASE_URL:url('qsa_migrator'),PG_BIN_DIR:bin});
 const migration="import pg from 'pg';import {applyMigrations} from './src/db/migrator.ts';const p=new pg.Pool({connectionString:process.env.MIGRATION_DATABASE_URL});applyMigrations(p).then(console.log).finally(()=>p.end()).catch(e=>{console.error(e);process.exitCode=1});";
 if(run('sql-migrate',process.execPath,['node_modules/tsx/dist/cli.mjs','-e',migration]))throw Error('FIXTURE_MIGRATION_FAILED');
 result.testExit=run('offline-continuity',process.execPath,['node_modules/vitest/vitest.mjs','run','src/tests/ar2U07OfflineContinuity.test.ts','--maxWorkers=1','--reporter=json','--outputFile='+path.join(e,'offline-continuity.json')]);
}catch(err){result.error=String(err)}finally{await owner?.end();if(started)result.stopExit=run('pg-stop',path.join(bin,'pg_ctl.exe'),['-D',data,'-m','fast','-t','180','-w','stop']);fs.writeFileSync(path.join(e,'sql-exits.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));}
