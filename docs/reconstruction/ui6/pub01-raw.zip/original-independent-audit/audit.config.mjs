export default {"root": "C:/Users/Hp/Documents/ChatGPT/Work Follow/ui6-publication-audit-20261121", "test": {"globals": true, "environment": "node", "include": ["*.test.tsx"]}};
