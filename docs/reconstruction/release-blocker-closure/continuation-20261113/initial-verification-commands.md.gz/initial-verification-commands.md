# Reproduction boundaries

Run from the convergence-1 repository using the recorded Node 22 runtime and unchanged package configuration. Exact historical/native selections are stored beside this file. The accepted baseline identity source is docs/reconstruction/convergence-3/historical-failures.json; no baseline code was changed.

- Full historical: vitest run <release-blocker-final-suite-files.json paths> src/tests/driverViewConvergenceP603.test.ts src/tests/i18nCodemod.test.ts --maxWorkers=1 --reporter=json.
- Exact package chain: npm test (exit 0, 48 commands, 546 passing tests).
- Release: npm run verify:beta2 (exit 0, final integration selection 443 passing tests).
- Final source: npm run lint; npm run build (both exit 0).
- Final frozen catalog: vitest run src/tests/finalReleaseReadiness.test.ts src/tests/runtimeKeyAudit.test.ts src/tests/runtimeSmokeBlock55.test.ts src/tests/switcherAndQualityBlock56.test.ts --maxWorkers=1 (49/49).
- Repeated timing families: durableImportSessionP8B1, operationalProfiles, operationalReportTabIsolation, operationalWorkspaceTemplates, workspaceBoundedWorkbookInspection, workspaceLocalBlueprint, workspaceProviderResilience native .test.ts files; unchanged default deadlines, maxWorkers=1 (148/160).
- Browser: QSA_BROWSER_TOOL_ROOT points to the existing .u07-tools Playwright installation; optional QSA_TEST_DIAGNOSTICS=1 emits phase names only. convergence3JournalBrowser retains sixty seconds. Actual Edge runs use a disposable context and localhost test server.
- PostgreSQL: only the owned localhost 55439 test cluster; QSA_TEST_DATABASE_ISOLATED=1 and restricted fixture roles. The attached runner creates a unique qsa_rbclosure_ database, applies unchanged 001–012, runs requested native selections, and drops its owned database in finally. The cluster is stopped after tests. Recreating test infrastructure is not production activation authorization.
- Connected browser tests used demo-convergence2 Auth/Firestore emulators on localhost 9099/8085. Those owned emulators were stopped. No live Google operation or production service/data was used.

Raw gzip JSON retains each exact fullName, assertion status and failure stack. Filtered rows are not counted as passing. Selections overlap and must not be added. All original registered identities are retained as recorded in assertion-registration.json.
