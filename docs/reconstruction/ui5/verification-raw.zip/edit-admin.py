from pathlib import Path
p=Path('src/components/admin/AdminConsoleView.tsx');s=p.read_text(encoding='utf8')
s=s.replace("import React, { useState, useEffect, useMemo } from 'react';","import React, { useState, useEffect, useMemo, useRef } from 'react';\nimport {auth} from '../../firebase/config';\nimport {ImportOverlay} from '../import/ImportOverlay';\nimport {runAccountDecision, accountFieldsMatch, type DecisionResult} from './adminDecisionReadback';\nimport type {AdminAccountCommand} from '../../services/adminAccountClient.service';")
s=s.replace('export function AdminConsoleView() {', '''export function AdminConsoleView() {
  const context=useAuth(),{t}=useI18n();
  const key=JSON.stringify([context.user?.uid,context.profileAuthority,context.isProfileLoading,context.userProfile?.userId,context.userProfile?.role,context.userProfile?.status,context.userProfile?.isActive,[...(context.userProfile?.assignedProjectIds||[])].sort()]);
  const scope=useRef({key,alive:true});scope.current.key=key;
  useEffect(()=>{scope.current.alive=true;return()=>{scope.current.alive=false;};},[]);
  const available=Boolean(context.user&&context.userProfile?.status==='ACTIVE'&&context.userProfile.isActive!==false&&!context.isProfileLoading&&(!context.profileAuthority||context.profileAuthority==='AVAILABLE')&&['SUPER_ADMIN','PROJECT_ADMIN'].includes(context.userProfile.role));
  if(!available)return <p role="alert">{t('ui5.denied')}</p>;
  return <AdminAccountWorkspace key={key} isCurrent={()=>scope.current.alive&&scope.current.key===key&&auth.currentUser?.uid===context.user?.uid}/>;
}

type ReadStatus='idle'|'loading'|'ready'|'error';
const readKeys={idle:'ui5.not_loaded',loading:'ui5.loading',ready:'ui5.loaded',error:'ui5.read_error'} as const;
const outcomeKeys={confirmed:'ui5.confirmed',conflict:'ui5.conflict',partial:'ui5.partial',unresolved:'ui5.unresolved',failed:'ui5.failed',readback:'ui5.readback'} as const;
function AdminAccountWorkspace({isCurrent}:{isCurrent:()=>boolean}) {''',1)
# Preserve existing state/SSR fixture ordering, keeping selectedUserForSecurity as a separate draft.
a=s.index('  const showBanner =');b=s.index('  // Filtered Users List',a)
s=s[:a]+'''  const [readState,setReadState]=useState<{users:ReadStatus;projects:ReadStatus;audit:ReadStatus}>({users:'idle',projects:'idle',audit:'idle'});
  const [selectedId,setSelectedId]=useState('');
  const [busy,setBusy]=useState(false);
  const [outcome,setOutcome]=useState<DecisionResult|null>(null);
  const [reviewed,setReviewed]=useState(false);
  const selected=useRef({id:selectedUserForSecurity?.userId||'',generation:0});
  const commandLock=useRef(false),requests=useRef({users:0,projects:0,audit:0});
  const canDecide=readState.users==='ready'&&!busy&&(!outcome||outcome.status==='confirmed'||outcome.status==='failed'||reviewed);
  const copyDraft=(user:UserEntity)=>({...user,assignedProjectIds:[...(user.assignedProjectIds||[])]});
  const chooseUser=(user:UserEntity)=>{
    if(selected.current.id!==user.userId){selected.current={id:user.userId,generation:selected.current.generation+1};setOutcome(null);setReviewed(false);setBanner(null);setUserApprovalModal(null);setUserRejectionModal(null);}
    setSelectedId(user.userId);setSelectedUserForSecurity(copyDraft(user));
  };
  const showBanner = (message: string, type: 'success' | 'warning' | 'info' = 'success') => setBanner({ type, message });
  const setRead=(kind:keyof typeof requests.current,value:ReadStatus)=>setReadState(previous=>({...previous,[kind]:value}));
  const loadUsers=async()=>{
    const request=++requests.current.users;setRead('users','loading');
    try {const next=await userRepository.listAll();if(!isCurrent()||request!==requests.current.users)return;
      setUsers(next);setRead('users','ready');
      if(selected.current.id){const target=next.find(user=>user.userId===selected.current.id);if(target){setSelectedUserForSecurity(copyDraft(target));}else{selected.current={id:'',generation:selected.current.generation+1};setSelectedId('');setSelectedUserForSecurity(null);setUserApprovalModal(null);setUserRejectionModal(null);setOutcome(null);}}
    }catch{if(isCurrent()&&request===requests.current.users)setRead('users','error');}
  };
  const loadProjects=async()=>{
    const request=++requests.current.projects;setRead('projects','loading');
    try {const next=await projectRepository.listAll(userProfile?.assignedProjectIds||[],userProfile?.role==='SUPER_ADMIN');if(isCurrent()&&request===requests.current.projects){setProjects(next);setRead('projects','ready');}}
    catch{if(isCurrent()&&request===requests.current.projects)setRead('projects','error');}
  };
  const loadAudit=async()=>{
    const request=++requests.current.audit;setRead('audit','loading');
    try {const next=await auditLogService.getRecentAuditLogs(100);if(isCurrent()&&request===requests.current.audit){setAuditLogs(next);setRead('audit','ready');}}
    catch{if(isCurrent()&&request===requests.current.audit)setRead('audit','error');}
  };
  useEffect(()=>{void loadUsers();void loadProjects();},[]);
  useEffect(()=>{if(activeSection==='AUDIT_LOGS')void loadAudit();return()=>{requests.current.audit++;};},[activeSection]);

''' +s[b:]
a=s.index('  const refreshTarget =');b=s.index('\n  return (',a)
s=s[:a]+'''  const refreshTarget = async (userId: string) => userRepository.findByIdFromServer(userId);
  const applyReadback=(fresh:UserEntity|null,id:string)=>{
    setUsers(previous=>fresh?previous.map(user=>user.userId===id?fresh:user):previous.filter(user=>user.userId!==id));
    if(selected.current.id===id)setSelectedUserForSecurity(fresh?copyDraft(fresh):null);
  };
  const decide=async(targetId:string,commands:AdminAccountCommand[])=>{
    if (!canManageUsers || !canDecide || !isCurrent() || commandLock.current || !commands.length || targetId===currentUser?.uid || !users.some(user=>user.userId===targetId))return;
    if(commands.some(command=>command.command==='approveAccount'||command.command==='replaceAssignedProjects')&&readState.projects!=='ready')return;
    if(selected.current.id!==targetId)return;
    const generation=selected.current.generation;
    const current=()=>isCurrent()&&selected.current.id===targetId&&selected.current.generation===generation;
    commandLock.current=true;setBusy(true);setOutcome(null);setReviewed(false);setBanner(null);
    try {
      const result=await runAccountDecision(targetId,commands,{
        isCurrent:current,
        execute:(command,onFailure)=>executeAdminAccountCommand(targetId,command,{isCurrent:current,onFailure}),
        read:async()=>await refreshTarget(targetId),
        onRead:fresh=>{if(current())applyReadback(fresh,targetId);}
      });
      if(current()&&result){setOutcome(result);if(result.status==='confirmed'){setUserApprovalModal(null);setUserRejectionModal(null);}if(result.status==='failed'&&result.error){const error=result.error;showBanner(t(adminErrorKey(error)), 'warning');}}
    }finally{commandLock.current=false;if(isCurrent())setBusy(false);}
  };
  const reviewReadback=async()=>{
    if(!outcome||busy||!isCurrent()||commandLock.current)return;
    const captured=outcome,generation=selected.current.generation;commandLock.current=true;setBusy(true);
    try{const fresh=await refreshTarget(captured.targetId);if(!isCurrent()||selected.current.generation!==generation||selected.current.id!==captured.targetId)return;
      applyReadback(fresh,captured.targetId);setReviewed(true);
      // A read can prove current fields, never prove execution of a transport-unknown command.
      if(captured.acknowledged===captured.total)setOutcome({...captured,status:accountFieldsMatch(fresh,captured.expected)?'confirmed':'conflict'});
    }catch{if(isCurrent()&&selected.current.generation===generation)setReviewed(false);}
    finally{commandLock.current=false;if(isCurrent())setBusy(false);}
  };
  const handleApproveUserConfirm=async()=>{
    if (!canManageUsers || !userApprovalModal)return;
    await decide(userApprovalModal.userId,[{ command: 'approveAccount',approvedRole:approvalRole,assignedProjectIds:[...approvalProjectIds]}]);
  };
  const handleRejectUserConfirm=async()=>{
    if (!canManageUsers || !userRejectionModal || !rejectionReason.trim())return;
    await decide(userRejectionModal.userId,[{ command: 'rejectAccount',rejectionReason}]);
  };
  const handleSuspendUser=async(target:UserEntity)=>{chooseUser(target);await decide(target.userId,[{ command: 'suspendAccount' }]);};
  const handleReactivateUser=async(target:UserEntity)=>{chooseUser(target);await decide(target.userId,[{ command: 'reactivateAccount' }]);};
  const handleSaveSecurityPolicy=async()=>{
    if (!canManageUsers || !selectedUserForSecurity || readState.projects!=='ready')return;
    const target=selectedUserForSecurity,original=users.find(user=>user.userId===target.userId);if(!original)return;
    const commands:AdminAccountCommand[]=[];
    if(original.role!==target.role)commands.push({ command: 'changeUserRole',newRole:target.role});
    if(JSON.stringify([...original.assignedProjectIds].sort())!==JSON.stringify([...target.assignedProjectIds].sort()))commands.push({ command: 'replaceAssignedProjects',assignedProjectIds:[...target.assignedProjectIds]});
    await decide(target.userId,commands);
  };
  const bindingDecision=async(command:AdminAccountCommand)=>{if(selectedUserForSecurity)await decide(selectedUserForSecurity.userId,[command]);};
''' +s[b:]
# Header, independent source states and durable truthful command feedback.
s=s.replace('<div className="space-y-6" dir={direction}>','''<div className="space-y-6 [&_button:focus-visible]:outline-2 [&_button:focus-visible]:outline-offset-2 [&_button:focus-visible]:outline-emerald-700 [&_input:focus-visible]:ring-2 [&_select:focus-visible]:ring-2" dir={direction} data-testid="ui5-account-review">
      <header><h1 className="text-xl font-bold">{t('ui5.title')}</h1><p>{t('ui5.read_help')}</p>{!canManageUsers&&<p>{t('ui5.read_only')}</p>}</header>
      <div className="grid gap-3 sm:grid-cols-3">
       {(['users','projects',...(activeSection==='AUDIT_LOGS'?['audit']:[])] as ('users'|'projects'|'audit')[]).map(kind=><section key={kind} className="rounded-xl border bg-white p-3 text-stone-900" aria-busy={readState[kind]==='loading'} data-read-source={kind}>
        <h2>{t(kind==='users'?'ui5.users':kind==='projects'?'ui5.projects':'ui5.audit')}</h2><p role={readState[kind]==='error'?'alert':'status'}>{t(readKeys[readState[kind]])}</p>
        <button type="button" disabled={busy||readState[kind]==='loading'} onClick={()=>void (kind==='users'?loadUsers():kind==='projects'?loadProjects():loadAudit())}>{t('ui5.reload')}</button>
       </section>)}
      </div>
      {busy&&<p role="status">{t('ui5.pending')}</p>}
      {outcome&&<section role="status" aria-live="polite" className="rounded-xl border bg-white p-4 text-stone-900" data-decision-status={outcome.status}>
       <h2>{t(outcomeKeys[outcome.status])}</h2><p><bdi>{outcome.targetId}</bdi> · {t('ui5.acknowledged',{count:outcome.acknowledged,total:outcome.total})}</p><p>{t('ui5.no_replay')}</p>
       {outcome.error&&<p>{t(adminErrorKey(outcome.error))}</p>}
       {outcome.status!=='confirmed'&&<button disabled={busy} onClick={()=>void reviewReadback()}>{t('ui5.review_state')}</button>}{reviewed&&<p>{t('ui5.state_reviewed')}</p>}
      </section>}
''',1)
s=s.replace("{users.filter(u => u.status === 'PENDING_APPROVAL').length}","{readState.users==='ready'?users.filter(u => u.status === 'PENDING_APPROVAL').length:'—'}")
s=s.replace("{users.filter(u => u.status === 'ACTIVE' || (u.isActive && !u.status)).length}","{readState.users==='ready'?users.filter(u => u.status === 'ACTIVE' || (u.isActive && !u.status)).length:'—'}")
s=s.replace('{projects.length}',"{readState.projects==='ready'?projects.length:'—'}").replace('{auditLogs.length}',"{readState.audit==='ready'?auditLogs.length:'—'}")
s=s.replace("{t('admin_console.no_users_match')}","{t(readState.users==='ready'?(users.length?'ui5.filtered_empty':'ui5.empty'):readKeys[readState.users])}")
# One list selection predicate across both existing sections.
s=s.replace("{users\n                .filter(u => !searchQuery || u.fullName?.toLowerCase().includes(searchQuery.toLowerCase()))\n                .map(u => (", "{filteredUsers.map(u => (")
s=s.replace('onClick={() => setSelectedUserForSecurity(u)}','onClick={() => chooseUser(u)}')
s=s.replace("                                  setApprovalRole(u.role || 'SUPERVISOR');", "                                  chooseUser(u);setApprovalRole(u.requestedRole || u.role || 'SUPERVISOR');")
s=s.replace("                                  setRejectionReason('');", "                                  chooseUser(u);setRejectionReason('');")
s=s.replace('<tr key={u.userId} className="hover:bg-stone-50/60">','<tr key={u.userId} className="hover:bg-stone-50/60">')
s=s.replace("{u.fullName || t('admin_console.new_user')}</span>","{u.fullName || t('admin_console.new_user')}</span><button type=\"button\" data-review-user={u.userId} onClick={()=>{chooseUser(u);setActiveSection('SECURITY_ACCESS');}}>{t('ui5.select')}</button>")
# Source-dependent decisions: keep capabilities visible but disabled without their evidence.
s=s.replace('onClick={() => {\n                                  chooseUser(u);',"disabled={!canDecide"+"} onClick={() => {\n                                  chooseUser(u);")
s=s.replace('onClick={() => handleSuspendUser(u)}','disabled={!canDecide} onClick={() => handleSuspendUser(u)}').replace('onClick={() => handleReactivateUser(u)}','disabled={!canDecide} onClick={() => handleReactivateUser(u)}')
s=s.replace('<DriverAccountBindingControl key={selectedUserForSecurity.userId} target={selectedUserForSecurity} onChanged={() => refreshTarget(selectedUserForSecurity.userId)} />','<DriverAccountBindingControl key={selectedUserForSecurity.userId} target={users.find(user=>user.userId===selectedUserForSecurity.userId)!} isCurrent={isCurrent} disabled={!canDecide} onDecision={bindingDecision} />')
s=s.replace('value={selectedUserForSecurity.role}','disabled={!canDecide} aria-label={t(\'admin_console.role_assignment\')} value={selectedUserForSecurity.role}')
s=s.replace('onClick={handleSaveSecurityPolicy}','disabled={!canDecide||readState.projects!==\'ready\'} onClick={handleSaveSecurityPolicy}')
s=s.replace('onClick={handleApproveUserConfirm}',"disabled={!canDecide||readState.projects!=='ready'} onClick={handleApproveUserConfirm}")
s=s.replace('disabled={!rejectionReason.trim()}',"disabled={!canDecide||!rejectionReason.trim()}")
# Replace project-card click containers with native labels and checkbox change ownership.
s=s.replace('''<div 
                          key={proj.projectId} 
                          onClick={() => {''','''<label
                          key={proj.projectId}>
                        <input type="checkbox" checked={Boolean(isChecked)} disabled={!canDecide||readState.projects!=='ready'} onChange={() => {''',1)
start=s.index('<label\n                          key={proj.projectId}>');end=s.index('                    })}',start)
chunk=s[start:end];a=chunk.index('                          className=');b=chunk.index('                          <div>',a)
chunk=chunk[:a]+'''                        />
'''+chunk[b:];chunk=chunk.replace('''                        </div>
                      );''','''                        </label>
                      );''');s=s[:start]+chunk+s[end:]
# Approval checklist likewise (preserve all choices).
s=s.replace('''<div 
                        key={p.projectId}
                        onClick={() => {''','''<label key={p.projectId}>
                        <input type="checkbox" checked={checked} disabled={!canDecide||readState.projects!=='ready'} onChange={() => {''',1)
start=s.index('<label key={p.projectId}>');end=s.index('                  })}',start);chunk=s[start:end];a=chunk.index('                        className=');b=chunk.index('                        <div>',a);chunk=chunk[:a]+'''                        />
'''+chunk[b:];chunk=chunk.replace('''                      </div>
                    );''','''                      </label>
                    );''');s=s[:start]+chunk+s[end:]
# Existing owned overlay handles focus, Escape, backdrop and authority-layer precedence.
for modal,label in [('userApprovalModal','admin_console.approve_account_request'),('userRejectionModal','admin_console.reject_account_request')]:
 start=s.index('{canManageUsers && '+modal+' && (');end=s.index('\n      )}',start);chunk=s[start:end];a=chunk.index('<div className="fixed');b=chunk.index('>',a)+1
 chunk=chunk[:a]+f'<ImportOverlay label={{t(\'{label}\')}} busy={{busy}} onDismiss={{()=>set'+('UserApprovalModal' if modal=='userApprovalModal' else 'UserRejectionModal')+'(null)}}>'+chunk[b:]
 last=chunk.rfind('</div>');chunk=chunk[:last]+'</ImportOverlay>'+chunk[last+6:];s=s[:start]+chunk+s[end:]
s=s.replace('onClick={() => setUserApprovalModal(null)}',"disabled={busy} aria-label={t('ui5.close')} onClick={() => setUserApprovalModal(null)}").replace('onClick={() => setUserRejectionModal(null)}',"disabled={busy} aria-label={t('ui5.close')} onClick={() => setUserRejectionModal(null)}")
s=s.replace('placeholder={t(\'admin_console.search_users_placeholder\')}',"aria-label={t('admin_console.search_users_placeholder')} placeholder={t('admin_console.search_users_placeholder')}").replace('placeholder={t(\'admin_console.search_employee\')}',"aria-label={t('admin_console.search_employee')} placeholder={t('admin_console.search_employee')}")
s=s.replace('overflow-hidden">\n              <table','overflow-x-auto">\n              <table').replace('w-full text-right border-collapse text-xs','w-full text-start border-collapse text-xs')
s=s.replace("{selectedUserForSecurity ? (","{selectedUserForSecurity ? (",1).replace('<div className="space-y-6">\n                <div className="pb-4', '<div className="space-y-6" data-selected-user={selectedId||selectedUserForSecurity.userId}>\n                <p>{t(\'ui5.draft\')}</p><div className="pb-4',1)
p.write_text(s,encoding='utf8')
