import fs from 'node:fs';import path from 'node:path';import cp from 'node:child_process';
const root=process.cwd(),out=path.resolve('../ui5-evidence-20261115'),name=process.argv[2]||'baseline';
const files=['adminAccountCommands.test.ts','adminAccountRules.test.ts','adminAccountPresentation.test.ts','adminConsoleConvergence.test.ts','serverAuthenticationTrustBoundary.test.ts','firebaseAdminPersistenceBoundary.test.ts','ui4ReportPresentation.test.ts','ui4ReportScope.test.tsx','ui4ExportIntegrity.test.ts','ui4Ci1ExportLabels.test.ts','runtimeKeyAudit.test.ts'];
if(name!=='baseline')files.push('ui5AccountReview.test.tsx','ui5AccountReadback.test.ts','ui5AccountTransport.test.ts');
const fd=fs.openSync(path.join(out,name+(fs.existsSync(path.join(out,name+'.log'))?'-suite':'')+'.log'),'wx'),args=['node_modules/vitest/vitest.mjs','run',...files.map(f=>'src/tests/'+f),'--maxWorkers=1','--no-file-parallelism','--reporter=default','--reporter=json','--outputFile='+path.join(out,name+'.json')];
const startedAt=new Date().toISOString(),r=cp.spawnSync(process.execPath,args,{cwd:root,env:{...process.env,CI:'1'},stdio:['ignore',fd,fd]});fs.closeSync(fd);fs.writeFileSync(path.join(out,name+'-exit.json'),JSON.stringify({status:r.status,signal:r.signal,args,node:process.version,startedAt,finishedAt:new Date().toISOString()},null,2));console.log(name+' EXIT='+r.status);

process.exitCode=r.status??1;
