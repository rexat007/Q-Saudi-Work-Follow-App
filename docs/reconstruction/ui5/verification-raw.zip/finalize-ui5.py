from pathlib import Path
import json,subprocess,hashlib,zipfile,os,shutil,ast,re,urllib.parse,collections
r=Path.cwd();o=r.parent/'ui5-evidence-20261115';d=r/'docs/reconstruction/ui5'
read=lambda p:json.loads(p.read_text(encoding='utf8'))
write=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def g(folder,*a):return subprocess.check_output(['git','-c','safe.directory='+str(folder),'-C',str(folder),*a],encoding='utf8').rstrip()
pre=read(o/'preflight.json');scope=read(o/'scope-audit.json');source=read(o/'final-source-hashes.json');commands=read(o/'final-command-exits.json');comparison=read(o/'failure-comparison.json')
assert all(sha(r/f)==h for f,h in source.items())
assert {x['name']:x['status'] for x in commands}=={'lint-final':0,'build-final':0,'candidate-final':1,'browser-final':0}
assert (o/'runtime-final-exit.txt').read_text(encoding='utf-8-sig').strip()=='0'
counts=lambda p:{k:read(p)[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']}
assert counts(o/'browser-final.json')==dict(numTotalTests=9,numPassedTests=9,numFailedTests=0,numPendingTests=0)
assert counts(o/'owned-final/candidate-connected.json')==dict(numTotalTests=1,numPassedTests=1,numFailedTests=0,numPendingTests=0)
cleanup=read(o/'owned-final/ui3-connected-connected-browser-exit.json')
assert cleanup['status']==0 and not cleanup['cleanupErrors'] and not cleanup['remainingListeners']
assert comparison['newFailureIdentities']==[] and comparison['newUI5Cases']==48
assert g(r,'rev-parse','HEAD')==pre['head'] and not g(r,'diff','--cached','--name-only')
protected=[]
for s in pre['protected']:
 f=s['folder'];checks={'headUnchanged':g(f,'rev-parse','HEAD')==s['head'],'statusUnchanged':g(f,'status','--porcelain=v1','--untracked-files=all')==s['status'],'rawDirtyHashesUnchanged':all(sha(Path(f)/n)==h for n,h in s['hashes'].items())}
 assert all(checks.values()),f
 protected.append({'folder':f,**checks})
assert len(protected)==22
changed=[f for f,h in pre['existingSources'].items() if sha(r/f)!=h]
assert set(changed)<=set(scope['productionAllowlist']) and not any(f.startswith('src/tests/') for f in changed)
assert all(sha(r/f)==h for f,h in pre['protectedRootFiles'].items())
def method(text,name):
 a=text.index('  async '+name+'(');start=text.index('{',a);depth=0
 for i in range(start,len(text)):
  if text[i]=='{':depth+=1
  elif text[i]=='}':
   depth-=1
   if not depth:return text[a:i+1].replace('\r\n','\n')
old=subprocess.check_output(['git','show','HEAD:src/repositories/user.repository.ts'],encoding='utf8')
new=(r/'src/repositories/user.repository.ts').read_text(encoding='utf8')
assert all(method(old,n)==method(new,n) for n in ['findById','listAll'])
d.mkdir(exist_ok=False)
causes=[
 {'cause':'Coupled users/projects/audit reads and console-only failures','correction':'Independent read states; old views labeled unavailable; source-dependent decisions blocked; audit read only when active','proof':'22 component cases and native partial-read journeys'},
 {'cause':'Selected object doubled as editable state and late results lacked target context','correction':'Stable identity, copied drafts and actor/profile/target/request fencing','proof':'component identity, authority, filtering, target switching and immutable-input assertions'},
 {'cause':'No shared synchronous duplicate submission guard','correction':'Command-lock ref, disabled pending controls and shared driver decision lifecycle','proof':'duplicate-click and busy-dialog cases'},
 {'cause':'ACK and failed refresh were conflated; default reads may use cache','correction':'Additive server-only read through UserRepository and existing decoder; compare relevant fields after each ACK','proof':'18 decision/readback and eight transport/server-read cases plus actual emulator'},
 {'cause':'Role then project update are independent commands','correction':'Per-step ACK counts, stop before next command on failure/mismatch/uncertainty; no combined atomicity claim','proof':'component and real emulator partial sequence'},
 {'cause':'Unknown transport and generic server errors looked like rejection','correction':'Optional observation/context callbacks retain legacy API shape; ambiguous ADMIN_UPDATE_CONFLICT/ADMIN_UPDATE_FAILED stay unresolved; no replay','proof':'new transport cases and unchanged legacy client assertions'},
 {'cause':'Unowned modal layers and div-click project selection','correction':'Existing ImportOverlay, native labeled checkboxes, focus return, contained table scrolling and AR/EN/UR labels','proof':'nine native Edge cases and component focus/keyboard assertions'}
]
contract={'head':pre['head'],'branch':g(r,'branch','--show-current'),'productionAllowlist':scope['productionAllowlist'],'testAllowlist':scope['testAllowlist'],'sourceFiles':source,'changedOriginalSourceFiles':changed,'allOriginalTestsByteUnchanged':True,'allBackendRulesAndRootConfigurationUnchanged':True,'defaultUserRepositoryMethodsUnchanged':True,'frontendExceptions':['Additive getDocFromServer target reader in existing repository; same decoder and permissions','Optional context/failure-kind observation in existing account client; legacy two-argument shapes retained'],'dependencyClassification':scope,'protectedWorktrees':protected,'rb4OriginalNineAndMigration013':'UNCHANGED','ui4XlsxAndOriginalEvidence':'UNCHANGED'}
write(o/'source-contract-final.json',contract);write(d/'source-contract.json',contract);write(d/'failure-comparison.json',comparison)
for f in source:
 p=o/'final-source'/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/f,p)
write(o/'visual-qa.json',{'samplesReviewed':['browser-final/ar-390-dialog.png','browser-final/ur-768-dialog.png','browser-final/en-1440.png'],'scope':'Headless Edge screenshots plus actual keyboard, focus, overflow and control assertions. Full-page images include content outside the current fixed-overlay viewport.','readableTable':'Minimum width within contained scrolling; no body overflow in all nine cases','physicalDeviceScreenReaderCertification':False})
record="""# UI5 — Account Review & Access Decisions

## Current local source-review gate

Owner-authorized implementation on main 08f67b6046cc10e2ee6f3cd8387bcf7bffcaf551, in the existing isolated discovery checkout. All seven inherited documentation changes were inspected and their exact bytes preserved before editing. The [phase ledger](02_PHASE_LEDGER.md) alone owns current state. [Amended contract](UI5_TARGET_DISCOVERY.md), [verification](ui5/verification.json), [exact files](ui5/exact-file-inventory.json), [source boundary](ui5/source-contract.json), [failure identities](ui5/failure-comparison.json) and [raw evidence](ui5/verification-raw.zip).

UI5 = IMPLEMENTED_LOCALLY / VERIFIED_WITH_INHERITED_DEBT / OWNER_REVIEW_PENDING. It is not source-closed, published, deployed, product-accepted or Beta 2 ready. No staging, commit, push, PR, merge, SQL cutover, RB4 activation or live provider/account operation is authorized/performed.

## Source reading, selection and authority

USERS and PROJECTS have independent initial/loading/ready/error states and explicit reloads. AUDIT reads only on its active section, retaining the latest-100 limit. A failed source does not erase another. Retained values are labeled as a previous unavailable view; unavailable metrics show unknown and dependent decisions are disabled. Project evidence is required for approval/project assignment and combined access save; unrelated permitted lifecycle decisions remain available with valid user evidence.

Stable selected identity survives filtering; editable drafts copy source data/project arrays. Actor UID, profile authority/status/role/projects and target/request generations retire stale state. Late results cannot populate a different selected person. A synchronous ref prevents duplicate submissions and existing driver binding shares the same verified decision lifecycle.

Active SUPER_ADMIN alone retains account-command controls. PROJECT_ADMIN remains read-only under the unchanged Firestore read authorization. Self/last-admin/driver uniqueness decisions stay server-owned. No server, Rules, middleware, role policy, bulk endpoint, command schema, route, dependency, Outbox, Workspace, pricing or SQL changes. Existing UserRepository default find/list bodies remain unchanged.

## ACK, readback and uncertain outcomes

A successful HTTP response is an ACK, not final-view certification. One additive method in the existing repository uses getDocFromServer and the existing decoder, with no cache fallback and the same Rules. Relevant changed fields are compared after every ACK, cumulatively for role/project sequences, including project-set semantics and role-related driver unlink. Completion, canonical mismatch/conflict, partial ACK, explicit rejection, ACK/readback failure and unknown submission are separate states. There is no optimistic permission publication, invented receipt or fabricated rollback.

The existing client gains only optional context/failure-kind callbacks, preserving legacy two-argument error/result shapes. Generic ADMIN_UPDATE_CONFLICT and ADMIN_UPDATE_FAILED remain unconfirmed because existing server code also uses generic errors for unknown transaction outcomes. Only allowlisted unambiguous rejections are marked rejected. Each existing server command remains independent; the next step is not sent after mismatch, rejected/unconfirmed outcome or unavailable readback.

Unknown commands are never automatically replayed. A state-only read does not certify execution of the original submission. Unresolved outcomes continue blocking decisions for that selected account in this review session and remain held when revisiting it. This is local UI state, not a durable command journal or idempotency guarantee. Backend protocol expansion was explicitly excluded.

## UX and verification

Existing ImportOverlay owns stacking, background inertness, keyboard/Escape/focus return and busy dismissal. Native labeled checkboxes replace div-only project toggles. AR/EN/UR carry the same 30 UI5 labels. Identifiers are preserved and isolated where displayed. Tables have readable minimum width within contained scrolling, visible focus and stronger local action/label contrast. No global font/framework change.

Unchanged baseline administration/authority/UI4/runtime family: 240/243, exit 1. Final candidate: 288/291, exit 1. The same exact three pre-existing adminConsoleConvergence subscription-string failures remain, with zero new/removed identities and zero skips. Aggregate: NOT PASS. All 48 new cases pass: 22 actual component/state/locale, 18 decision/readback and eight server-read/transport cases. All historical tests and assertions are byte-unchanged; subscriptions were not restored merely to satisfy stale source expectations.

Final native Edge: 9/9, exit 0, AR/EN/UR at 390/768/1440. These use actual components/I18nProvider/ImportOverlay and explicitly synthetic presentation reads/transport. They verify partial project/audit failures, blocked dependent decisions, approval/readback, independent drafts, read-only role, checkbox keyboard operation, dialog focus/Escape/return, document direction and no body overflow. Initial smoke artifacts remain distinct from final layout/unknown-outcome refinements. Final samples were visually inspected; screenshots are not device or screen-reader certification.

Final authenticated loopback emulator: 1/1, exit 0, actual App/Auth/Firestore/server endpoints. Real transactions verify approval/readback/audit, driver link/unlink and uniqueness rejection, role success followed by explicit missing-project rejection (one role audit and no rejected-project audit), persisted-role revocation to PROJECT_ADMIN with direct command denial, self-action denial and last-SUPER_ADMIN protection. Only owned demo-convergence2 fixtures/example.invalid addresses are used. Both owned runs clean all listeners with zero cleanup errors. Earlier emulator 1/1 remains pre-refinement smoke evidence, not final-source acceptance.

Final npm run test:i18n-runtime: 16/16, exit 0. Final npm run lint (tsc --noEmit) and client/PWA/server production build: exit 0; existing chunk-size warning retained. Production/test hashes were frozen before final gates and checked afterwards. No UI5 remote CI was run and no dirty build identity is a deployed artifact identity.

Initial JSX/type errors and two additional intermediate source-shape assertion failures were retained and corrected without changing historical tests. Original UI4 fourteen-failure history, connected 16/17 and separate 1/1, RB1/CI1 red/green and earlier interruptions remain unchanged. This different administration family is not combined with those historical suites or relabeled green.

## Exact scope and stop

30 changed files: 8 production, 7 new tests/fixtures, 15 documentation/evidence. Seven documentation paths were inherited; complete original byte bodies remain preserved. Only the two admin components, one local readback helper, existing UserRepository/account client and AR/EN/UR dictionaries are production changes. All 22 protected worktrees, original nine RB4 dirty-file hashes and unpublished migration 013 are unchanged.

GO to owner source review with inherited non-green debt; publication HOLD. Real-device, screen-reader, live operational/Workspace and Beta 2 acceptance remain separate. Review the conservative unknown-outcome hold, per-step readback, role boundaries and frontend read/client exceptions before any publication authorization. No UI6 implementation.
"""
(r/'docs/reconstruction/UI5_ACCOUNT_REVIEW.md').write_text(record,encoding='utf8')
headers={
 '00_WORK_START_HERE.md':"## CURRENT ENTRY POINTER — UI5 local source review — 2026-11-15\n\nRead the [sole phase ledger](02_PHASE_LEDGER.md) and [UI5 implementation/evidence](UI5_ACCOUNT_REVIEW.md). Owner-authorized UI5 is implemented locally, verified with three unchanged inherited administration failures, and awaiting owner review. UI1–UI4 remain merged/source-closed. No commit/push/PR/merge/deployment/SQL/RB4 or Beta 2 authorization. Earlier pointers below remain historical.\n\n",
 '02_PHASE_LEDGER.md':"## CURRENT UI5 OWNER-AUTHORIZED LOCAL REVIEW — 2026-11-15\n\nThis ledger alone owns current state. UI5 = IMPLEMENTED_LOCALLY / VERIFIED_WITH_INHERITED_DEBT / OWNER_REVIEW_PENDING. UI1–UI4 closure, including UI4/RB1/CI1 merged on main 08f67b6046cc10e2ee6f3cd8387bcf7bffcaf551, is unchanged. Owner approval and mandatory amendments supersede earlier discovery-only wording below.\n\nIndependent USERS/PROJECTS/AUDIT states, copied drafts and identity fencing, duplicate prevention, existing commands with per-step ACK/server-only field readback, conservative unknown-outcome holds, driver binding and owned AR/EN/UR responsive dialogs are implemented. SUPER_ADMIN-only commands and PROJECT_ADMIN read-only behavior remain. Backend/Rules/role policy/Workspace/Outbox/SQL/dependencies are unchanged. Frontend-only repository/client adaptations are bounded in the [amended contract](UI5_TARGET_DISCOVERY.md).\n\nBaseline 240/243 and candidate 288/291, native exits 1/1: same three pre-existing source-string expectation failures; aggregate NOT PASS, no additions or skips. All 48 new cases, final Edge 9/9, authenticated local emulator 1/1 and runtime audit 16/16 pass. TypeScript/lint/build exit 0. Separate original fourteen-failure UI4 history remains unchanged. No remote UI5 CI, device/screen-reader/live Workspace or product/Beta 2 acceptance claim.\n\n[Implementation/owner gate](UI5_ACCOUNT_REVIEW.md), [exact files](ui5/exact-file-inventory.json), [verification](ui5/verification.json). Scope 30 files: 8 production, 7 new tests/fixtures, 15 docs/evidence including seven inherited paths. All 22 protected worktrees and original RB4 nine dirty files/unpublished migration 013 preserved. Firestore remains authority. STOP at owner review: no staging/commit/push/PR/merge/deployment/SQL cutover/RB4/UI6; publication HOLD.\n\n",
 '05_DECISION_AND_DEBT_LOG.md':"## UI5 decisions and retained local debt — 2026-11-15\n\nOwner-authorized UI5 is ready for source review; [current ledger](02_PHASE_LEDGER.md) and [implementation/evidence](UI5_ACCOUNT_REVIEW.md) apply. Source failures never become confirmed empty data. ACK is distinct from server-only field readback. Role/project updates remain separate commands; partial/unknown outcomes never imply rollback or auto-replay. Generic server conflict errors remain unresolved; current-session unknown decisions fail closed. No durable receipt, idempotency protocol or combined endpoint was invented.\n\nAdditive server-only target read in existing UserRepository and optional observation/context callbacks in existing account client satisfy owner requirements without changing default reads, legacy client shapes, server authority or Rules. All historical tests are byte-unchanged. Baseline 240/243 vs final 288/291 retains exactly three pre-existing subscription-string failures, exit 1/1: NOT PASS. This is measured source-expectation debt, not an environmental excuse. No subscriptions or weakened assertions were added to obtain green. All 48 new cases, Edge 9/9, real local emulator 1/1, runtime 16/16 and lint/TypeScript/build pass.\n\nOriginal fourteen UI4 identities, connected red/green history and timestamps remain separate and unchanged. Earlier UI5 red iterations are retained. Devices, screen readers, live Workspace/operational and Beta 2 gates remain open. Firestore remains active; no SQL, dual writes, RB4, deployment or publication authorization.\n\n",
 'MASTER_PROJECT_HANDOFF.md':"## CURRENT HANDOFF — UI5 local owner source review — 2026-11-15\n\nFollow the [sole phase ledger](02_PHASE_LEDGER.md). Owner-authorized UI5 is implemented under [the amended preserved contract](UI5_TARGET_DISCOVERY.md); [implementation and exact verification](UI5_ACCOUNT_REVIEW.md) are ready for owner review. Review independent reads, stable identity/drafts, only existing privileged commands, duplicate guards, explicit server-only field readback, partial/conflict/unresolved feedback, driver binding and owned AR/EN/UR dialogs. Backend/Rules, UI1–UI4, Outbox/Workspace/SQL and canonical authority are preserved.\n\nScope 30 changed files (8 production / 7 new tests-fixtures / 15 docs-evidence), including the seven inherited documentation changes. Baseline 240/243 vs candidate 288/291 stays NOT PASS with the same three failures. All 48 new cases, Edge 9/9, real local Auth/Firestore/server 1/1, runtime 16/16 and TypeScript/lint/build pass. No remote UI5 CI or live/device/screen-reader/Beta 2 certification. All 22 protected worktrees and RB4/013 unchanged. STOP at owner review; no commit/push/PR/merge/deployment/SQL/RB4/UI6. Earlier handoffs remain historical.\n\n",
 'UI5_TARGET_DISCOVERY.md':"## UI5 execution outcome — local owner-review gate — 2026-11-15\n\nThe approved unit and owner amendments below have been implemented locally. [Implementation/evidence](UI5_ACCOUNT_REVIEW.md) records exact scope; the [phase ledger](02_PHASE_LEDGER.md) alone owns current state. Baseline 240/243 vs final 288/291 retains identical three inherited failures (NOT PASS). All 48 new cases, Edge 9/9, real authenticated emulator 1/1, runtime 16/16 and TypeScript/lint/build pass; no historical test or authority was weakened.\n\nThe bounded frontend exceptions are an explicit server-only target reader in the same UserRepository and optional context/failure observation in the existing account client. Ordinary reads/legacy shapes remain. Ambiguous generic server errors stay unresolved; no receipt authority, combined command or automatic replay was introduced. State-only reads do not certify unknown submission outcomes; local unknown decisions remain held in this review session.\n\nUI5 = IMPLEMENTED_LOCALLY / VERIFIED_WITH_INHERITED_DEBT / OWNER_REVIEW_PENDING. STOP at owner review; publication HOLD. All original proposal text, source comparison, timestamps and execution amendments below remain preserved. No UI6, commit/push/PR/merge/deployment/SQL/RB4.\n\n"
}
for name,header in headers.items():
 p=r/'docs/reconstruction'/name;p.write_bytes(header.encode('utf8')+p.read_bytes())
(d/'README.md').write_text("# UI5 local owner-review evidence\n\n[Implementation](../UI5_ACCOUNT_REVIEW.md), [verification](verification.json), [exact inventory](exact-file-inventory.json), [source/dependency preservation](source-contract.json), [failure identities](failure-comparison.json), [raw evidence](verification-raw.zip).\n\nMain 08f67b6046cc10e2ee6f3cd8387bcf7bffcaf551 unchanged; no staging or publication. Baseline 240/243 versus candidate 288/291, exits 1/1, same three failures: NOT PASS. All 48 new cases pass. Final Edge 9/9, authenticated loopback App 1/1, runtime 16/16 and lint/TypeScript/build exit 0. Original tests, server/Rules, shared XLSX and older fourteen-failure evidence remain unchanged.\n\nRaw archive retains original seven-document bytes, baseline/candidate/intermediate logs, frozen final source, initial/final browser images and owned emulator identities/cleanup. browser-final/ uses actual components with explicit synthetic presentation fixtures; owned-final/ uses real App/Auth/Firestore/server. Metadata/Git runtime warnings are retained, not live-provider proof. No device, screen-reader or production acceptance. GO to owner review with inherited debt; publication HOLD.\n",encoding='utf8')
archive=d/'verification-raw.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for folder,dirs,names in os.walk(o):
  dirs[:]=[n for n in dirs if n not in ['runner','__pycache__']]
  for name in sorted(names):
   p=Path(folder)/name
   if p.suffix.lower() in ['.json','.log','.txt','.mjs','.py','.ts','.tsx','.zip','.png','.pdf','.csv','.xlsx']:z.write(p,p.relative_to(o).as_posix())
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
verification={
 'SOURCE_PREFLIGHT':{'status':'PASS','head':pre['head'],'branch':g(r,'branch','--show-current'),'remoteMainVerifiedBeforeEdits':pre['head'],'inheritedSevenDocsVerifiedAndBackedUp':pre['inheritedSevenDocs'],'ownerAmendmentsIntegrated':True,'publicationAllowed':False},
 'EXACT_FILE_SCOPE':{'total':30,'production':8,'newTestsAndFixtures':7,'documentationAndEvidence':15,'inheritedDocumentation':7,'inventory':'exact-file-inventory.json'},
 'ROOT_CAUSE_MATRIX':causes,
 'ROLE_AND_AUTHORITY_PRESERVATION':{'superAdminCommandsOnly':True,'projectAdminReadOnly':True,'serverRulesAndCanonicalContractsUnchanged':True,'defaultRepositoryMethodsAndLegacyClientPreserved':True,'sourceContract':'source-contract.json'},
 'PARTIAL_READ_BEHAVIOR':'Independent USERS/PROJECTS/AUDIT, explicit error/old-view labeling, blocked evidence-dependent decisions, hidden audit reads retired.',
 'SELECTION_AND_DRAFT_FENCING':'Stable selected identity and copied drafts; actor/profile/context/target/request retirement; no late publication into a different person.',
 'COMMAND_ACK_READBACK_RESULTS':{'newCases':48,'allPass':True,'serverRead':'getDocFromServer via same repository/decoder/Rules, never cache fallback','comparison':'Relevant fields after every ACK, cumulative for sequences, project-set and cleared driver binding semantics','genericServerErrors':'Remain unresolved','noAutomaticReplay':True,'localUnknownHold':'Retained for revisited accounts within this actor review session; no durable journal claim.'},
 'DUPLICATE_AND_UNCERTAIN_OUTCOME_HANDLING':'Synchronous ref guard, pending disabled controls/owned dialogs, per-step ACKs; ACK/readback failure differs from rejection; state-only read cannot certify unknown submission.',
 'BROWSER_AR_EN_UR':{'result':counts(o/'browser-final.json'),'nativeExit':0,'engine':'Headless Microsoft Edge','locales':['ar','en','ur'],'widths':[390,768,1440],'fixtureBoundary':'Explicit synthetic presentation read/transport; actual components/I18nProvider/ImportOverlay','visualQA':read(o/'visual-qa.json')},
 'AUTHENTICATED_EMULATOR_RESULTS':{'result':counts(o/'owned-final/candidate-connected.json'),'nativeExit':0,'project':'demo-convergence2','ports':['127.0.0.1:8085','127.0.0.1:9099'],'actualAppAuthFirestoreServer':True,'syntheticOnly':True,'detail':read(o/'owned-final/connected/result.json'),'cleanup':cleanup,'earlierOwnedRun':'owned-r1 preserved as pre-refinement smoke, not final acceptance'},
 'BASELINE_CANDIDATE_FAILURE_IDENTITIES':comparison,
 'TYPECHECK_LINT_BUILD':{'commands':commands,'runtimeCommand':'npm run test:i18n-runtime','runtimeResult':'16/16 PASS / exit0','typecheckLint':'npm run lint executes tsc --noEmit / exit0','build':'Client/PWA/server exit0, existing chunk-size warning retained','sourceIdentity':'Final source hashes frozen before gates and independently read back afterwards'},
 'DOCUMENT_RECONCILIATION':{'status':'RECONCILED','owner':'docs/reconstruction/02_PHASE_LEDGER.md','record':'docs/reconstruction/UI5_ACCOUNT_REVIEW.md','historicalBodiesPreserved':True,'oldUi4RawArchivesAndManifestsUnchanged':True},
 'PROTECTED_WORKTREES':{'count':22,'allPreserved':True,'rb4OriginalNine':'RAW_HASHES_UNCHANGED','migration013':'UNTRACKED_UNPUBLISHED_UNCHANGED'},
 'FINAL_SOURCE_REVIEW_DECISION':'GO_TO_OWNER_SOURCE_REVIEW_WITH_INHERITED_NOT_PASS_DEBT; PUBLICATION_HOLD',
 'historicalEvidenceBoundary':{'oldUi4FourteenIdentities':'Unchanged and separate; original aggregate NOT_PASS','oldConnected16of17AndSeparate1of1':'Unchanged','earlyIterations':'Initial JSX/type errors and two added intermediate shape assertions retained; corrected without changing historical tests','productionDeviceScreenReaderLiveGoogleBeta2':'NOT_ACCEPTED','ui5RemoteCI':'NOT_RUN; publication unauthorized'},
 'rawArchiveSha256':sha(archive),'sourceFiles':source
}
write(d/'verification.json',verification)
files=sorted(set(g(r,'diff','--name-only','HEAD').splitlines()+g(r,'ls-files','--others','--exclude-standard').splitlines()+['docs/reconstruction/ui5/exact-file-inventory.json','docs/reconstruction/ui5/evidence-sha256.json']))
assert len(files)==30,(len(files),files)
classify=lambda f:'TEST_OR_FIXTURE' if f.startswith('src/tests/') else 'PRODUCTION' if f.startswith('src/') else 'DOCUMENTATION_OR_EVIDENCE'
classes=collections.Counter(classify(f) for f in files)
assert classes=={'PRODUCTION':8,'TEST_OR_FIXTURE':7,'DOCUMENTATION_OR_EVIDENCE':15},classes
assert all(f in scope['productionAllowlist'] for f in files if classify(f)=='PRODUCTION')
assert all(f in scope['testAllowlist'] for f in files if classify(f)=='TEST_OR_FIXTURE')
write(d/'exact-file-inventory.json',{'head':pre['head'],'branch':g(r,'branch','--show-current'),'counts':dict(classes),'total':30,'inheritedSevenDocs':list(pre['inheritedSevenDocs']),'files':[{'file':f,'classification':classify(f),'sha256':sha(r/f) if f.startswith('src/') else None} for f in files]})
for f,h in pre['inheritedSevenDocs'].items():
 original=(o/'before'/f).read_bytes()
 assert hashlib.sha256(original).hexdigest()==h and (r/f).read_bytes().endswith(original),f
links=[]
for f in files:
 p=r/f
 if p.suffix!='.md':continue
 text=p.read_text(encoding='utf8')
 if f in pre['inheritedSevenDocs']:
  original=(o/'before'/f).read_text(encoding='utf8');text=text[:text.find(original)] if original in text else text.split('\n## ',1)[0]
 for url in re.findall(r'\[[^\]]+\]\(([^)]+)\)',text):
  if url.startswith(('http://','https://','mailto:','#')):continue
  target=urllib.parse.unquote(url.split('#')[0]);assert (p.parent/target).exists(),(f,url);links.append({'source':f,'target':url})
tree=ast.parse((r.parent/'ui4-rb1-evidence-20261115/finalize.py').read_text(encoding='utf8'))
patterns=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='patterns' for t in n.targets))
findings=[];scanned=0
for f in files:
 p=r/f
 if p.exists() and p.suffix not in ['.zip','.png']:
  scanned+=1;findings.extend({'file':f,'rule':k} for k,pat in patterns.items() if re.search(pat,p.read_bytes()))
with zipfile.ZipFile(archive) as z:
 for n in z.namelist():
  if Path(n).suffix in ['.json','.log','.txt','.mjs','.py','.ts','.tsx','.csv']:
   scanned+=1;findings.extend({'file':'raw::'+n,'rule':k} for k,pat in patterns.items() if re.search(pat,z.read(n)))
assert not findings,findings
res=subprocess.run(['git','diff','--check'],capture_output=True,text=True);assert res.returncode==0,res.stdout+res.stderr
assert not g(r,'diff','--cached','--name-only')
write(d/'evidence-sha256.json',{'algorithm':'SHA256','scope':'Final 30-file local union; self excluded. Raw archive retains original seven document bodies and frozen verified source.','diffCheckNativeExit':0,'stagedFiles':0,'secretScan':{'status':'PASS','textFilesAndEntriesScanned':scanned,'findings':[],'fixtureCredentials':'Intentional synthetic/demo-only/example.invalid values, not real credentials.'},'docLinks':{'status':'PASS','checked':links},'files':{f:sha(r/f) for f in files if f!='docs/reconstruction/ui5/evidence-sha256.json'}})
write(o/'final-review-gate.json',{'status':'OWNER_REVIEW_ONLY','files':files,'counts':dict(classes),'sourceMatchesFinalGates':True,'protectedWorktrees':22,'allSevenOriginalDocBodiesPreserved':True,'secretScan':'PASS','docLinks':'PASS','diffCheckExit':0,'staged':0,'noPublication':True})
print('UI5_FINALIZED: 30 files / 8 production / 7 new tests / 15 docs-evidence; frozen source; same3 inherited failures; owner review only.')
