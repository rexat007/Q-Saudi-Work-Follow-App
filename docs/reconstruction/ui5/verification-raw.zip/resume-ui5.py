from pathlib import Path
import json,subprocess,hashlib,zipfile,os,shutil,ast,re,urllib.parse,collections
r=Path.cwd();o=r.parent/'ui5-evidence-20261115';d=r/'docs/reconstruction/ui5'
read=lambda p:json.loads(p.read_text(encoding='utf8'))
write=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def g(folder,*a):return subprocess.check_output(['git','-c','safe.directory='+str(folder),'-C',str(folder),*a],encoding='utf8').rstrip()
pre=read(o/'preflight.json');scope=read(o/'scope-audit.json')
gateSource=read(o/'final-source-hashes.json');source=dict(gateSource)
change=read(o/'format-reconciliation/change.json');tokens=read(o/'format-reconciliation/token-equivalence.json')
assert tokens['status']=='PASS' and tokens['identical']
assert change['beforeSha256']==gateSource[change['file']] and change['afterSha256']==sha(r/change['file'])
source[change['file']]=change['afterSha256']
assert all(sha(r/f)==h for f,h in source.items())
write(o/'format-reconciliation/source-hashes-after-format.json',source)
shutil.copy2(r/change['file'],o/'final-source'/change['file'])
contract=read(d/'source-contract.json')
contract['gateSourceFiles']=gateSource;contract['sourceFiles']=source;contract['postGateWhitespaceReconciliation']={'change':change,'tokenEquivalence':tokens}
write(d/'source-contract.json',contract)
shutil.copy2(o/'source-contract-final.json',o/'format-reconciliation/source-contract-before-format.json')
write(o/'source-contract-final.json',contract)
p=r/'docs/reconstruction/UI5_ACCOUNT_REVIEW.md';text=p.read_text(encoding='utf8')
text=text.replace('Production/test hashes were frozen before final gates and checked afterwards.','Tested production/test hashes are retained. Final diff checking removed only one trailing space from the edited repository import after gates; the TypeScript scanner verified identical non-trivia tokens. Current and tested hashes are explicitly reconciled, with no semantic test rerun for formatting.')
p.write_text(text,encoding='utf8')
verification=read(d/'verification.json')
verification['gateSourceFiles']=gateSource;verification['sourceFiles']=source
verification['postGateWhitespaceReconciliation']={'change':change,'tokenEquivalence':tokens}
verification['TYPECHECK_LINT_BUILD']['sourceIdentity']='Tested hashes retained; final import trailing-space-only correction has independently identical TypeScript tokens. Current hashes are reconciled explicitly, not claimed byte-identical to pre-format gates.'
archive=d/'verification-raw.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for folder,dirs,names in os.walk(o):
  dirs[:]=[n for n in dirs if n not in ['runner','__pycache__']]
  for name in sorted(names):
   p=Path(folder)/name
   if p.suffix.lower() in ['.json','.log','.txt','.mjs','.cjs','.py','.ts','.tsx','.zip','.png','.pdf','.csv','.xlsx','.md']:z.write(p,p.relative_to(o).as_posix())
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
verification['rawArchiveSha256']=sha(archive);write(d/'verification.json',verification)
code=(o/'finalize-ui5.py').read_text(encoding='utf8')
exec(compile(code[code.index('files=sorted('):],str(o/'finalize-ui5.py')+'::resume','exec'))
