from pathlib import Path
import ast, datetime, hashlib, json, os, re, subprocess, urllib.parse, zipfile

r=Path.cwd();o=r.parent/'ui5-ir01-evidence-20261121';d=r/'docs/reconstruction/ui5'
j=lambda p:json.loads(p.read_text(encoding='utf8'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def g(folder,*a):return subprocess.check_output(['git','-c','safe.directory='+str(folder),'-C',str(folder),*a],text=True,stderr=subprocess.PIPE).rstrip()
def counts(p):return {k:j(p)[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']}
def failures(p):return sorted((Path(t['name']).name,a['fullName']) for t in j(p)['testResults'] for a in t['assertionResults'] if a['status']=='failed')
pre=j(o/'preflight.json');source=j(o/'source-final.json');red=j(o/'red-source-proof.json');commands=j(o/'command-exits.json')
assert g(r,'rev-parse','HEAD')==pre['head']==g(r,'rev-parse','@{upstream}')
assert g(r,'branch','--show-current')==pre['branch'] and not g(r,'diff','--cached','--name-only')
assert [c['status'] for c in commands]==[1,0,0,0]
assert counts(o/'red.json')==dict(numTotalTests=10,numPassedTests=6,numFailedTests=4,numPendingTests=0)
assert counts(o/'green.json')==dict(numTotalTests=10,numPassedTests=10,numFailedTests=0,numPendingTests=0)
assert counts(o/'affected-final.json')==dict(numTotalTests=329,numPassedTests=326,numFailedTests=3,numPendingTests=0)
assert failures(o/'affected-final.json')==failures(r.parent/'ui5-publication-20261120/affected.json')
assert all(sha((r/f).read_bytes())==h for f,h in source.items())
test='src/tests/ui5Ir01DecisionAdmission.test.tsx';production='src/components/admin/AdminConsoleView.tsx'
assert source[test]==red['newTestSha256']
before=(o/'before'/production).read_text(encoding='utf8');after=(r/production).read_text(encoding='utf8')
insertion="    // Selection state may still be scheduled; admit no command for a synchronously held target.\n    if(uncertain.current.get(targetId)?.status==='unresolved')return;\n"
assert after.count(insertion)==1 and after.replace(insertion,'',1)==before
old_ui5={'ui5AccountReview.test.tsx','ui5AccountReadback.test.ts','ui5AccountTransport.test.ts','ui5Pub01Retirement.test.tsx'}
results=j(o/'affected-final.json')['testResults']
old_cases=[a for t in results if Path(t['name']).name in old_ui5 for a in t['assertionResults']]
assert len(old_cases)==76 and all(a['status']=='passed' for a in old_cases)
pub01=[a for t in results if Path(t['name']).name=='ui5Pub01Retirement.test.tsx' for a in t['assertionResults']]
assert len(pub01)==27 and all(a['status']=='passed' for a in pub01)
changed=[production,test,'docs/reconstruction/02_PHASE_LEDGER.md','docs/reconstruction/UI5_ACCOUNT_REVIEW.md','docs/reconstruction/UI5_IR01_DECISION_ADMISSION.md','docs/reconstruction/ui5/ir01-verification.json','docs/reconstruction/ui5/ir01-raw.zip']
modified=[production,'docs/reconstruction/02_PHASE_LEDGER.md','docs/reconstruction/UI5_ACCOUNT_REVIEW.md']

# Retain all published source/test/evidence bytes outside the exact three modified paths.
assert all(sha((r/f).read_bytes())==h for f,h in pre['trackedHashes'].items() if f not in modified)
legacy=j(r.parent/'ui5-evidence-20261115/preflight.json');protected=[]
for w in legacy['protected']:
 p=Path(w['folder']);assert g(p,'rev-parse','HEAD')==w['head'] and g(p,'status','--porcelain=v1','--untracked-files=all')==w['status']
 assert all(sha((p/f).read_bytes())==h for f,h in w['hashes'].items());protected.append({'folder':w['folder'],'HEADStatusDirtyHashes':'UNCHANGED'})
assert len(protected)==22
write(o/'preservation.json',{'protected':protected,'rb4NineMigration013':'UNCHANGED_UNPUBLISHED','publishedSourceOutsideAdminConsole':'UNCHANGED','allExistingTestsAndArchives':'BYTE_UNCHANGED','exactProductionDiff':'Two added lines only; existing authorization leases/transport/readback/server/Rules untouched','noCommitPush':True})

canonical={}
for f,h in source.items():
 raw=(r/f).read_bytes();blob=g(r,'hash-object','--path='+f,f)
 for data in [raw,raw.replace(b'\r\n',b'\n')]:
  expected=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
  if expected==blob:canonical[f]={'workspaceSha256':h,'gitBlobSha1':blob,'canonicalSha256':sha(data)};break
 else:raise AssertionError(('Unexpected content filter',f))
source_digest=sha(json.dumps({f:v['canonicalSha256'] for f,v in canonical.items()},sort_keys=True,separators=(',',':')).encode('utf8'))
paths_audit=[
 {'path':'Suspend/Reactivate row actions','before':'chooseUser(target) then decide in one event; render canDecide may describe A while target ref/map already describe B','after':'Central synchronous map lookup rejects unresolved B before token or HTTP'},
 {'path':'Approval/rejection','review':'Row events select/open a modal, not send; confirmation also uses decide and now receives the same target guard'},
 {'path':'Role/project access','review':'handleSaveSecurityPolicy routes its independent command sequence through decide; existing lease, lock, ACK/readback and partial semantics unchanged'},
 {'path':'Driver binding','review':'bindingDecision routes through decide; existing child lock, canonical driver identity and parent authorization lease preserved'},
 {'path':'Explicit state-only review','review':'Reads existing authoritative reader; does not clear uncertain map, certify original unknown transmission or issue/replay a command'},
]
report={
 'status':'UI5_IR01_CORRECTED_LOCALLY_AWAITING_OWNER_REVIEW',
 'publishedHead':pre['head'],'localHead':g(r,'rev-parse','HEAD'),'branch':pre['branch'],'PR106':'Draft / HOLD; unchanged remote head; no commit or push authorized for this correction',
 'rootCause':'chooseUser schedules outcome state but synchronously changes selection. decide previously admitted from safe A render canDecide while returning B already had an unresolved entry in uncertain.current.',
 'correction':'Synchronous uncertain.current.get(targetId)?.status === unresolved guard at the common decide admission boundary, before existing render/lifetime/lock/prerequisite checks and before token/HTTP. No other production behavior or authority changed.',
 'exactChangedPaths':changed,'modifiedTrackedPaths':modified,'addedPaths':[p for p in changed if p not in modified],
 'redBeforeProductionEdit':{'counts':counts(o/'red.json'),'nativeExit':1,'sourceSha256':red['productionSha256BeforeCorrection'],'failureIdentities':red['failureIdentities'],'observed':'Both lifecycle return paths and state-read variants sent2 actual B POSTs, expected1; six positive controls passed.'},
 'greenSameUnmodifiedTest':{'counts':counts(o/'green.json'),'nativeExit':0,'testSha256':red['newTestSha256'],'observed':'B receives only the initial POST; zero additional fetch/HTTP on return. Safe A remains available; confirmed/rejected outcomes permit legitimate new decisions.'},
 'testExecutionBoundary':'Actual AdminConsoleView and unmocked production command service/token/error/readback orchestration. Only relative URL resolution bridges fetch to a loopback HTTP fixture. Counts are checked both before real fetch and on the receiving server; the first unknown B request has its connection destroyed without ACK. Auth/read models and backend replies are synthetic; this is not an Admin SDK/Firebase production acceptance claim.',
 'sameEventPathReview':paths_audit,
 'affectedSuite':{'publishedHistoricalCounts':{'passed':316,'total':319,'failed':3,'aggregate':'NOT_PASS'},'currentCounts':counts(o/'affected-final.json'),'nativeExit':1,'sameThreeInheritedFailureIdentities':failures(o/'affected-final.json'),'newIR01Cases':10,'newIR01Failures':0,'existingUI5Cases':76,'existingUI5Passed':76,'PUB01Cases':27,'PUB01Passed':27,'skipped':0,'aggregate':'NOT_PASS'},
 'runtimeI18n':'npm run test:i18n-runtime:16/16 PASS, native0','typecheckLint':'npm run lint / tsc --noEmit:PASS native0','build':'Production client/PWA/server:PASS native0; existing chunk-size warning retained','commands':commands,
 'sourceIdentity':{'allCodeEditsBeforeFinalGates':True,'publishedHeadUnchanged':pre['head'],'correctedSourceFile':production,'correctedWorkspaceSha256':source[production],'correctedSourceGitBlobSha1':canonical[production]['gitBlobSha1'],'correctedCanonicalSha256':canonical[production]['canonicalSha256'],'UI5FamilyCandidateSha256':source_digest,'digestDefinition':'SHA256 of sorted compact JSON path -> canonicalSha256 for17 UI5 source/test paths; not a Git commit SHA','files':canonical},
 'historyPreservation':'Published316/319 NOT_PASS record, original three identities, original IR01 red4/10, PUB01 original red->green, existing76/27 coverage, earlier14 UI4 non-green identities and original archives preserved unchanged. New10 cases and current326/329 are separately identified.',
 'protectedWorktrees':{'count':22,'proof':'HEAD/status/raw dirty hashes unchanged','rb4NineAndMigration013':'UNCHANGED_UNPUBLISHED'},
 'remoteCI':'Existing44699706777 SUCCESS belongs to published a38c305 only; no CI run for this unpublished correction; no reuse as new CI PASS',
 'browserEmulatorBoundary':'Published9/9 and1/1 remain historical evidence; not rerun or claimed as IR01 final-source results. IR01 verifies real local HTTP and the requested automated gates.',
 'publication':{'commit':False,'push':False,'PRMutation':False,'merge':False,'deployment':False,'SQL':False,'RB4':False,'UI6':False,'FirestoreRulesOrServerChanges':False},
 'ownerGate':'HOLD: owner review of corrected source and red-to-green evidence required before any corrective commit or push',
}
write(o/'owner-review-verification.json',report)

record='''# UI5 IR-01 — Synchronous unresolved-target decision admission

## Current local owner-review gate — 2026-11-21

UI5_IR01_CORRECTED_LOCALLY_AWAITING_OWNER_REVIEW. PR106 remains Draft/HOLD on published head `a38c305202a4365a293e8f54afbb4e9a7bc28c49`. This correction is uncommitted and unpublished. No commit, push, PR mutation, merge, deployment, SQL, Rules/server redesign, RB4 or UI6 action is authorized/performed here. The published CI44699706777 success is historical evidence for a38c305, not CI acceptance of this local correction.

## Exact failure and correction

`chooseUser(target)` changes selection refs immediately but schedules outcome state. The direct suspend/reactivate handlers then call `decide` within the same event, using the previous safe-A render's `canDecide`. Thus returning to unresolved B could submit another command before B's queued outcome is rendered.

Before production editing, the new real-component/production-transport family reported6/10 PASS and4/10 FAIL. Both Suspend and Reactivate, with and without a prior state-only read, delivered2 actual loopback POSTs to B instead of1. The production file was byte-identical to the published head during that red run. Six controls verified unrelated eligible A and confirmed/rejected B outcomes.

The sole production change is a synchronous target-specific unresolved check at the shared `decide` admission boundary. It reads `uncertain.current.get(targetId)?.status` before any new operation can acquire a token or submit HTTP. No flush, delayed retry, map clearing, global hold or authorization redesign was introduced. Existing render prerequisites, permanent authorization generation/mount lease, target generation, duplicate guard, ACK/server-readback and partial/unknown semantics remain intact.

The exact same test bytes now report10/10 PASS: the returning held B issues zero additional HTTP commands, unrelated A remains usable, confirmed/rejected outcomes allow new legitimate decisions, and an explicit state-only read neither replays nor unlocks an unknown command. The network fixture deliberately drops the first B response; its socket-reset messages are preserved raw and are expected unknown-outcome evidence, not hidden failures.

## Decision-path review

- Suspend/reactivate select and decide in one event; the new central guard directly closes this race.
- Approval/rejection row events select/open a modal; confirmations also pass through the same admission guard.
- Role/project updates and driver binding both route through `decide`; their existing leases, locks, independently authoritative commands and server protections are unchanged.
- Explicit state-only review calls the existing server reader, never the command service. It does not clear the unresolved-target map or certify the unknown submission.
- The hold remains the existing review-session UI safeguard, not a new durable idempotency or canonical authorization authority.

## Verification and historical debt

Current affected suite326/329, native1, retains exactly the three published subscription-string failures. The historical316/319 NOT_PASS result is unchanged; the new10 cases are identified separately. Existing UI5 coverage76/76 and PUB01 coverage27/27 remain passing, with zero old-test/assertion edits or skips. Runtime i18n16/16, TypeScript/lint and production client/PWA/server build pass. No new confirmed source regression remains in these gates; broad aggregate is still NOT PASS.

Tests use actual AdminConsoleView and the unmocked production command service. The relative fetch URL is resolved to an owned loopback fixture and real POSTs are counted at both fetch and receiving server. Identity/read fixtures and backend responses are synthetic; no new Firebase, live-provider, physical-device or screen-reader acceptance is claimed. Published browser9/9, emulator1/1 and CI success remain historical, not relabeled as fresh IR01 results.

Exact red/green identities, native exits/timestamps, preserved failure identities, code hashes and seven-path local inventory are in [IR01 verification](ui5/ir01-verification.json); [raw evidence](ui5/ir01-raw.zip) preserves both runs, source-before/source-after, final gate logs and worktree preservation proof. Original published verification, inventory, seals and raw archives remain unchanged and describe the published a38c305 baseline; the IR01 manifest owns this unpublished delta.

All22 protected HEAD/status/dirty hashes, RB4 original nine files and unpublished migration013 remain unchanged. Server, Firestore Rules, command schema/routes, permanent leases, all pre-existing tests and historical evidence are preserved.

## Source identity and owner stop

The Git HEAD remains `a38c305202a4365a293e8f54afbb4e9a7bc28c49`; no corrected commit exists. Corrected AdminConsoleView workspace SHA256: `'''+source[production]+'''`. Corrected source Git blob SHA1: `'''+canonical[production]['gitBlobSha1']+'''`. These are source fingerprints, not a new commit or remote publication identity.

HOLD for owner review of the corrected source and red-to-green evidence before any commit/push. UI4 remains source-closed; UI6 not started. Operational/product/Beta2 acceptance remains separate.
'''
(r/'docs/reconstruction/UI5_IR01_DECISION_ADMISSION.md').write_text(record,encoding='utf8')
header='''## CURRENT UI5 IR-01 LOCAL CORRECTION — 2026-11-21

UI5_IR01_CORRECTED_LOCALLY_AWAITING_OWNER_REVIEW. PR106 remains Draft/HOLD on published a38c305202a4365a293e8f54afbb4e9a7bc28c49. The synchronous target-specific unresolved admission guard is corrected locally; no commit or push is authorized before owner review. [IR01 correction/evidence](UI5_IR01_DECISION_ADMISSION.md) records the exact real-component/HTTP red4/10 -> green10/10, preserved existing UI5 76/76 and PUB01 27/27, current affected326/329 with the same three inherited failures (NOT PASS), runtime16/16 and TypeScript/lint/build PASS. Published316/319 and original raw archives remain unchanged. Published CI success certifies the old head only. Seven local changed paths are enumerated in the new IR01 manifest. Protected22/RB4 nine/migration013 preserved; UI4 source-closed, UI6 not started. Earlier publication authorization and evidence below are historical and do not authorize publishing this correction.

'''
for f in ['docs/reconstruction/02_PHASE_LEDGER.md','docs/reconstruction/UI5_ACCOUNT_REVIEW.md']:(r/f).write_bytes(header.encode('utf8')+(o/'before'/f).read_bytes())

archive=d/'ir01-raw.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for folder,dirs,names in os.walk(o):
  dirs[:]=[x for x in dirs if x not in ['node_modules','runner','__pycache__']]
  for name in sorted(names):
   p=Path(folder)/name
   if p.suffix.lower() in ['.json','.log','.txt','.mjs','.py','.ts','.tsx','.md']:z.write(p,p.relative_to(o).as_posix())
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
report['rawArchiveSha256']=sha(archive.read_bytes());report['rawArchive']='ir01-raw.zip'
report['changedPathWorkspaceHashes']={f:sha((r/f).read_bytes()) for f in changed if f!='docs/reconstruction/ui5/ir01-verification.json'}
write(d/'ir01-verification.json',report)
actual=set(g(r,'diff','--name-only','HEAD').splitlines()+g(r,'ls-files','--others','--exclude-standard').splitlines())
assert actual==set(changed) and len(actual)==7,sorted(actual)
assert all(sha((r/f).read_bytes())==h for f,h in pre['trackedHashes'].items() if f not in modified)
assert all(sha((r/f).read_bytes())==h for f,h in source.items())
assert subprocess.run(['git','diff','--check'],capture_output=True).returncode==0
assert not g(r,'diff','--cached','--name-only')

tree=ast.parse((r.parent/'ui4-rb1-evidence-20261115/finalize.py').read_text(encoding='utf8'))
patterns=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='patterns' for t in n.targets))
findings=[]
for f in changed:
 if Path(f).suffix!='.zip':findings.extend({'path':f,'rule':k} for k,p in patterns.items() if re.search(p,(r/f).read_bytes()))
with zipfile.ZipFile(archive) as z:
 for name in z.namelist():
  if Path(name).suffix in ['.json','.log','.txt','.mjs','.py','.ts','.tsx','.md']:findings.extend({'path':'ir01-raw::'+name,'rule':k} for k,p in patterns.items() if re.search(p,z.read(name)))
assert not findings,findings
links=[]
for f in ['docs/reconstruction/02_PHASE_LEDGER.md','docs/reconstruction/UI5_ACCOUNT_REVIEW.md','docs/reconstruction/UI5_IR01_DECISION_ADMISSION.md']:
 body=(r/f).read_bytes();old=o/'before'/f
 if old.exists():assert body.endswith(old.read_bytes());body=body[:-len(old.read_bytes())]
 for url in re.findall(r'\[[^\]]+\]\(([^)]+)\)',body.decode('utf8')):
  if url.startswith(('https://','http://','mailto:','#')):continue
  assert ((r/f).parent/urllib.parse.unquote(url.split('#')[0])).exists();links.append({'source':f,'target':url})
report['integrityChecks']={'secretScan':'PASS','docLinks':links,'diffCheckNativeExit':0,'stagedFiles':0,'manifestSelfHashExcluded':True}
write(d/'ir01-verification.json',report)
write(o/'final-owner-review-gate.json',{'status':report['status'],'changedPaths':sorted(actual),'sourceGitBlobSHA1':canonical[production]['gitBlobSha1'],'sourceSha256':source[production],'sourceCandidateSha256':source_digest,'headUnchanged':pre['head'],'originalRedPreserved':True,'sameTestSha256':source[test],'protected22':True,'oldTestAndEvidenceHashesUnchanged':True,'diffCheck':0,'secretScan':'PASS','docLinks':links,'staged':0,'commitPush':False})
print('IR01_FINALIZED: exact7 paths; red4FAIL/6PASS -> green10PASS; old76/PUB0127 retained; affected326/329 same3 NOT_PASS; no commit/push; owner review only.')
