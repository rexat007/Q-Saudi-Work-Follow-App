from pathlib import Path
import ast, collections, datetime, hashlib, json, os, re, shutil, subprocess, zipfile, urllib.parse

r=Path.cwd();o=r.parent/'ui5-pub01-evidence-20261116';d=r/'docs/reconstruction/ui5'
read=lambda p:json.loads(p.read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def git(folder,*a):return subprocess.check_output(['git','-c','safe.directory='+str(folder),'-C',str(folder),*a],text=True).rstrip()
def counts(p):return {k:read(p)[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']}
def failures(p):return sorted((Path(t['name']).name,a['fullName']) for t in read(p)['testResults'] for a in t['assertionResults'] if a['status']=='failed')

before=read(o/'before.json');pre=read(r.parent/'ui5-evidence-20261115/preflight.json');source=read(o/'source-final.json')
assert git(r,'rev-parse','HEAD')==before['head'] and git(r,'branch','--show-current')==before['branch']
assert all(sha(r/f)==h for f,h in source.items())
initial_gate_source=read(o/'source-before-connected-fixture-correction.json')
assert [f for f in source if source[f]!=initial_gate_source[f]]==['src/tests/ui5AccountConnectedJourney.test.ts']
commands=read(o/'command-exits.json');assert [c['status'] for c in commands]==[1,0,0,0,0]
latest_types=read(o/'lint-after-fixture-exit.json');assert latest_types['status']==0
assert counts(o/'red-original.json')['numFailedTests']==1
assert counts(o/'green-original.json')['numPassedTests']==1
assert counts(o/'affected-final.json')==dict(numTotalTests=319,numPassedTests=316,numFailedTests=3,numPendingTests=0)
assert counts(o/'browser-final.json')['numPassedTests']==9
assert counts(o/'owned-verified/candidate-connected.json')['numPassedTests']==1
cleanup=read(o/'owned-verified/ui3-connected-connected-browser-exit.json')
assert cleanup['status']==0 and not cleanup['cleanupErrors'] and not cleanup['remainingListeners']
connected=read(o/'owned-verified/connected/result.json')
assert connected['authorizationRetirement']['httpCommands']==['changeUserRole']
assert connected['authorizationRetirement']['subsequentProjectRequests']==0
baseline=r.parent/'ui5-evidence-20261115/baseline.json'
assert failures(baseline)==failures(o/'affected-final.json') and len(failures(baseline))==3
assert len([a for t in read(o/'affected-final.json')['testResults'] if Path(t['name']).name.startswith('ui5') for a in t['assertionResults'] if a['status']=='passed'])==76

protected=[]
for w in pre['protected']:
 p=Path(w['folder']);assert git(p,'rev-parse','HEAD')==w['head']
 assert git(p,'status','--porcelain=v1','--untracked-files=all')==w['status']
 assert all(sha(p/f)==h for f,h in w['hashes'].items())
 protected.append({'folder':w['folder'],'headStatusDirtyHashes':'UNCHANGED'})
assert len(protected)==22
old_audit=r.parent/'ui5-publication-audit-20261115'
for f,h in before['originalAuditFiles'].items():
 assert sha(old_audit/f)==h
 target=o/'publication-audit-original'/f;target.parent.mkdir(exist_ok=True);shutil.copy2(old_audit/f,target)
assert (r/'src/tests/ui5AccountReview.test.tsx').read_bytes().startswith((o/'before/src/tests/ui5AccountReview.test.tsx').read_bytes())
original_case=(old_audit/'retirement.test.tsx').read_text(encoding='utf8').split("it('publication gate:",1)[1]
assert (r/'src/tests/ui5AccountReview.test.tsx').read_text(encoding='utf8').split("it('publication gate:",1)[1]==original_case
for line in (o/'before/src/tests/ui5AccountConnectedJourney.test.ts').read_text(encoding='utf8').splitlines():
 if 'expect(' in line:assert line in (r/'src/tests/ui5AccountConnectedJourney.test.ts').read_text(encoding='utf8')
unchanged={f:h for f,h in pre['existingSources'].items() if f not in source}
assert all(sha(r/f)==h for f,h in unchanged.items())
assert all(sha(r/f)==h for f,h in pre['protectedRootFiles'].items())
assert sha(r/'src/services/adminAccountClient.service.ts')==before['beforePaths']['src/services/adminAccountClient.service.ts']
assert sha(r/'docs/reconstruction/ui5/verification-raw.zip')==before['beforePaths']['docs/reconstruction/ui5/verification-raw.zip']

comparison=read(o/'before/docs/reconstruction/ui5/failure-comparison.json')
comparison['originalUI5Candidate']=comparison['candidate'];comparison['candidate']=counts(o/'affected-final.json')
comparison['newUI5Cases']=76;comparison['publicationRetirementCase']={'historicalAudit':'1/1 FAIL','preCorrectionReproduction':'1/1 FAIL','unchangedOriginalAfterCorrection':'1/1 PASS','copiedCaseInAffectedFamily':'1/1 PASS; separately identified, not historical debt','assertionsChanged':False}
comparison['pub01NewBoundaryCases']={'total':27,'passed':27,'fixtureCorrections':'Two initial new-test fixture errors retained in focused-r1; correct rejection button label and retain old draft while asserting committed server-role effect.'}
comparison['aggregate']='NOT_PASS';comparison['noNewFailureIdentities']=True
write(d/'failure-comparison.json',comparison)

boundaries=[
 {'boundary':'Initiation','guard':'decide/reviewReadback capture the current immutable workspace lifetime and authorization generation; synchronous command lock'},
 {'boundary':'After token / immediately before HTTP','guard':'Existing executeAdminAccountCommand checks captured isCurrent and UID after getIdToken, immediately before fetch; service bytes unchanged'},
 {'boundary':'ACK and error','guard':'runAccountDecision checks the captured operation after execute resolves or rejects; late responses do not publish state'},
 {'boundary':'Next command','guard':'Every iteration checks the same captured lease; retired role change cannot dispatch replaceAssignedProjects'},
 {'boundary':'Authoritative readback','guard':'Explicit checks before read, after read, before onRead via caller, and after onRead; manual review also captures lifetime and target generation'},
 {'boundary':'UI publication','guard':'onRead/outcome/banner/drafts guarded by current operation; pending-flag cleanup only in the captured live workspace'},
 {'boundary':'Independent sources','guard':'USERS/PROJECTS/AUDIT capture lifetime plus request sequence before await and verify both before publishing'},
 {'boundary':'Unmount/StrictMode/target switching','guard':'Layout cleanup permanently retires its own lease; replay creates a new lease. Target generation increments on every identity switch, including X-Y-X.'},
]
report={
 'UI5_PUB01_ROOT_CAUSE':'A reusable role/actor/scope string and resettable parent alive flag could restore an old unmounted workspace after A-B-A.',
 'EXACT_CHANGED_FILES':{'before':30,'after':33,'production':8,'testsAndFixtures':8,'documentationAndEvidence':17,'pub01ProductionDelta':['src/components/admin/AdminConsoleView.tsx','src/components/admin/adminDecisionReadback.ts'],'addedPaths':['src/tests/ui5Pub01Retirement.test.tsx','docs/reconstruction/UI5_PUB01_RETIREMENT.md','docs/reconstruction/ui5/pub01-raw.zip']},
 'AUTHORIZATION_LEASE_INVARIANT':{'status':'PASS','definition':'Once retired, an operation lease never becomes current again.','generation':'Replace the authorization identity object and increment its generation when any effective key input changes; never compare only reusable values.','lifetime':'Each mounted workspace creates a lifetime object; cleanup only changes retired false->true. Each async operation captures that object, never a later replacement.','target':'Captured stable identity and target generation remain mandatory; no global authorization authority added.'},
 'A_B_A_RETIREMENT_RESULTS':{'boundaryCases':27,'passed':27,'covered':['role','authenticated UID','profile authority','account status','project scope','target X-Y-X','token','ACK','readback','unmount/remount','StrictMode','late source/error publication','duplicates','all existing lifecycle and driver commands','uninterrupted completion']},
 'TOKEN_HTTP_BOUNDARY_RESULTS':{'clientServiceUnchanged':True,'transport':'Real production command service, token await and response parsing; intercepted fetch call counts, not mocked execute success indicators.','retiredTokenHttpRequests':0,'retiredAckOrReadbackHttpCommands':['changeUserRole'],'retiredSubsequentProjectRequests':0,'uninterruptedHttpOrder':['changeUserRole','replaceAssignedProjects'],'emulator':'Genuine authenticated HTTP plus canonical Firestore effects verified separately.'},
 'ACK_AND_READBACK_FENCING':boundaries,
 'SEQUENTIAL_COMMAND_INTEGRITY':{'status':'PASS','firstTransmittedCommand':'May really commit; never described as rolled back/cancelled','subsequentProjectRequestsAfterRetirement':0,'oldPendingOutcomeOrDraftInNewWorkspace':False,'noAutomaticReplayOrCompensation':True,'canonicalEmulatorResult':connected['authorizationRetirement']},
 'AUTHORITY_PRESERVATION':{'serverRulesCommandsAndCanonicalAuthority':'UNCHANGED','projectAdminReadOnlySuperAdminCommands':'PRESERVED','selfLastAdminDriverUniqueness':'Server-owned, rerun authority regressions and authenticated journey','newEndpointsPrivilegesGlobalState':False},
 'RED_TO_GREEN_REGRESSION':{'originalExternalTestSha256':before['originalAuditFiles']['retirement.test.tsx'],'originalAssertionsUnchanged':True,'red':counts(o/'red-original.json'),'redNativeExit':1,'green':counts(o/'green-original.json'),'greenNativeExit':0,'originalFailedAuditPreserved':True,'copyInExistingComponentTests':'Exact original case and assertions retained; one appended case identified separately'},
 'AFFECTED_SUITE_RESULTS':{'counts':counts(o/'affected-final.json'),'nativeExit':1,'all76UI5CasesPass':True,'originalUI5Cases':48,'originalRetirementCopy':1,'newBoundaryCases':27,'aggregate':'NOT_PASS','commands':commands},
 'BROWSER_AND_EMULATOR_RESULTS':{'browser':counts(o/'browser-final.json'),'browserNativeExit':0,'engine':'Headless native Edge','locales':['ar','en','ur'],'widths':[390,768,1440],'browserBoundary':'Actual components with explicit presentation fixture, keyboard/focus/Escape/native checkbox/action disabling; fresh run on final production source','emulator':counts(o/'owned-verified/candidate-connected.json'),'emulatorNativeExit':0,'emulatorBoundary':'Actual App/AuthProvider/Firestore SDK/Rules/server commands; owned demo-convergence2 synthetic fixtures and loopback-only browser requests','canonicalDetail':connected,'cleanup':cleanup,'physicalDeviceScreenReaderLiveProviderBeta2Accepted':False,'initialAttempt':'owned-final retained: self-row fixture collision before new retirement scenario; seed placement corrected without changing original assertion'},
 'TYPECHECK_I18N_BUILD':{'runtimeCommand':'npm run test:i18n-runtime','runtime':'16/16 PASS / native0','typecheckLint':'npm run lint / tsc --noEmit / native0','productionBuild':'Client/PWA/server native0; existing chunk-size warning retained','allProductionEditsBeforeGates':True,'connectedOnlyFixtureReconciliation':read(o/'connected-fixture-reconciliation.json'),'typecheckAfterFinalFixtureEdit':latest_types,'sourceSha256':source},
 'HISTORICAL_FAILURE_RECONCILIATION':comparison,
 'PROTECTED_WORKTREES':{'count':22,'worktrees':protected,'rb4NineAndMigration013':'UNCHANGED_UNPUBLISHED'},
 'FINAL_PUBLICATION_READINESS_DECISION':'UI5-PUB-01_CORRECTED_LOCALLY / READY_FOR_OWNER_REVIEW / PUBLICATION_NOT_AUTHORIZED',
 'remainingAcceptanceDebt':['Three inherited source-string subscription expectation failures: affected aggregate NOT PASS','Original UI4 fourteen-failure history remains separately NOT_PASS','Independent owner/source/publication review','Physical devices, screen reader and real operational/provider acceptance','Product/Beta2 release authorization'],
 'publication':{'staged':0,'commit':False,'push':False,'PR':False,'merge':False,'deployment':False,'SQL':False,'RB4':False,'UI6':False},
 'historicalAttempts':'Original red audit and reproduction unchanged; focused-r1 74/76 retained with two new-test fixture corrections; owned-final initial self-row fixture failure retained, corrected by deferring new target seeding with assertions unchanged; blocked pre-execution approval attempt was not counted as a test; work resumed on 2026-11-20 without replaying unaffected completed gates.'
}
write(o/'pub01-verification.json',report)
write(o/'final-source-preservation.json',{'source':source,'protected':protected,'originalAuditHashes':before['originalAuditFiles'],'oldUi5ArchiveUnchanged':True,'originalUI5TestsRetained':True,'allOriginalMainTestsAndBackendUnchanged':True})

record='''# UI5-PUB-01 — Permanent authorization context retirement

## Current source review — 2026-11-20

UI5-PUB-01 is corrected locally and ready for OWNER REVIEW. UI5 remains SOURCE_IMPLEMENTED / OWNER_REVIEW_PENDING; publication is NOT authorized. UI4 remains MERGED / SOURCE_CLOSED. Main/HEAD remains `08f67b6046cc10e2ee6f3cd8387bcf7bffcaf551`. No commit, push, PR, merge, deployment, SQL, RB4 or UI6 action occurred.

The original publication audit HOLD is preserved unchanged, including its failing test/assertions, logs and SHA seal, inside [new raw evidence](ui5/pub01-raw.zip), under `publication-audit-original/`. This addendum records the correction and new local results; it does not rewrite that historical audit to imply it passed.

## Root cause and bounded correction

The old parent ref compared a reusable actor/role/status/authority/project string. Returning A-B-A restored equality; a pending read in an old keyed workspace could resume `replaceAssignedProjects` after `changeUserRole` had already committed. The original real-component reproduction was rerun before editing: 1/1 FAIL, `isCurrent=true`, two commands.

Only two production files changed relative to the reviewed 30-path UI5 candidate: AdminConsoleView replaces authorization identity and advances a generation on every effective key transition, and each workspace captures an immutable lifetime object whose layout cleanup permanently retires it. Async operations capture that particular lifetime rather than whatever later object occupies the ref. StrictMode replay creates a new lifetime. Existing target generations still retire X-Y-X operations. adminDecisionReadback adds explicit checks before authoritative read and after its UI callback. No global state or authorization policy was added.

The existing account client already checks UID and the captured `isCurrent` after token acquisition, immediately before fetch. Those service bytes remain unchanged; the predicate now stays retired permanently. Server/Rules, transactions, last viable SUPER_ADMIN, self-action protection, driver identity authority and PROJECT_ADMIN read-only behavior remain unchanged.

## Async-boundary audit

| Boundary | Permanent continuity check |
| --- | --- |
| Initiation | Capture workspace lifetime and authorization generation; synchronous duplicate guard |
| Token -> HTTP | Existing production client checks captured predicate and UID after token await, immediately before fetch |
| ACK/error | Captured operation checked after execute resolves/rejects |
| Next command | Same captured predicate checked before every subsequent command |
| Authoritative read | Guard before and after read; caller checks before publication; guard after callback |
| UI outcome/draft/banner | Captured operation checked before publishing; pending cleanup only in captured live workspace |
| USERS/PROJECTS/AUDIT | Independent captured lifetimes plus per-source request sequences |
| Unmount/target/StrictMode | Permanently retired mount token; fresh replay token; target generation never reused |

An already transmitted command may commit. Retirement is neither cancellation nor rollback. Unknown outcomes are not replayed and no compensating permission mutation is added. New actor/authorization workspaces receive fresh state rather than inheriting a prior pending decision.

## Red-to-green and final verification

- Exact original external test/assertions: 1/1 FAIL before correction -> 1/1 PASS after correction. It now records `isCurrent=false`, only `changeUserRole`. Its unchanged case is also appended to the existing component suite and identified separately from historical failure debt.
- 27 new real-component/production-client boundary cases PASS. They count intercepted fetch invocations, not mocked execute success flags. They cover role, UID, authority, status and project A-B-A during token/readback; role/actor A-B-A during ACK; X-Y-X; unmount/remount; duplicate clicks; late reads/errors; StrictMode; lifecycle/driver commands; and uninterrupted role/read/project/read ordering. Retired tokens send zero HTTP commands; retired ACK/readback sequences send zero subsequent project commands.
- Original baseline 240/243, original UI5 candidate 288/291, current affected suite 316/319, native exit1: the exact same three subscription-string failure identities. All76 UI5 cases pass: original48 + unchanged original-retirement copy1 + new27. No historical assertions removed, weakened or skipped. Aggregate remains NOT PASS. The external original retirement 1/1 is separate red-to-green evidence, not silently absorbed into the inherited three.
- Fresh native Edge9/9: AR/EN/UR at390/768/1440; actual components, explicit presentation transport/data fixtures, keyboard checkbox, dialog focus/Escape/return and disabled actions.
- Fresh authenticated owned emulator1/1: actual App/Auth/Rules/Firestore/server. A genuine role HTTP ACK is delayed after the server transaction commits, actor role is revoked and restored, then the ACK is released. Exactly one role request/audit persists, zero project requests/audits, canonical project assignment unchanged, and no stale confirmed UI. Existing approval, driver uniqueness/link/unlink, partial rejection, current-role403, self409 and last-admin409 assertions remain intact. Owned processes/listeners cleanly shut down.
- Exact runtime command16/16 native0, TypeScript/lint native0, client/PWA/server build native0. All production bytes were frozen before gates and verified unchanged. A connected-test-only seed-placement correction was made after the first emulator attempt; that journey and TypeScript were rerun on the final test bytes. The unaffected automated family, runtime, build and browser inputs remained unchanged and were not needlessly rerun.

Initial new-test fixture errors remain in focused-r1: the rejection confirm label was incorrect, and a target-switch test incorrectly expected a discarded late read to replace the retained draft. Only those new fixtures were corrected; the latter now asserts both retained VIEWER UI and genuinely committed DRIVER fixture state. The original failing publication test was never altered.

The initial owned emulator attempt also remains preserved: the newly seeded active target ID contained the actor ID and matched the original self-row text selector before the added scenario. Creating that new target later, immediately before its own scenario and explicitly reloading users, preserves the original self-protection selector/assertion without weakening it. Only the affected journey and TypeScript needed rerunning; production bytes did not change.

## Exact scope, preserved evidence and owner gate

Before33-file final reconciliation the original candidate had30 paths:8 production/7 tests/15 docs. Final scope33:8 production/8 tests/17 docs. Added paths are the permanent-retirement test, this addendum and its separate raw ZIP. The old `ui5/verification-raw.zip` is unchanged. Current [inventory](ui5/exact-file-inventory.json), [verification](ui5/verification.json), [source contract](ui5/source-contract.json), [failure comparison](ui5/failure-comparison.json) and [SHA seal](ui5/evidence-sha256.json) reconcile the final bytes; pre-correction versions are preserved in `pub01-raw.zip/before/`.

All22 protected worktree HEAD/status/dirty hashes, original RB4 nine dirty files and unpublished migration013 remain unchanged. Seven inherited documentation bodies and original UI4 fourteen-failure/RB1/CI1/connected/interrupted evidence remain preserved. Firestore stays operational authority; backend/Rules/client command service and shared XLSX correction remain untouched.

GO to owner source review only. Independent publication review, inherited non-green debt, physical-device/screen-reader/live operational/provider acceptance and product/Beta2 release authorization remain outstanding. Do not treat local emulator results as production acceptance or this addendum as UI5 source closure.
'''
(r/'docs/reconstruction/UI5_PUB01_RETIREMENT.md').write_text(record,encoding='utf8')
(o/'FINAL_PUBLICATION_AUDIT.md').write_text(record,encoding='utf8')

header='''## CURRENT UI5-PUB-01 CORRECTION — 2026-11-20

UI5 = SOURCE_IMPLEMENTED / UI5-PUB-01_CORRECTED_LOCALLY / OWNER_REVIEW_PENDING. See [permanent retirement and post-correction audit](UI5_PUB01_RETIREMENT.md). Original audit FAIL is retained; its unchanged reproduction is now1/1 PASS. All27 new boundary cases and all76 UI5 cases pass. Affected316/319 retains the same three inherited failures: aggregate NOT PASS. Fresh Edge9/9, authenticated local emulator1/1, runtime16/16 and TypeScript/lint/build pass. Final scope33 files:8 production/8 tests/17 docs. Original30-path bytes and historical evidence are preserved in the new raw archive. UI4 remains MERGED / SOURCE_CLOSED; protected22/RB4 nine/migration013 preserved. No commit/push/PR/merge/deployment/SQL/RB4/UI6 or product/Beta2 authorization. Earlier local records below are historical, not the current publication decision.

'''
for name in ['00_WORK_START_HERE.md','02_PHASE_LEDGER.md','05_DECISION_AND_DEBT_LOG.md','MASTER_PROJECT_HANDOFF.md','UI5_ACCOUNT_REVIEW.md','UI5_TARGET_DISCOVERY.md']:
 p=r/'docs/reconstruction'/name;original=(o/'before/docs/reconstruction'/name).read_bytes();p.write_bytes(header.encode('utf8')+original)
readme=d/'README.md';readme.write_bytes(('## Current UI5-PUB-01 owner review — 2026-11-20\n\n[Post-correction audit](../UI5_PUB01_RETIREMENT.md), [current verification](verification.json), [exact33 files](exact-file-inventory.json), [new raw evidence](pub01-raw.zip). Original publication FAIL and old raw ZIP remain historical and unchanged. READY_FOR_OWNER_REVIEW; publication unauthorized.\n\n').encode('utf8')+(o/'before/docs/reconstruction/ui5/README.md').read_bytes())

# Archive originals and new raw evidence independently; never overwrite the old archive.
archive=d/'pub01-raw.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for folder,dirs,names in os.walk(o):
  dirs[:]=[n for n in dirs if n not in ['runner','node_modules','__pycache__']]
  for name in sorted(names):
   p=Path(folder)/name
   if p.suffix.lower() in ['.json','.log','.txt','.mjs','.cjs','.py','.ts','.tsx','.zip','.png','.md','.diff']:z.write(p,p.relative_to(o).as_posix())
with zipfile.ZipFile(archive) as z:assert z.testzip() is None

previous=read(o/'before/docs/reconstruction/ui5/verification.json');v=dict(previous)
v['beforePub01Verification']=previous;v['UI5_PUB01_CURRENT']=report
v['SOURCE_PREFLIGHT']={**previous['SOURCE_PREFLIGHT'],'pub01ResumeVerifiedMain':before['head'],'pub01ResumeDate':'2026-11-20','publicationAllowed':False}
v['EXACT_FILE_SCOPE']={'total':33,'production':8,'newTestsAndFixtures':8,'documentationAndEvidence':17,'inheritedDocumentation':7,'inventory':'exact-file-inventory.json'}
v['sourceFiles']=source;v['currentGateSourceFiles']=source;v['gateSourceFiles']=source
v['COMMAND_ACK_READBACK_RESULTS']={**previous['COMMAND_ACK_READBACK_RESULTS'],'newCases':76,'permanentRetirementVerified':True,'original48PlusRetirementCopy1PlusBoundary27':True}
v['SELECTION_AND_DRAFT_FENCING']='Permanent authorization generation and captured mount lifetime; target generation never reused. See UI5_PUB01_CURRENT for complete boundaries and red-to-green proof.'
v['ROOT_CAUSE_MATRIX']=[*previous['ROOT_CAUSE_MATRIX'],{'cause':report['UI5_PUB01_ROOT_CAUSE'],'correction':report['AUTHORIZATION_LEASE_INVARIANT'],'proof':'Original unchanged1/1 red->green, new27/27, real HTTP emulator0 subsequent project requests'}]
v['BASELINE_CANDIDATE_FAILURE_IDENTITIES']=comparison
v['BROWSER_AR_EN_UR']=report['BROWSER_AND_EMULATOR_RESULTS'];v['AUTHENTICATED_EMULATOR_RESULTS']=report['BROWSER_AND_EMULATOR_RESULTS']
v['TYPECHECK_LINT_BUILD']=report['TYPECHECK_I18N_BUILD'];v['FINAL_SOURCE_REVIEW_DECISION']=report['FINAL_PUBLICATION_READINESS_DECISION']
v['PROTECTED_WORKTREES']=report['PROTECTED_WORKTREES']
v['DOCUMENT_RECONCILIATION']={'status':'PUB01_RECONCILED','owner':'docs/reconstruction/02_PHASE_LEDGER.md','record':'docs/reconstruction/UI5_PUB01_RETIREMENT.md','historicalBodiesAndOriginalAuditPreserved':True}
v['historicalPostGateWhitespaceReconciliation']=previous['postGateWhitespaceReconciliation']
v['postGateWhitespaceReconciliation']={'currentGateState':'No source edits after final PUB01 gates. Original one-space history retained under historicalPostGateWhitespaceReconciliation and beforePub01Verification.'}
v['pub01RawArchiveSha256']=sha(archive);v['pub01RawArchive']='pub01-raw.zip'
v['publicationAllowed']=False
write(d/'verification.json',v)
contract=read(o/'before/docs/reconstruction/ui5/source-contract.json')
contract['beforePub01SourceFiles']=contract['sourceFiles'];contract['sourceFiles']=source
contract['beforePub01GateSourceFiles']=contract['gateSourceFiles'];contract['gateSourceFiles']=source
contract['pub01ProductionChanges']=report['EXACT_CHANGED_FILES']['pub01ProductionDelta'];contract['asyncBoundaryCoverage']=boundaries
contract['currentTestAddition']='src/tests/ui5Pub01Retirement.test.tsx';contract['serverRulesAndClientServiceUnchangedFromReviewedUI5']=True
contract['testAllowlist']=[*contract['testAllowlist'],'src/tests/ui5Pub01Retirement.test.tsx']
contract['originalMainTestsUnchanged']=True
contract['historicalPostGateWhitespaceReconciliation']=contract['postGateWhitespaceReconciliation']
contract['postGateWhitespaceReconciliation']={'currentState':'Final production bytes unchanged after gates; connected-only seed placement correction and its latest TypeScript/emulator runs explicitly reconciled.'}
write(d/'source-contract.json',contract)

paths=sorted(set(git(r,'diff','--name-only','HEAD').splitlines()+git(r,'ls-files','--others','--exclude-standard').splitlines()))
assert len(paths)==33,(len(paths),paths)
classify=lambda f:'TEST_OR_FIXTURE' if f.startswith('src/tests/') else 'PRODUCTION' if f.startswith('src/') else 'DOCUMENTATION_OR_EVIDENCE'
classes=collections.Counter(classify(f) for f in paths);assert classes=={'PRODUCTION':8,'TEST_OR_FIXTURE':8,'DOCUMENTATION_OR_EVIDENCE':17}
write(d/'exact-file-inventory.json',{'head':before['head'],'branch':before['branch'],'total':33,'counts':dict(classes),'beforePub01Count':30,'addedByPub01':report['EXACT_CHANGED_FILES']['addedPaths'],'inheritedSevenDocs':list(pre['inheritedSevenDocs']),'files':[{'file':f,'classification':classify(f),'sha256':sha(r/f) if f.startswith('src/') else None} for f in paths]})
for f,h in pre['inheritedSevenDocs'].items():
 original=(r.parent/'ui5-evidence-20261115/before'/f).read_bytes();assert hashlib.sha256(original).hexdigest()==h and (r/f).read_bytes().endswith(original)

# Reuse the established secret rules, report only rule/path names, and verify all new links.
tree=ast.parse((r.parent/'ui4-rb1-evidence-20261115/finalize.py').read_text(encoding='utf8'))
patterns=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='patterns' for t in n.targets))
findings=[];scanned=0
for f in paths:
 if Path(f).suffix not in ['.zip','.png']:
  scanned+=1;findings.extend({'file':f,'rule':k} for k,p in patterns.items() if re.search(p,(r/f).read_bytes()))
with zipfile.ZipFile(archive) as z:
 for name in z.namelist():
  if Path(name).suffix in ['.json','.log','.txt','.mjs','.py','.ts','.tsx','.md','.diff']:
   scanned+=1;findings.extend({'file':'pub01-raw::'+name,'rule':k} for k,p in patterns.items() if re.search(p,z.read(name)))
assert not findings,findings
links=[]
for f in paths:
 if Path(f).suffix!='.md':continue
 body=(r/f).read_bytes();old=o/'before'/f
 if old.exists():
  previous_bytes=old.read_bytes()
  assert body.endswith(previous_bytes)
  body=body[:-len(previous_bytes)]
 for url in re.findall(r'\[[^\]]+\]\(([^)]+)\)',body.decode('utf8')):
  if url.startswith(('https://','http://','mailto:','#')):continue
  target=urllib.parse.unquote(url.split('#')[0]);assert ((r/f).parent/target).exists(),(f,url)
  links.append({'source':f,'target':url})
assert subprocess.run(['git','diff','--check'],capture_output=True).returncode==0
assert not git(r,'diff','--cached','--name-only')
assert all(sha(r/f)==h for f,h in source.items())
write(d/'evidence-sha256.json',{'algorithm':'SHA256','scope':'Final33 local paths; self excluded. New archive preserves original30 bytes and immutable failed audit; original raw ZIP unchanged.','diffCheckNativeExit':0,'stagedFiles':0,'secretScan':{'status':'PASS','scanned':scanned,'findings':[],'fixtureBoundary':'Intentional synthetic demo/example.invalid data only'},'docLinks':{'status':'PASS','checked':links},'files':{f:sha(r/f) for f in paths if f!='docs/reconstruction/ui5/evidence-sha256.json'}})
write(o/'final-owner-review-gate.json',{'status':report['FINAL_PUBLICATION_READINESS_DECISION'],'paths':paths,'counts':dict(classes),'sourceFrozenAfterGates':True,'originalAuditUnchanged':True,'originalUi5RawArchiveUnchanged':True,'protected22':True,'diffCheck':0,'secretScan':'PASS','staged':0,'noPublication':True})
print('FINALIZED: UI5-PUB-01 corrected; original1/1 red->green; new27/27; UI5 total76/76; affected316/319 NOT_PASS; exact33; owner review only.')
