from pathlib import Path
import json,hashlib,subprocess,zipfile
r=Path.cwd();o=r.parent/'ui5-publication-audit-20261115';e=r.parent/'ui5-evidence-20261115';d=r/'docs/reconstruction/ui5'
j=lambda p:json.loads(p.read_text(encoding='utf8'))
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def g(p,*a):return subprocess.check_output(['git','-c','safe.directory='+str(p),'-C',str(p),*a],encoding='utf8').rstrip()
p=j(e/'preflight.json');v=j(d/'verification.json');s=j(d/'evidence-sha256.json');inv=j(d/'exact-file-inventory.json')
assert all(h(r/f)==a for f,a in s['files'].items());assert all(h(r/f)==a for f,a in v['sourceFiles'].items())
assert all((d/f).read_bytes()==(o/('before-'+f)).read_bytes() for f in ['verification.json','exact-file-inventory.json','evidence-sha256.json','source-contract.json'])
assert h(d/'verification-raw.zip')==v['rawArchiveSha256']
with zipfile.ZipFile(d/'verification-raw.zip') as z:
 assert z.testzip() is None
 for f,a in p['inheritedSevenDocs'].items():
  b=(e/'before'/f).read_bytes();assert hashlib.sha256(b).hexdigest()==a and (r/f).read_bytes().endswith(b) and z.read('before/'+f)==b
 for f in v['sourceFiles']:assert z.read('final-source/'+f)==(r/f).read_bytes()
protected=[]
for w in p['protected']:
 folder=Path(w['folder']);assert g(folder,'rev-parse','HEAD')==w['head'];assert g(folder,'status','--porcelain=v1','--untracked-files=all')==w['status'];assert all(h(folder/f)==a for f,a in w['hashes'].items());protected.append({'folder':w['folder'],'headStatusRawDirtyHashes':'UNCHANGED'})
assert len(protected)==22
unchanged={f:a for f,a in p['existingSources'].items() if f not in v['sourceFiles']}
assert all(h(r/f)==a for f,a in unchanged.items());assert all(h(r/f)==a for f,a in p['protectedRootFiles'].items())
assert g(r,'rev-parse','HEAD')==p['head'] and g(r,'branch','--show-current')==p['branch'];assert not g(r,'diff','--cached','--name-only')
actual=set(g(r,'diff','--name-only','HEAD').splitlines()+g(r,'ls-files','--others','--exclude-standard').splitlines());assert actual=={x['file'] for x in inv['files']} and len(actual)==30
assert subprocess.run(['git','diff','--check'],capture_output=True).returncode==0
assert not actual.intersection(g(r,'ls-tree','-r','--name-only','HEAD','--','src/tests').splitlines())
for f in ['docs/reconstruction/ui4/verification-raw.zip','docs/reconstruction/ui4/failure-comparison.json','src/services/reportsEngine.service.ts']:assert g(r,'hash-object',f)==g(r,'rev-parse','HEAD:'+f),f
before=(e/'format-reconciliation/user.repository.before.ts').read_text(encoding='utf8');after=(r/'src/repositories/user.repository.ts').read_text(encoding='utf8');assert before.replace('  getDoc, getDocFromServer, \n','  getDoc, getDocFromServer,\n')==after
base=j(e/'baseline.json');candidate=j(e/'publication-candidate-r2.json')
def fails(a):return sorted((Path(x['name']).name,t['fullName']) for x in a['testResults'] for t in x['assertionResults'] if t['status']=='failed')
assert fails(base)==fails(candidate) and len(fails(base))==3
assert candidate['numTotalTests']==291 and candidate['numPassedTests']==288 and candidate['numPendingTests']==0
new=[t for x in candidate['testResults'] if Path(x['name']).name.startswith('ui5') for t in x['assertionResults']];assert len(new)==48 and all(x['status']=='passed' for x in new)
red=j(o/'retirement-r2.json');assert red['numFailedTests']==1
browser=j(e/'browser-final.json');owned=j(e/'owned-final/candidate-connected.json');assert browser['numPassedTests']==9 and owned['numPassedTests']==1
assert len(list((e/'browser-final').glob('*.png')))==18 and len(list((e/'browser-final').glob('*.json')))==9
cleanup=j(e/'owned-final/ui3-connected-connected-browser-exit.json');assert cleanup['status']==0 and not cleanup['cleanupErrors'] and not cleanup['remainingListeners']
result={'status':'PUBLICATION_HOLD_CONFIRMED_SOURCE_BLOCKER','head':p['head'],'branch':p['branch'],'changedFiles':inv['total'],'counts':inv['counts'],'candidateRawHashes':{f:h(r/f) for f in sorted(actual)},'all30BytesUnchangedDuringPublicationAudit':True,'sealedHashesVerified':len(s['files']),'sourceAndTestsVerified':len(v['sourceFiles']),'oneCharacterAdjustmentVerified':True,'protected':protected,'rb4OriginalNineAndMigration013':'UNCHANGED','originalSourceFilesChecked':len(unchanged),'originalTestsAndBackendRulesUnchanged':True,'sevenInheritedDocBodiesAndZipPreserved':True,'sameThreeFailureIdentities':fails(candidate),'affectedCounts':{k:candidate[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']},'all48NewCasesPass':True,'additionalPublicationRegression':'retirement.test.tsx: authorization scope A -> B -> A revives and dispatches step two; 1/1 FAIL','browserReuse':'9/9 actual components with explicit presentation mocks; no source behavior changes; does not cover the blocker','emulatorReuse':'1/1 real App/Auth/Rules/server/Firestore; synthetic local only; no ABA claim','stagedFiles':0,'commitCreated':False,'pushPerformed':False,'draftPrCreated':False,'diffCheckExit':0,'CI':'NOT_RUN','ownerMergeGate':'HOLD'}
(o/'preservation-and-test-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print(json.dumps({k:val for k,val in result.items() if k not in ['protected','candidateRawHashes','sameThreeFailureIdentities']},ensure_ascii=False))
