# UI5 final publication audit — HOLD

Publication blocker UI5-PUB-01 (P1) is independently reproduced. No production, test, documentation or evidence bytes in the 30-file candidate were changed by this publication audit. No staging, branch creation, commit, push or PR was performed.

## Causal evidence

In `src/components/admin/AdminConsoleView.tsx:43-47`, a shared parent ref stores the current authorization key. `isCurrent` checks key equality and the parent lifetime. It does not irreversibly retire the old keyed workspace. If context A changes to B and later returns to A, an old unmounted workspace callback becomes current again. `decide` at line208 passes that predicate to `runAccountDecision`; after the old pending read returns, lines36-51 of that helper allow the next command to execute.

The additive [real-component regression](retirement.test.tsx) starts a role+project decision and holds the first readback, renders SUPER_ADMIN -> PROJECT_ADMIN -> SUPER_ADMIN, then releases the old readback. Output:

```
RETIRED_AUTH_CALLBACK_CURRENT_AFTER_RESTORE true
COMMANDS [ 'changeUserRole', 'replaceAssignedProjects' ]
```

The [test log](retirement-r2.log) and [native result](retirement-r2.json) report 1/1 FAIL, exit1. This is actual AdminConsoleView/runAccountDecision behavior with explicit mocked command/read ports; it is not a claim that this diagnostic wrote through a live or emulator server. Existing server transaction-time role checks are unchanged: the defect resumes a stale UI decision after valid authority has returned, rather than demonstrating server privilege escalation.

## Required bounded correction

Use an irreversible workspace lifetime/generation for actor and authorization contexts. Once invalidated by a key change or unmount, an old callback must remain invalid even if the same UID/role/authority key returns. Preserve target-generation checks and existing server authority. Add actual-component round-trip regressions during pending token, ACK and readback phases. After correction, rerun affected automated checks and impacted browser/authenticated journeys; reconcile documentation and evidence. No backend, Rules, command or permission redesign is needed. This audit stops at the blocker and does not implement the correction.

## Other final results

- Exact main/HEAD baseline: `08f67b6046cc10e2ee6f3cd8387bcf7bffcaf551`; branch `docs/ui4-postmerge-ui5-discovery-20261115`. Remote main was verified by successful approved `git ls-remote` in the previous segment.
- Existing affected family rerun on final bytes: 288/291, same three subscription-expectation identities as baseline 240/243, exit1, zero skips; aggregate NOT PASS. All48 existing new UI5 cases pass. The additional failed retirement test is separate new causal evidence and prevents a no-regression claim.
- TypeScript/lint exit0; exact `npm run test:i18n-runtime` 16/16 exit0; client/PWA/server build exit0. Original sandbox startup failures remain preserved. TypeScript had completed successfully before interruption and was reused; only incomplete gates were resumed.
- Edge9/9 AR/EN/UR at390/768/1440 and authenticated loopback App1/1 are retained unchanged and source-reconciled. Browser uses actual components with explicit presentation mocks; emulator uses actual App/Auth/Firestore/Rules/server with synthetic demo fixtures and clean owned-process shutdown. Neither covers the authorization round-trip defect. No physical-device, screen-reader, production or Beta2 claim.
- All30 candidate raw hashes unchanged;29-file seal and15 production/test hashes checked. The earlier import trailing-space adjustment is precisely reconciled and current bytes now covered by rerun automated gates. Diff check exit0; index empty. All22 protected worktree HEAD/status/dirty-file hashes unchanged, including RB4 nine files and unpublished migration013. Seven inherited document bodies, original UI4 fourteen non-green failure identities, raw logs/archives and old assertions remain unchanged.

Complete requested report fields, exact three identities, source hashes, command timestamps and gate decisions: [final-publication-audit.json](final-publication-audit.json). Preservation proof: [preservation-and-test-audit.json](preservation-and-test-audit.json). Publication diagnostic files are outside the candidate checkout and have not been staged.

**PUBLICATION_GATE_DECISION = HOLD. COMMIT_SHA = NOT_CREATED. REMOTE_SHA = NO_UI5_HEAD_PUSHED. DRAFT_PR_URL = NOT_CREATED. CI_STATUS_IF_OBSERVED = NO_UI5_CI_RUN_OBSERVED. OWNER_MERGE_GATE = HOLD.**
