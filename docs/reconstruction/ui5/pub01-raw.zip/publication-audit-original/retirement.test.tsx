// @vitest-environment happy-dom
import React,{act} from 'react';
import {createRoot,type Root} from 'react-dom/client';
import {beforeEach,afterEach,it,expect,vi} from 'vitest';
import {dictionaries} from 'C:/Users/Hp/Documents/ChatGPT/Work Follow/ui4-postmerge-ui5-discovery-20261115/src/locales';
import {resolveTranslation} from 'C:/Users/Hp/Documents/ChatGPT/Work Follow/ui4-postmerge-ui5-discovery-20261115/src/i18n/utils';
const f=vi.hoisted(()=>({uid:'actor',role:'SUPER_ADMIN',status:'ACTIVE',authority:'AVAILABLE',users:vi.fn(),projects:vi.fn(),audit:vi.fn(),read:vi.fn(),send:vi.fn(),drivers:vi.fn(),remote:[] as any[]}));
vi.mock('C:/Users/Hp/Documents/ChatGPT/Work Follow/ui4-postmerge-ui5-discovery-20261115/src/firebase/config',()=>({auth:{get currentUser(){return {uid:f.uid,getIdToken:async()=> 'synthetic-token'};}},db:{}}));
vi.mock('C:/Users/Hp/Documents/ChatGPT/Work Follow/ui4-postmerge-ui5-discovery-20261115/src/firebase/authContext',()=>({useAuth:()=>({user:{uid:f.uid},userProfile:{userId:f.uid,role:f.role,status:f.status,isActive:f.status==='ACTIVE',assignedProjectIds:['P1','P2']},profileAuthority:f.authority,isProfileLoading:false})}));
vi.mock('C:/Users/Hp/Documents/ChatGPT/Work Follow/ui4-postmerge-ui5-discovery-20261115/src/repositories/user.repository',()=>({userRepository:{listAll:()=>f.users(),findByIdFromServer:(id:string)=>f.read(id)}}));
vi.mock('C:/Users/Hp/Documents/ChatGPT/Work Follow/ui4-postmerge-ui5-discovery-20261115/src/repositories/project.repository',()=>({projectRepository:{listAll:(...args:any[])=>f.projects(...args)}}));
vi.mock('C:/Users/Hp/Documents/ChatGPT/Work Follow/ui4-postmerge-ui5-discovery-20261115/src/services/auditLog.service',()=>({auditLogService:{getRecentAuditLogs:(...args:any[])=>f.audit(...args)}}));
vi.mock('C:/Users/Hp/Documents/ChatGPT/Work Follow/ui4-postmerge-ui5-discovery-20261115/src/services/adminAccountClient.service',async original=>({...await original<any>(),executeAdminAccountCommand:(...args:any[])=>f.send(...args),listDriverIdentities:()=>f.drivers()}));
vi.mock('C:/Users/Hp/Documents/ChatGPT/Work Follow/ui4-postmerge-ui5-discovery-20261115/src/i18n',()=>({useI18n:()=>({t:(key:string,params?:any)=>params?key+JSON.stringify(params):key,direction:'ltr',locale:'en'})}));
import {AdminConsoleView} from 'C:/Users/Hp/Documents/ChatGPT/Work Follow/ui4-postmerge-ui5-discovery-20261115/src/components/admin/AdminConsoleView';
(globalThis as any).IS_REACT_ACT_ENVIRONMENT=true;
let host:HTMLDivElement,root:Root;
const clone=<T,>(value:T):T=>structuredClone(value);
const deferred=<T,>()=>{let resolve!:(value:T)=>void,reject!:(value:unknown)=>void;const promise=new Promise<T>((yes,no)=>{resolve=yes;reject=no});return {promise,resolve,reject};};
const render=()=>act(async()=>root.render(<AdminConsoleView/>));
const button=(name:string,scope:ParentNode=document)=>Array.from(scope.querySelectorAll<HTMLButtonElement>('button')).find(b=>b.textContent===name)!;
const click=async(name:string,scope:ParentNode=document)=>{expect(button(name,scope),name).toBeDefined();await act(async()=>button(name,scope).click());};
const review=async(id='B')=>act(async()=>host.querySelector<HTMLButtonElement>(`[data-review-user="${id}"]`)!.click());
const change=async(element:HTMLInputElement|HTMLSelectElement|HTMLTextAreaElement,value:string)=>act(async()=>{const proto=element instanceof HTMLSelectElement?HTMLSelectElement.prototype:element instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(proto,'value')!.set!.call(element,value);element.dispatchEvent(new Event(element instanceof HTMLSelectElement?'change':'input',{bubbles:true}));});
const state=()=>document.querySelector('[data-decision-status]')?.getAttribute('data-decision-status');
beforeEach(()=>{
 f.uid='actor';f.role='SUPER_ADMIN';f.status='ACTIVE';f.authority='AVAILABLE';
 f.remote=[{userId:'A',fullName:'Pending Alice',email:'alice@example.invalid',role:'VIEWER',requestedRole:'SUPERVISOR',assignedProjectIds:['P1'],status:'PENDING_APPROVAL',isActive:false},{userId:'B',fullName:'Active Bob',email:'bob@example.invalid',role:'VIEWER',assignedProjectIds:['P1'],status:'ACTIVE',isActive:true}];
 for(const mock of [f.users,f.projects,f.audit,f.read,f.send,f.drivers])mock.mockReset();
 f.users.mockImplementation(async()=>clone(f.remote));f.projects.mockResolvedValue([{projectId:'P1',nameAr:'Project One'},{projectId:'P2',nameAr:'Project Two'}]);f.audit.mockResolvedValue([]);f.drivers.mockResolvedValue([{driverId:'D1',fullNameAr:'Synthetic Driver',status:'ACTIVE'}]);f.read.mockImplementation(async(id:string)=>clone(f.remote.find(u=>u.userId===id)||null));
 f.send.mockImplementation(async(id:string,c:any)=>{const row=f.remote.find(u=>u.userId===id);switch(c.command){case 'approveAccount':Object.assign(row,{role:c.approvedRole,assignedProjectIds:c.assignedProjectIds,status:'ACTIVE',isActive:true});break;case 'rejectAccount':Object.assign(row,{status:'REJECTED',isActive:false,rejectionReason:c.rejectionReason.trim()});break;case 'suspendAccount':Object.assign(row,{status:'SUSPENDED',isActive:false});break;case 'reactivateAccount':Object.assign(row,{status:'ACTIVE',isActive:true});break;case 'changeUserRole':row.role=c.newRole;if(c.newRole!=='DRIVER')delete row.linkedDriverId;break;case 'replaceAssignedProjects':row.assignedProjectIds=c.assignedProjectIds;break;case 'linkDriverIdentity':row.linkedDriverId=c.linkedDriverId;break;case 'unlinkDriverIdentity':delete row.linkedDriverId;}return {userId:id};});
 host=document.createElement('div');document.body.append(host);root=createRoot(host);
});
afterEach(async()=>{await act(async()=>root.unmount());host.remove();});

it('publication gate: a retired authorization scope never revives when its old key returns',async()=>{
 await render();await review();await change(host.querySelector<HTMLSelectElement>('select[aria-label="admin_console.role_assignment"]')!,'DRIVER');
 const project=Array.from(host.querySelectorAll('label')).find(l=>l.textContent?.includes('Project Two'))!;
 await act(async()=>project.querySelector<HTMLInputElement>('input')!.click());
 const pending=deferred<any>();f.read.mockReturnValueOnce(pending.promise);
 await click('admin_console.save_matrix');expect(f.send).toHaveBeenCalledTimes(1);
 const retired=f.send.mock.calls[0][2].isCurrent;
 f.role='PROJECT_ADMIN';await render();expect(retired()).toBe(false);
 f.role='SUPER_ADMIN';await render();
 await act(async()=>pending.resolve(clone(f.remote.find(u=>u.userId==='B'))));
 console.log('RETIRED_AUTH_CALLBACK_CURRENT_AFTER_RESTORE',retired(),'COMMANDS',f.send.mock.calls.map(c=>c[1].command));
 expect(retired(),'authorization retirement must be irreversible').toBe(false);
 expect(f.send,'retired sequence must not dispatch step two').toHaveBeenCalledTimes(1);
});
