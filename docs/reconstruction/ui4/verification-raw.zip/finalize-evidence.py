from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess
root=Path.cwd();out=root.parent/'ui4-evidence-20261115';docs=root/'docs/reconstruction';dest=docs/'ui4'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,data):p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git','-c','safe.directory='+str(root),*args],cwd=root,text=True,encoding='utf8').strip()
def counts(r):return {k:r[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']}
def failures(r):return {x['fullName']:{'file':t['name'].split('/src/tests/')[-1],'messages':x['failureMessages']} for t in r['testResults'] for x in t['assertionResults'] if x['status']=='failed'}
commands=read(out/'owner-review-command-exits.json');assert len(commands)==5 and all(x['status']==0 for x in commands)
b=read(out/'baseline.json');c=read(out/'candidate-owner-review.json');assert counts(b)==dict(numTotalTests=324,numPassedTests=310,numFailedTests=14,numPendingTests=0);assert counts(c)==dict(numTotalTests=396,numPassedTests=382,numFailedTests=14,numPendingTests=0)
bf,cf=failures(b),failures(c);assert set(bf)==set(cf)
f=read(out/'print-affected-reviewed.json');n=read(out/'browser-owner-review.json');assert f['numTotalTests']==f['numPassedTests']==156 and n['numTotalTests']==n['numPassedTests']==9 and not f['numPendingTests'] and not n['numPendingTests']
e1=out/'owned-connected-r1';e2=out/'owned-connected-r2';eb=read(e1/'baseline-operational.json');ec=read(e1/'candidate-connected.json');er=read(e2/'candidate-connected.json');assert eb['numTotalTests']==eb['numPassedTests']==14;assert ec['numPassedTests']==16 and ec['numFailedTests']==1;assert er['numTotalTests']==er['numPassedTests']==1 and not er['numPendingTests']
for folder in [e1,e2]:
 clean=read(folder/'ui3-connected-connected-browser-exit.json');assert clean['cleanupErrors']==[] and clean['remainingListeners']==[]
pre=read(out/'preflight.json');contract=read(out/'source-contract.json');assert not contract['unexpected'] and not contract['protectedChanges'] and not contract['hookProblems'];assert all(x['headUnchanged'] and x['statusUnchanged'] for x in contract['otherWorktrees']);assert all(x['unchanged'] for x in contract['rb4Files'])
assert git('rev-parse','HEAD')==pre['startingMain']=='800434f634fb7ea5099fc12e4ec064dfb05d6df2';assert git('branch','--show-current')=='ui/ui4-operational-reports-20261115';assert not git('diff','--cached','--name-only')
assert not dest.exists();dest.mkdir()
for name in ['preflight.json','inherited-five-docs.patch','source-contract.json']:shutil.copyfile(out/name,dest/name)
comparison={'baseline':counts(b),'candidate':counts(c),'baselineNativeExit':read(out/'baseline-exit.json')['status'],'candidateNativeExit':read(out/'candidate-owner-review-exit.json')['status'],'newFailureIdentities':[],'removedFailureIdentities':[],'identities':[{'identity':name,'baseline':bf[name],'candidate':cf[name],'classification':'CONFIRMED_ENVIRONMENT_PRECONDITION' if 'EXPLICIT_LOCAL_FIRESTORE_REQUIRED' in cf[name]['messages'][0] else 'INHERITED_ASSERTION_IN_UNCHANGED_WIZARD_OR_OUTBOX','supplemental':'Matching 14-case operational family passed on baseline and candidate with asserted loopback emulators; original non-emulator aggregate remains NOT PASS.' if 'EXPLICIT_LOCAL_FIRESTORE_REQUIRED' in cf[name]['messages'][0] else 'Still failing in exact final focused differential; no assertion modification.'} for name in sorted(cf)]};write(dest/'failure-comparison.json',comparison)
sections={};name=None
for line in (out/'inherited-five-docs.patch').read_text(encoding='utf8').splitlines():
 if line.startswith('+++ b/'):name=line[6:];sections[name]=[]
 elif name and line.startswith('+') and not line.startswith('+++'):sections[name].append(line[1:])
inherited=[]
for name,lines in sections.items():
 current=(root/name).read_text(encoding='utf8');position=0
 for line in lines:
  index=current.find(line,position);assert index>=0,(name,line);position=index+len(line)
 inherited.append({'file':name,'allOriginalAddedLinesPreservedInOrder':True})
assert len(inherited)==5
verification={'startingMain':pre['startingMain'],'githubMainReadback':{'url':'https://api.github.com/repos/rexat007/Q-Saudi-Work-Follow-App/branches/main','sha':pre['startingMain'],'method':'GitHub connector read before edits and independent readback during verification'},'branch':git('branch','--show-current'),'localHead':git('rev-parse','HEAD'),'noCommitOrPublication':True,'commands':commands,'differential':{'baseline':counts(b),'candidateFinalSource':counts(c),'nativeExits':[1,1],'newFailureIdentities':[],'aggregateDisposition':'NOT_PASS'},'newUnitTests':{'total':72,'passed':72},'finalPrintSecurityLocalizationFamily':{'result':counts(f),'nativeExit':0,'files':[t['name'].split('/src/tests/')[-1] for t in f['testResults']]},'finalBrowser':{'result':counts(n),'nativeExit':0,'browser':'Headless Microsoft Edge','locales':['ar','en','ur'],'viewports':[390,768,1440],'fourOperationalProfiles':True,'allExistingReportFamilies':True,'liveProviderOrPhysicalDeviceAcceptance':False,'fixtures':'Explicit presentation-only auth/storage/provider fixtures; actual production components, calculations and exports.'},'connected':{'baselineOperational':counts(eb),'baselineNativeExit':0,'initialCandidate':counts(ec),'initialCandidateNativeExit':1,'unchangedUi3Journeys':{'passed':2,'formats':['CSV','EXCEL'],'reportScale':1002},'newUi4AfterCanonicalNavigationFixtureRepair':counts(er),'newUi4NativeExit':0,'assertedEmulators':['127.0.0.1:8085','127.0.0.1:9099'],'project':'demo-convergence2','actualAppAuthFirestoreAndServer':True,'syntheticReportRecordsInNewUi4Case':True,'liveGoogleCalls':False,'cleanupErrors':[],'remainingListeners':[],'initial17CaseAggregate':'NOT_PASS; no synthesized 17/17 rerun claim'},'pdfReadOnlyQa':read(out/'pdf-qa/result.json'),'originalFiveDocuments':inherited,'scopePreservation':{'sourceContract':'source-contract.json','originalGoogleSevenTestAssertionsUnchanged':contract['originalGoogleTestAssertionsPreserved'],'allOtherOriginalTestsUnchanged':True,'allOtherWorktreesAndOriginalNineRb4HashesUnchanged':True,'migrationsUnchanged':True,'noStaging':True},'remainingAcceptance':['Owner source review and separate authorization before commit/publication.','Two inherited translationByConstructionGuard assertions remain failing.','Earlier native browser deadlines not reproduced in final 9/9; cause remains unresolved.','Existing shared XLSX Arabic metadata/branding retained; physical device/screen-reader acceptance remains.','Emulator runner ADC metadata lookup and runtime Git discovery warnings do not establish live Google or deployed-runtime acceptance.','Live Workspace refresh/provider credentials and operational freshness require separately authorized acceptance.']};write(dest/'verification.json',verification)
history=[]
for p in sorted(out.glob('*.json')):
 try:r=read(p)
 except Exception:continue
 if isinstance(r,dict) and 'numTotalTests' in r:history.append({'artifact':p.name,'counts':counts(r),'classification':'FINAL_ACCEPTANCE_EVIDENCE' if p.name in ['candidate-owner-review.json','print-affected-reviewed.json','browser-owner-review.json'] else 'PRESERVED_INTERMEDIATE_OR_DIAGNOSTIC_NOT_FINAL_ACCEPTANCE'})
history += [{'artifact':'new-r2-interruption.json','classification':'OWNED_TEST_FIXTURE_INTERRUPTION_RETAINED','explanation':'A new useAuth mock created a new profile object every render; cache stability corrected. No old assertion or test deadline changed.'},{'artifact':'browser-verified-interruption.json','classification':'NOT_REPRODUCED_IN_FINAL_MATRIX_CAUSE_UNRESOLVED','explanation':'Original 60-second deadlines preserved. Owned tree stopped; stage evidence and stricter 10-second action limits added. Final nine cases passed.'},{'artifact':'owned-connected-r1/candidate-connected.json','classification':'NEW_TEST_FIXTURE_NAVIGATION_ASSUMPTION','explanation':'Unchanged Sidebar selector explicitly enters WIZARD. New test verifies old report disappears, then follows existing Reports route before asserting new project.'},{'artifact':'print-affected-final.json','classification':'NEW_TEST_UPDATED_FOR_COLUMN_BANDS','explanation':'Each printed band repeats canonical rows. New tests assert every band row count and full unique column-key union, retaining the dataset-equivalence guarantee.'}];write(dest/'history.json',history)
raw=[p for p in out.iterdir() if p.is_file() and p.suffix in ['.json','.log','.txt','.mjs','.patch','.py']]
for folder in [e1,e2]:
 raw.extend(p for p in folder.iterdir() if p.is_file())
 for name in ['ui3-connected-journey-states','ui4-evidence-20261115']:
  d=folder/name
  if d.exists():raw.extend(p for p in d.rglob('*') if p.is_file())
for name in ['browser','pdf-qa']:raw.extend(p for p in (out/name).rglob('*') if p.is_file())
with zipfile.ZipFile(dest/'verification-raw.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(set(raw)):z.write(p,p.relative_to(out).as_posix())
shots={'ar-390.png':'ar-mobile.png','en-1440.png':'en-desktop.png','ur-768.png':'ur-tablet.png','ar-390-print.png':'ar-print.png','en-1440-print.png':'en-print.png','ur-768-print.png':'ur-print.png'};(dest/'screenshots').mkdir()
for source,target in shots.items():shutil.copyfile(out/'browser'/source,dest/'screenshots'/target)
(dest/'pdf-qa').mkdir()
for p in sorted((out/'pdf-qa/reviewed').glob('*.png')):shutil.copyfile(p,dest/'pdf-qa'/p.name)
(dest/'README.md').write_text('''# UI4 local owner-review evidence

No commit, staging, push or production operation. HEAD remains `800434f634fb7ea5099fc12e4ec064dfb05d6df2` on `ui/ui4-operational-reports-20261115`.

- [Commands/native exits](verification.json), [exact inventory](exact-file-inventory.json), [authority/worktree preservation](source-contract.json).
- [All 14 matched failure identities](failure-comparison.json). Baseline 310/324; final 382/396. Both native exits 1; aggregate **NOT PASS**. Twelve require explicit loopback; separately verified on emulators. Two unchanged Wizard/Outbox translation assertions remain.
- All 72 new unit cases pass. Final print/security/localization family 156/156, native exit 0. Final Edge 9/9, exit 0: AR/EN/UR at 390/768/1440, four profiles, all report families, actual CSV/XLSX downloads, print row/column equivalence, keyboard/focus, failed reads/recovery and scoped provider fixtures.
- Authenticated loopback baseline operational 14/14; initial candidate 16/17 (exit 1), including both unchanged UI3 journeys passing with 1002-Trip reporting. The new UI4 test assumed project selection remained on Reports; unchanged Sidebar enters Wizard. Following that route and real App/server gives 1/1, exit 0. Do not call the original 17-case aggregate PASS. Both owned runs have zero cleanup errors and no remaining listeners.
- [Historical attempts and causal limits](history.json). [Immutable raw verification archive](verification-raw.zip) retains failures/logs, commands, diagnostic selectors, ownership/cleanup and native artifacts. One-case diagnostics are not full-suite acceptance. Earlier native deadlines remain CAUSE_UNRESOLVED, not reproduced in final 9/9.
- [Inherited five-document patch](inherited-five-docs.patch), [preflight/allowlist](preflight.json). Original added lines remain in order.
- [Arabic mobile](screenshots/ar-mobile.png), [English desktop](screenshots/en-desktop.png), [Urdu tablet](screenshots/ur-tablet.png); print screenshots and six final page renders under `pdf-qa/`. Read-only PDF QA confirmed the old clipped columns are visible in complete bounded bands. No live-provider, physical-device or screen-reader acceptance.

[The phase ledger](../02_PHASE_LEDGER.md) alone owns current state. [UI4 implementation](../UI4_OPERATIONAL_REPORTS.md) records boundaries/debt. Existing shared XLSX metadata is Arabic; emulator runtime/ADC warnings are not Google/deployment acceptance. Recommendation: GO to owner source review with inherited debt; separate commit/publication authorization required.
''',encoding='utf8')
for name in ['secret-scan.json','doc-links.json','evidence-sha256.json','exact-file-inventory.json']:write(dest/name,{'status':'PENDING_FINAL_INTEGRITY_PASS'})
report=docs/'UI4_OPERATIONAL_REPORTS.md';s=report.read_text(encoding='utf8');s+='''
## Final local verification

See [exact files](ui4/exact-file-inventory.json), [commands/native exits](ui4/verification.json), [all matched failure identities](ui4/failure-comparison.json) and [retained raw evidence](ui4/verification-raw.zip).

Exact final focused differential: baseline **310/324**, candidate **382/396**, native exits **1/1**, zero new failure identities, zero skips. It is **NOT PASS**. All 72 new unit cases pass. Twelve of 14 failures require explicit loopback; the matching operational family separately passes **14/14 on both baseline and candidate**. The other two remain unchanged Wizard/Outbox translation assertions.

Final affected print/security/localization: **156/156**, exit **0**. Final native Edge: **9/9**, exit **0**, zero skips, AR/EN/UR mobile/tablet/desktop, four profiles and all report families. Actual CSV/XLSX cell equivalence and complete printed row/column coverage are asserted. All six final PDF pages were rendered and visually inspected, alongside retained negative clipped-table evidence.

Authenticated emulator results remain distinct: baseline **14/14**; initial candidate **16/17**, exit **1**, including both unchanged UI3 CSV/Excel journeys passing and 1002-Trip reporting. The new test incorrectly assumed Sidebar selection stays on Reports; it explicitly enters Wizard. Following that unchanged route yields corrected UI4 **1/1**, exit **0**. No synthesized 17/17 aggregate. Both owned runs clean all listeners with zero cleanup errors.

Final TypeScript/lint (`npm run lint` executes `tsc --noEmit`): **0 diagnostics / exit 0**. Client/PWA/server build: **exit 0**, existing chunk-size warning retained. Source contract **exit 0**: original seven Google assertions and all other old tests unchanged; no protected authority/dependency/CI/migration changes; other worktrees and original nine RB4 raw hashes unchanged. Final diff/secret/link checks are adjacent evidence.

Earlier red iterations and two native deadlines remain retained. They were not reproduced in final 9/9; cause **CAUSE_UNRESOLVED**, not a proven environment explanation. Emulator ADC/runtime Git warnings do not establish live Google or deployed-runtime acceptance. Shared XLSX Arabic metadata, physical devices, assistive technology and real Workspace refresh/freshness need separate operational acceptance.

**GO to owner source review with inherited debt.** HEAD unchanged; changes uncommitted/unstaged. No publication, deployment, cutover or product-live acceptance authorized.
''';report.write_text(s,encoding='utf8')
p=docs/'02_PHASE_LEDGER.md';s=p.read_text(encoding='utf8').replace('**UI4: LOCAL_IMPLEMENTATION / VERIFICATION_IN_PROGRESS / OWNER_REVIEW_REQUIRED.**','**UI4: SOURCE_IMPLEMENTED / LOCALLY_VERIFIED_WITH_INHERITED_DEBT / OWNER_REVIEW_REQUIRED.**');p.write_text(s,encoding='utf8')
changed=sorted(set(git('diff','--name-only','HEAD').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()))
inventory={'head':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),'counts':{'production':sum(x.startswith('src/') and not x.startswith('src/tests/') for x in changed),'testsAndFixtures':sum(x.startswith('src/tests/') for x in changed),'documentationAndEvidence':sum(x.startswith('docs/') for x in changed),'total':len(changed)},'files':[{'file':x,'classification':'TEST_OR_FIXTURE' if x.startswith('src/tests/') else 'PRODUCTION' if x.startswith('src/') else 'DOCUMENTATION_OR_EVIDENCE','sha256':sha(root/x) if x.startswith('src/') else None} for x in changed]};assert inventory['counts']['production']==8 and inventory['counts']['testsAndFixtures']==7;write(dest/'exact-file-inventory.json',inventory)
print(json.dumps(inventory['counts'],indent=2))
