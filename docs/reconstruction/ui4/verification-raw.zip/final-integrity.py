from pathlib import Path
import json,re,hashlib,zipfile,subprocess,urllib.parse
root=Path.cwd();dest=root/'docs/reconstruction/ui4';inventory=json.loads((dest/'exact-file-inventory.json').read_text(encoding='utf8'));contract=json.loads((dest/'source-contract.json').read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for row in contract['sourceFiles']:assert sha(root/row['file'])==row['sha256'],row['file']
patterns={'PRIVATE_KEY':rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----','GITHUB_TOKEN':rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})','OPENAI_KEY':rb'sk-(?:proj-)?[A-Za-z0-9_-]{32,}','GOOGLE_ACCESS':rb'ya29\.[A-Za-z0-9_-]{20,}','GOOGLE_CLIENT_SECRET':rb'GOCSPX-[A-Za-z0-9_-]{20,}','AWS_ACCESS':rb'AKIA[0-9A-Z]{16}','SLACK_TOKEN':rb'xox[baprs]-[A-Za-z0-9-]{20,}','JWT':rb'eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}','GOOGLE_API_KEY':rb'AIza[A-Za-z0-9_-]{35}'}
findings=[];scanned=[]
def scan(name,data):
 scanned.append(name)
 for key,pattern in patterns.items():
  for match in re.finditer(pattern,data):findings.append({'file':name,'rule':key,'line':data[:match.start()].count(b'\n')+1})
for row in inventory['files']:
 p=root/row['file']
 if p.suffix not in ['.zip','.png']:scan(row['file'],p.read_bytes())
with zipfile.ZipFile(dest/'verification-raw.zip') as z:
 assert z.testzip() is None
 for name in z.namelist():
  if Path(name).suffix in ['.json','.log','.txt','.mjs','.ts','.tsx','.py','.patch','.md']:scan('verification-raw.zip::'+name,z.read(name))
assert not findings,findings
secret={'status':'PASS','scannedTextFilesAndDecompressedEntries':len(scanned),'patterns':list(patterns),'findings':[],'fixtureClassification':'The explicit emulator-only synthetic password and example.invalid identities are intentional test fixtures, not production credentials. No environment/private-key/runtime credential files are in the Git inventory.','archiveIntegrity':'PASS'};(dest/'secret-scan.json').write_text(json.dumps(secret,indent=2)+'\n',encoding='utf8')
# Entire new records and only current entry sections of preserved historical documents.
scopes=[root/'docs/reconstruction/UI4_OPERATIONAL_REPORTS.md',dest/'README.md']
scopes += [root/'docs/reconstruction'/n for n in ['00_WORK_START_HERE.md','02_PHASE_LEDGER.md','MASTER_PROJECT_HANDOFF.md','05_DECISION_AND_DEBT_LOG.md']]
links=[]
for p in scopes:
 text=p.read_text(encoding='utf8')
 if p.name not in ['UI4_OPERATIONAL_REPORTS.md','README.md']:
  match=re.search(r'\n## ',text[1:])
  if match:text=text[:match.start()+1]
 for url in re.findall(r'\[[^\]]+\]\(([^)]+)\)',text):
  if url.startswith(('https://','http://','mailto:','#')):continue
  target=urllib.parse.unquote(url.split('#')[0].strip('<>'));exists=(p.parent/target).exists();links.append({'source':p.relative_to(root).as_posix(),'target':url,'exists':exists})
assert all(x['exists'] for x in links),links
(dest/'doc-links.json').write_text(json.dumps({'status':'PASS','scope':'New UI4 records and current entry pointers; retained historical documents are not rewritten.','checked':links},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
result=subprocess.run(['git','-c','safe.directory='+str(root),'diff','--check'],cwd=root,capture_output=True,text=True);assert result.returncode==0,result.stdout+result.stderr
assert not subprocess.check_output(['git','-c','safe.directory='+str(root),'diff','--cached','--name-only'],cwd=root,text=True).strip()
# Seal all documentary evidence except this self-referential hash manifest.
paths=[root/r['file'] for r in inventory['files'] if r['file']!='docs/reconstruction/ui4/evidence-sha256.json']
(dest/'evidence-sha256.json').write_text(json.dumps({'algorithm':'SHA256','diffCheckNativeExit':result.returncode,'stagedFiles':0,'files':{p.relative_to(root).as_posix():sha(p) for p in paths}},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'secretScan':'PASS','scanned':len(scanned),'links':len(links),'diffCheckNativeExit':result.returncode,'sourceIdentitiesMatchFinalVerification':True,'inventory':inventory['counts'],'stagedFiles':0},indent=2))
