import {createRequire} from 'node:module';import fs from 'node:fs';import path from 'node:path';import {pathToFileURL} from 'node:url';
const root=process.cwd(),out=path.resolve('../ui4-rb1-evidence-20261115/route-probe'),require=createRequire(path.join(root,'package.json')),XLSX=require('xlsx');
fs.mkdirSync(out,{recursive:true});let captured:any;XLSX.writeFile=(wb:any)=>{captured=wb;};
(globalThis as any).fetch=()=>{throw Error('NETWORK_PROHIBITED_IN_AUDIT');};
const {reportsEngineService}=await import(pathToFileURL(path.join(root,'src/services/reportsEngine.service.ts')).href);
const {operationalReportPresentation}=await import(pathToFileURL(path.join(root,'src/components/reports/operationalReportPresentation.ts')).href);
const {reportTrips,reportConfig,reportNow}=await import(pathToFileURL(path.join(root,'src/tests/helpers/ui4ReportFixture.ts')).href);
const {validateOperationalConfiguration,snapshotOperationalConfiguration}=await import(pathToFileURL(path.join(root,'src/services/operationalProfileResolver.ts')).href);
const configuration=reportConfig('NONE','NONE');configuration.routeConfiguration.loadingLocation='Origin\r\nGate A';
const validated=validateOperationalConfiguration(configuration),trips=reportTrips('NONE','NONE');for(const trip of trips)trip.operationalSnapshot=snapshotOperationalConfiguration(validated,1,null,{});
const dataset=operationalReportPresentation(trips,'P1',validated,{},'LIVE',reportNow,(key:string)=>key).dataset;
const csv=reportsEngineService.exportDatasetToCSV(dataset);fs.writeFileSync(path.join(out,'multiline-route.csv'),csv);
(globalThis as any).window={};(globalThis as any).document={};reportsEngineService.exportToXLSX(dataset);if(!captured)throw Error('AUDIT_CAPTURE_DID_NOT_INTERCEPT_WRITEFILE');
const bytes=XLSX.write(captured,{type:'buffer',bookType:'xlsx'});fs.writeFileSync(path.join(out,'multiline-route.xlsx'),bytes);const book=XLSX.read(bytes),sheet=book.Sheets[book.SheetNames[0]],xlsxRows=XLSX.utils.sheet_to_json(sheet,{header:1,range:5,defval:'',raw:true});
const allRows:string[][]=[];let csvRow:string[]=[],value='',quoted=false;
for(let i=1;i<csv.length;i++){const ch=csv[i];if(ch==='"'){if(quoted&&csv[i+1]==='"'){value+='"';i++;}else quoted=!quoted;}else if(!quoted&&ch===','){csvRow.push(value);value='';}else if(!quoted&&ch==='\r'&&csv[i+1]==='\n'){csvRow.push(value);allRows.push(csvRow);csvRow=[];value='';i++;}else value+=ch;}csvRow.push(value);allRows.push(csvRow);const csvRows=allRows.slice(1);
const result={validCanonicalConfiguration:true,lineBreakPreserved:validated.routeConfiguration.loadingLocation==='Origin\r\nGate A',inputDatasetRows:dataset.rows.length,csvDataRows:csvRows.length,xlsxDataRows:xlsxRows.length,equivalent:JSON.stringify(csvRows)===JSON.stringify(xlsxRows),csvRows,xlsxRows};fs.writeFileSync(path.join(out,'xlsx-multiline-probe.json'),JSON.stringify(result,null,2));console.log(JSON.stringify({...result,csvRows:undefined,xlsxRows:undefined}));

if(result.inputDatasetRows!==2||result.xlsxDataRows!==2||!result.equivalent||!xlsxRows.every((row:any)=>row.includes('Origin\r\nGate A')))throw Error('ROW_INTEGRITY_FAILURE');
