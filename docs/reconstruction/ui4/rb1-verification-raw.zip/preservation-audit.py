from pathlib import Path
import json,hashlib,subprocess
r=Path.cwd();o=r.parent/'ui4-rb1-evidence-20261115';pre=json.loads((o/'preflight.json').read_text(encoding='utf8'))
def g(folder,*a):return subprocess.check_output(['git','-c','safe.directory='+str(folder),'-C',str(folder),*a],text=True,encoding='utf8').rstrip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
for folder,s in pre['protected'].items():
 checks.append({'folder':folder,'headUnchanged':g(folder,'rev-parse','HEAD')==s['head'],'statusUnchanged':g(folder,'status','--porcelain=v1')==s['status'],'rawHashesUnchanged':all(sha(Path(folder)/f)==h for f,h in s['hashes'].items())})
baseline=r.parent/'ui4-main-baseline-20261115';checks.append({'folder':str(baseline),'headUnchanged':g(baseline,'rev-parse','HEAD')==pre['head'],'statusUnchanged':not g(baseline,'status','--porcelain=v1'),'rawHashesUnchanged':True,'note':'Additional detached comparison worktree is clean; no mutations were made by correction.'})
rb4=json.loads((r.parent/'convergence1-rb4-preservation.json').read_text(encoding='utf8'));folder=next(p for p,s in pre['protected'].items() if s['head']==rb4['head'] and len(s['hashes'])==9)
rb4files=[{'file':f,'sha256':sha(Path(folder)/f),'matchesOriginal':sha(Path(folder)/f)==h} for f,h in rb4['files'].items()]
assert len(rb4files)==9 and all(x['matchesOriginal'] for x in rb4files)
assert all(c['headUnchanged'] and c['statusUnchanged'] and c['rawHashesUnchanged'] for c in checks)
assert g(r,'rev-parse','HEAD')==pre['head'] and g(r,'branch','--show-current')==pre['branch'] and not g(r,'diff','--cached','--name-only')
assert all(sha(r/f)==h for f,h in pre['files'].items() if f.startswith('src/') and f!='src/tests/ui4ReportConnectedJourney.test.ts')
changedProduction=[f for f in g(r,'diff','--name-only','HEAD').splitlines() if f.startswith(('src/services/','src/db/','server/','src/repositories/','src/types/','src/firebase/','.github/','package'))]
assert changedProduction==['src/services/reportsEngine.service.ts'],changedProduction
result={'head':g(r,'rev-parse','HEAD'),'branch':g(r,'branch','--show-current'),'stagedFiles':0,'protectedWorktrees':checks,'originalRb4NineFiles':rb4files,'migration013':'UNTRACKED_UNPUBLISHED_UNCHANGED','productionAuthorityException':changedProduction,'originalUI4SourcePreservedExceptAdditiveConnectedExportAssertions':True,'sourceFiles':[{'file':f,'sha256':sha(r/f)} for f in sorted(set(g(r,'diff','--name-only','HEAD').splitlines()+g(r,'ls-files','--others','--exclude-standard').splitlines())) if f.startswith('src/')]}
(o/'preservation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8');print('PRESERVATION_PASS: 21 protected worktrees, original 9 RB4 hashes, unpublished 013, no staging')
