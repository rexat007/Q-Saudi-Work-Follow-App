import {completeReportExportColumns} from './operationalReportPresentation';
import {useReportScope} from './useReportScope';
import {AdaptiveOperationalReports} from './AdaptiveOperationalReports';
import { hasProjectScope, filterProjectScope } from '../../utils/projectScope';
import { presentAnalyticsText, presentReportCell } from '../../i18n/analyticsPresentation';
import { useI18n } from '../../i18n';
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  FileText, 
  Calendar, 
  Clock, 
  Truck, 
  Layers, 
  Gauge, 
  Scale, 
  RotateCcw, 
  AlertTriangle, 
  Building2, 
  PieChart, 
  Package, 
  Hash, 
  Calculator, 
  Banknote, 
  Download, 
  Printer, 
  Filter, 
  RotateCw, 
  Search, 
  CheckCircle2, 
  ChevronDown,
  Info,
  ShieldCheck,
  TrendingUp,
  FileSpreadsheet,
  ShieldAlert
} from 'lucide-react';
import { 
  ReportType, 
  ReportCategory, 
  OperationalReportType, 
  PricingReportType, 
  ReportFilterParams, 
  OPERATIONAL_REPORTS_METADATA, 
  PRICING_REPORTS_METADATA 
} from '../../types/reports';
import { TripEngineStatus, TripPricingType, OperationSourceType, TripRecord } from '../../types/tripEngine';
import { reportsEngineService } from '../../services/reportsEngine.service';
import { useAuth } from '../../firebase/authContext';
import { tripRepository } from '../../repositories/trip.repository';
import { projectRepository } from '../../repositories/project.repository';
import { exceptionRepository } from '../../repositories/exception.repository';
import { TripExceptionEntity } from '../../types/entities';
import { PrintableReportModal } from './PrintableReportModal';

export function computeMergedTripsFromProjects(tripsByProject: Record<string, TripRecord[]>): TripRecord[] {
  const list: TripRecord[] = [];
  Object.keys(tripsByProject).forEach(projectId => {
    if (tripsByProject[projectId]) {
      list.push(...tripsByProject[projectId]);
    }
  });

  const seen = new Set<string>();
  const deduplicated: TripRecord[] = [];
  for (const t of list) {
    const key = JSON.stringify([t.projectId, t.tripId]);
    if (!seen.has(key)) {
      seen.add(key);
      deduplicated.push(t);
    }
  }
  return deduplicated;
}

export function computeMergedExceptionsFromProjects(exceptionsByProject: Record<string, TripExceptionEntity[]>): TripExceptionEntity[] {
  const list: TripExceptionEntity[] = [];
  Object.keys(exceptionsByProject).forEach(projectId => {
    if (exceptionsByProject[projectId]) {
      list.push(...exceptionsByProject[projectId]);
    }
  });

  const seen = new Set<string>();
  const deduplicated: TripExceptionEntity[] = [];
  for (const e of list) {
    const key = JSON.stringify([e.projectId, e.tripId, e.exceptionId]);
    if (!seen.has(key)) {
      seen.add(key);
      deduplicated.push(e);
    }
  }
  return deduplicated;
}

type ReportsViewProps={operationalProjectId?:string;operationalConfiguration?:import('../../types/operationalProfile').OperationalConfiguration};
export const ReportsEngineView: React.FC<ReportsViewProps> = props => {
  const scope=useReportScope(props.operationalProjectId),{t}=useI18n();
  if(!scope.allowed)return <section role={scope.verifying?'status':'alert'}>{t(scope.verifying?'ui4.verifying':scope.unavailable?'ui4.authority_unavailable':'ui4.denied')}</section>;
  return <ActiveReportSurface key={scope.key} {...props} scope={scope}/>;
};
function ActiveReportSurface(props:ReportsViewProps&{scope:ReturnType<typeof useReportScope>}){
  const [financial,setFinancial]=useState(false),{t}=useI18n();
  if(props.operationalProjectId&&!financial)return <div className="space-y-4"><button type="button" className="min-h-11 rounded-lg border border-stone-600 px-4 py-2" onClick={()=>setFinancial(true)}>{t('op.financial_reports')}</button><AdaptiveOperationalReports projectId={props.operationalProjectId} configuration={props.operationalConfiguration}/></div>;
  return <><div>{props.operationalProjectId&&<button type="button" className="min-h-11 rounded-lg border border-stone-600 px-4 py-2" onClick={()=>setFinancial(false)}>{t('ui4.return_operational')}</button>}</div><LegacyReportsEngineView {...props} initialCategory={props.operationalProjectId?'PRICING':'OPERATIONAL'} initialReportType={props.operationalProjectId?'SETTLEMENT_BY_CARRIER':'DAILY_OPERATIONS'} onOperationalRequested={()=>setFinancial(false)}/></>;
}
const LegacyReportsEngineView: React.FC<ReportsViewProps&{scope:ReturnType<typeof useReportScope>;initialCategory:ReportCategory;initialReportType:ReportType;onOperationalRequested:()=>void}> = ({operationalProjectId,scope,initialCategory,initialReportType,onOperationalRequested}) => {
  const { t: translate, isRTL } = useI18n();
  // Navigation
  const [activeCategory, setCategory] = useState<ReportCategory>(initialCategory);
  const setActiveCategory=(category:ReportCategory)=>{if(operationalProjectId&&!['PRICING','SETTLEMENT'].includes(category)){onOperationalRequested();return;}setCategory(category);};
  const [selectedReportType, setSelectedReportType] = useState<ReportType>(initialReportType);
  
  // Filter state (BLOCK 39: multi-criteria filter parameters)
  const [filters, setFilters] = useState<ReportFilterParams>({
    projectId: 'ALL',
    shiftDateFrom: '',
    shiftDateTo: '',
    shift: 'ALL',
    carrierId: 'ALL',
    materialId: 'ALL',
    pricingType: 'ALL',
    status: 'ALL',
    sourceType: 'ALL',
    truckId: 'ALL',
    driverId: 'ALL',
    supervisorId: 'ALL',
  });

  // Table Search and Sorting
  const [tableSearch, setTableSearch] = useState<string>('');
  const [isPrintModalOpen, setIsPrintModalOpen] = useState<boolean>(false);
  const [isMobileFiltersOpen, setIsMobileFiltersOpen] = useState<boolean>(false);

  // Auth and Subscription State
  const { userProfile, isAuthReady } = useAuth();
  const [isDataLoading, setIsDataLoading] = useState<boolean>(true);
  const [dataError, setDataError] = useState<string | null>(null);

  // Authorized projects
  const [storedAuthorizedProjects, setAuthorizedProjects] = useState<{ id: string; nameAr: string }[]>([]);
  const [storedAuthorizedProjectIds, setAuthorizedProjectIds] = useState<string[]>([]);

  const authorizedProjects = useMemo(() => storedAuthorizedProjects.filter(project => hasProjectScope(userProfile || undefined, project.id)), [storedAuthorizedProjects, userProfile]);
  const authorizedProjectIds = useMemo(() => storedAuthorizedProjectIds.filter(id => hasProjectScope(userProfile || undefined, id)), [storedAuthorizedProjectIds, userProfile]);

  // Real-time trip database mapping: projectId -> TripRecord[]
  const [tripsByProject, setTripsByProject] = useState<Record<string, TripRecord[]>>({});

  // Real-time exception database mapping: projectId -> TripExceptionEntity[]
  const [exceptionsByProject, setExceptionsByProject] = useState<Record<string, TripExceptionEntity[]>>({});

  const [readRevision,setReadRevision]=useState(0),[sourceReadAt,setSourceReadAt]=useState<string|null>(null);
  const readGeneration=useRef(0);
  const dataScope=JSON.stringify([readRevision,userProfile?.userId,userProfile?.role,userProfile?.status,[...(userProfile?.assignedProjectIds||[])].sort(),filters.projectId,selectedReportType]);
  const [loadedScope,setLoadedScope]=useState<string|null>(null);
  const currentDataScope=useRef(dataScope);currentDataScope.current=dataScope;

  // Combined data loading effect (Retire to one-shot for Idle Quiescence)
  useEffect(() => {
    setTripsByProject({});
    setExceptionsByProject({});
    setAuthorizedProjects([]);
    setAuthorizedProjectIds([]);
    if (!isAuthReady || !userProfile) { setIsDataLoading(false); return; }

    let active = true;const request=++readGeneration.current;
    const current=()=>active&&request===readGeneration.current&&currentDataScope.current===dataScope&&scope.isCurrent();
    setSourceReadAt(null);setIsPrintModalOpen(false);
    const isSuperAdmin = userProfile.role === 'SUPER_ADMIN';
    const assignedIds = userProfile.assignedProjectIds || [];

    const loadData = async () => {
      setIsDataLoading(true);
      setDataError(null);

      try {
        // 1. Projects
        const projects = await projectRepository.listAll(assignedIds, isSuperAdmin);
        if (!current()) return;
        const filtered = projects.filter(p => p.status !== 'ARCHIVED' && (isSuperAdmin || assignedIds.includes(p.projectId)));
        const formatted = filtered.map(p => ({ id: p.projectId, nameAr: p.nameAr || p.projectId }));
        setAuthorizedProjects(formatted);
        const ids = formatted.map(f => f.id);
        setAuthorizedProjectIds(ids);

        if (ids.length === 0) {
          setLoadedScope(dataScope);setSourceReadAt(new Date().toISOString());
          setIsDataLoading(false);
          return;
        }

        // 2. Trips
        const targetIds = filters.projectId === 'ALL' ? ids : (ids.includes(filters.projectId) ? [filters.projectId] : []);
        if (targetIds.length === 0) {
          setDataError("analytics.ui.data_loading_failed");
          setTripsByProject({});
          setIsDataLoading(false);
          return;
        }

        const tripResults = await Promise.all(targetIds.map(pId => tripRepository.listCompleteByProject(pId)));
        if (!current()) return;
        const tripsMap: Record<string, TripRecord[]> = {};
        tripResults.forEach((trips, idx) => {
          tripsMap[targetIds[idx]] = trips.map(t => reportsEngineService.adaptTripEntityToRecord(t));
        });

        // 3. Exceptions
        if (selectedReportType === 'EXCEPTION_REPORT') {
          const exceptionResults = await Promise.all(targetIds.map(pId => exceptionRepository.listByProject(pId)));
          if (!current()) return;
          const exceptionsMap: Record<string, TripExceptionEntity[]> = {};
          exceptionResults.forEach((excs, idx) => {
            exceptionsMap[targetIds[idx]] = excs;
          });
          setExceptionsByProject(exceptionsMap);
        }

        // Publish a complete successful generation only after all required reads.
        if (!current()) return;
        setTripsByProject(tripsMap);
        setLoadedScope(dataScope);setSourceReadAt(new Date().toISOString());
        setIsDataLoading(false);
      } catch (err) {
        console.error('Failed to load report data:', err);
        if (current()) {
          setTripsByProject({});
          setExceptionsByProject({});
          setDataError("analytics.ui.data_loading_failed");
          setIsDataLoading(false);
        }
      }
    };

    loadData();
    return () => { active = false;readGeneration.current++; };
  }, [userProfile, isAuthReady, filters.projectId, selectedReportType,readRevision]);

  // Merged & Deduplicated canonical datasets
  const allTrips = useMemo(() => {
    return loadedScope!==dataScope?[]:filterProjectScope(computeMergedTripsFromProjects(tripsByProject), userProfile || undefined);
  }, [tripsByProject, userProfile,loadedScope,dataScope]);

  const allExceptions = useMemo(() => {
    return loadedScope!==dataScope?[]:filterProjectScope(computeMergedExceptionsFromProjects(exceptionsByProject), userProfile || undefined);
  }, [exceptionsByProject, userProfile,loadedScope,dataScope]);

  // Distinct master data options extracted dynamically from live trips & snapshots (RP-27, RP-28, RP-34)
  const availableProjects = useMemo(() => {
    return authorizedProjects.map(p => ({ projectId: p.id, nameAr: p.nameAr }));
  }, [authorizedProjects]);

  const availableCarriers = useMemo(() => {
    const map = new Map<string, string>();
    allTrips.forEach(t => {
      const cName = reportsEngineService.getEntityLabels(t).carrierName;
      map.set(t.carrierId, cName);
    });
    return Array.from(map.entries()).map(([id, name]) => ({ carrierId: id, nameAr: name }));
  }, [allTrips]);

  const availableMaterials = useMemo(() => {
    const map = new Map<string, string>();
    allTrips.forEach(t => {
      const mName = reportsEngineService.getEntityLabels(t).materialName;
      map.set(t.materialId, mName);
    });
    return Array.from(map.entries()).map(([id, name]) => ({ materialId: id, nameAr: name }));
  }, [allTrips]);

  const availableTrucks = useMemo(() => {
    const map = new Map<string, string>();
    allTrips.forEach(t => {
      const tPlate = reportsEngineService.getEntityLabels(t).truckPlate;
      map.set(t.truckId, tPlate);
    });
    return Array.from(map.entries()).map(([id, plate]) => ({ truckId: id, plateNumberAr: plate }));
  }, [allTrips]);

  const availableDrivers = useMemo(() => {
    const map = new Map<string, string>();
    allTrips.forEach(t => {
      const dName = reportsEngineService.getEntityLabels(t).driverName;
      map.set(t.driverId, dName);
    });
    return Array.from(map.entries()).map(([id, name]) => ({ driverId: id, fullNameAr: name }));
  }, [allTrips]);

  // Distinct supervisors list extracted from trips
  const availableSupervisors = useMemo(() => {
    const list = new Set<string>();
    allTrips.forEach(t => {
      if (t.loaderId) list.add(t.loaderId);
      if (t.unloaderId) list.add(t.unloaderId);
      if (t.createdBy) list.add(t.createdBy);
      if (t.updatedBy) list.add(t.updatedBy);
    });
    return Array.from(list);
  }, [allTrips]);

  // Generate current active dataset
  const currentDataset = useMemo(() => {
    return completeReportExportColumns(reportsEngineService.generateReport(
      selectedReportType, 
      filters, 
      allTrips, 
      selectedReportType === 'EXCEPTION_REPORT' ? allExceptions : undefined
    ),translate);
  }, [selectedReportType, filters, allTrips, allExceptions,translate]);

  // Filter rows by table search
  const filteredRows = useMemo(() => {
    if (!tableSearch.trim()) return currentDataset.rows;
    const query = tableSearch.toLowerCase();
    return currentDataset.rows.filter(r => {
      return Object.values(r).some(val => 
        val !== undefined && val !== null && String(val).toLowerCase().includes(query)
      );
    });
  }, [currentDataset.rows, tableSearch]);

  // Active filter count
  const activeFilterCount = useMemo(() => {
    let count = 0;
    if (filters.projectId !== 'ALL') count++;
    if (filters.shiftDateFrom) count++;
    if (filters.shiftDateTo) count++;
    if (filters.shift && filters.shift !== 'ALL') count++;
    if (filters.carrierId !== 'ALL') count++;
    if (filters.materialId !== 'ALL') count++;
    if (filters.pricingType !== 'ALL') count++;
    if (filters.status !== 'ALL') count++;
    if (filters.sourceType && filters.sourceType !== 'ALL') count++;
    if (filters.truckId !== 'ALL') count++;
    if (filters.driverId !== 'ALL') count++;
    if (filters.supervisorId !== 'ALL') count++;
    return count;
  }, [filters]);

  const handleResetFilters = () => {
    setFilters({
      projectId: 'ALL',
      shiftDateFrom: '',
      shiftDateTo: '',
      shift: 'ALL',
      carrierId: 'ALL',
      materialId: 'ALL',
      pricingType: 'ALL',
      status: 'ALL',
      sourceType: 'ALL',
      truckId: 'ALL',
      driverId: 'ALL',
      supervisorId: 'ALL',
    });
    setTableSearch('');
  };

  const handleExportCSV = () => {
    if(readReady&&scope.isCurrent())reportsEngineService.exportToCSV(currentDataset);
  };

  const handleExportXLSX = () => {
    if(readReady&&scope.isCurrent())reportsEngineService.exportToXLSX(currentDataset);
  };

  // Icon mapping helper
  const renderReportIcon = (iconName: string, className = 'w-4 h-4') => {
    switch (iconName) {
      case 'Calendar': return <Calendar className={className} />;
      case 'Clock': return <Clock className={className} />;
      case 'Truck': return <Truck className={className} />;
      case 'Layers': return <Layers className={className} />;
      case 'Gauge': return <Gauge className={className} />;
      case 'Scale': return <Scale className={className} />;
      case 'RotateCcw': return <RotateCcw className={className} />;
      case 'AlertTriangle': return <AlertTriangle className={className} />;
      case 'Building2': return <Building2 className={className} />;
      case 'PieChart': return <PieChart className={className} />;
      case 'Package': return <Package className={className} />;
      case 'Hash': return <Hash className={className} />;
      case 'Calculator': return <Calculator className={className} />;
      case 'Banknote': return <Banknote className={className} />;
      default: return <FileText className={className} />;
    }
  };

  const readReady=!isDataLoading&&!dataError&&loadedScope===dataScope&&scope.isCurrent();

  return (
    <div className="space-y-6" dir={isRTL ? 'rtl' : 'ltr'}>
      <button type="button" className="min-h-11 rounded-lg border border-stone-600 px-4 py-2" disabled={isDataLoading} onClick={()=>{if(!scope.isCurrent())return;readGeneration.current++;setLoadedScope(null);setIsDataLoading(true);setIsPrintModalOpen(false);setReadRevision(v=>v+1);}}>{translate('ui4.reload_source')}</button>
      
      {/* 1. Header Banner & Authoritative Invariance Guarantee */}
      <div className="bg-white rounded-2xl border border-stone-200 p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-700">
                <FileText className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-stone-900 flex items-center gap-2">
                  <span>{translate("analytics.ui.logistics_and_financial_reports_engine")}</span>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold border border-emerald-200">
                    {translate("analytics.ui.count_approved_reports", { count: Object.keys(OPERATIONAL_REPORTS_METADATA).length + Object.keys(PRICING_REPORTS_METADATA).length })}</span>
                </h1>
                <p className="text-xs text-stone-500 mt-0.5">
                  {translate("analytics.ui.comprehensive_operational_and_financial_reporting_with_contractual_pricing_snapshot_in")}</p>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            {/* Snapshot Invariance Badge */}
            <div className="bg-amber-50 border border-amber-200/80 rounded-xl p-3 text-xs text-amber-950 flex items-start gap-2.5 max-w-md">
              <ShieldCheck className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">{translate("analytics.ui.contractual_snapshot_invariance")}</span>
                <p className="text-[11px] text-amber-900 mt-0.5 leading-relaxed">
                  {translate("analytics.ui.reports_rely_exclusively_on")}{" "}<code className="bg-white px-1 py-0.2 rounded font-mono font-bold text-amber-950">settlementAmount</code> {" "}{translate("analytics.ui.stored_with_each_trip_historical_trips_are_never_repriced_using_current_rates")}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Category Switcher Tabs */}
        <div className="flex flex-wrap items-center gap-2.5 mt-6 border-t border-stone-100 pt-4">
          <button
            id="tab-operational-reports"
            onClick={() => {
              setActiveCategory('OPERATIONAL');
              setSelectedReportType('DAILY_OPERATIONS');
            }}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeCategory === 'OPERATIONAL'
                ? 'bg-stone-900 text-white shadow-xs'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            <Truck className="w-4 h-4" />
            <span>{translate("analytics.ui.operational_reports_7_reports")}</span>
            <span className={`px-1.5 py-0.2 rounded text-[10px] ${activeCategory === 'OPERATIONAL' ? 'bg-white/20 text-white' : 'bg-stone-200 text-stone-700'}`}>
              {translate("analytics.ui.operational")}</span>
          </button>

          <button
            id="tab-weighbridge-reports"
            onClick={() => {
              setActiveCategory('WEIGHBRIDGE');
              setSelectedReportType('WEIGHT_VARIANCE');
            }}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeCategory === 'WEIGHBRIDGE'
                ? 'bg-cyan-700 text-white shadow-xs'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            <Scale className="w-4 h-4" />
            <span>{translate("analytics.ui.weighbridge_and_variance_reports")}</span>
            <span className={`px-1.5 py-0.2 rounded text-[10px] ${activeCategory === 'WEIGHBRIDGE' ? 'bg-white/20 text-white' : 'bg-stone-200 text-stone-700'}`}>
              {translate("analytics.ui.weighbridge")}</span>
          </button>

          <button
            id="tab-pricing-reports"
            onClick={() => {
              setActiveCategory('PRICING');
              setSelectedReportType('SETTLEMENT_BY_CARRIER');
            }}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeCategory === 'PRICING' || activeCategory === 'SETTLEMENT'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            <Banknote className="w-4 h-4" />
            <span>{translate("analytics.ui.financial_and_settlement_reports_7_reports")}</span>
            <span className={`px-1.5 py-0.2 rounded text-[10px] ${activeCategory === 'PRICING' || activeCategory === 'SETTLEMENT' ? 'bg-white/20 text-white' : 'bg-stone-200 text-stone-700'}`}>
              {translate("analytics.ui.financial")}</span>
          </button>

          <button
            id="tab-ingestion-reports"
            onClick={() => {
              setActiveCategory('INGESTION');
              setSelectedReportType('EXCEPTION_REPORT');
            }}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeCategory === 'INGESTION'
                ? 'bg-rose-700 text-white shadow-xs'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            <AlertTriangle className="w-4 h-4" />
            <span>{translate("analytics.ui.ingestion_and_exception_reports")}</span>
            <span className={`px-1.5 py-0.2 rounded text-[10px] ${activeCategory === 'INGESTION' ? 'bg-white/20 text-white' : 'bg-stone-200 text-stone-700'}`}>
              {translate("analytics.ui.ingestion_exceptions")}</span>
          </button>
        </div>

        {/* Report Selector Pills */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-2 mt-3">
          {activeCategory === 'OPERATIONAL' &&
            ['DAILY_OPERATIONS', 'SHIFT_OPERATIONS', 'CARRIER_PERFORMANCE', 'MATERIAL_MOVEMENT', 'TRUCK_UTILIZATION', 'RETURNED_TRIPS', 'SOURCE_BREAKDOWN'].map((typeKey) => {
              const rep = OPERATIONAL_REPORTS_METADATA[typeKey as OperationalReportType];
              if (!rep) return null;
              const isSelected = selectedReportType === rep.type;
              return (
                <button
                  key={rep.type}
                  onClick={() => setSelectedReportType(rep.type)}
                  className={`flex flex-col items-center text-center p-2.5 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-amber-500/10 border-amber-500 text-amber-950 font-bold shadow-2xs'
                      : 'bg-stone-50/70 border-stone-200 text-stone-700 hover:bg-stone-100 hover:border-stone-300'
                  }`}
                >
                  <div className={`p-1.5 rounded-lg mb-1.5 ${isSelected ? 'bg-amber-500 text-white' : 'bg-stone-200 text-stone-600'}`}>
                    {renderReportIcon(rep.iconName, 'w-3.5 h-3.5')}
                  </div>
                  <span className="text-[11px] line-clamp-1">{presentAnalyticsText(rep.titleAr, translate)}</span>
                </button>
              );
            })}

          {activeCategory === 'WEIGHBRIDGE' && (
            <button
              onClick={() => setSelectedReportType('WEIGHT_VARIANCE')}
              className="flex flex-col items-center text-center p-2.5 rounded-xl border bg-cyan-500/10 border-cyan-500 text-cyan-950 font-bold shadow-2xs cursor-pointer col-span-full sm:col-span-2 md:col-span-3"
            >
              <div className="p-1.5 rounded-lg mb-1.5 bg-cyan-600 text-white">
                <Scale className="w-4 h-4" />
              </div>
              <span className="text-xs">{presentAnalyticsText(OPERATIONAL_REPORTS_METADATA.WEIGHT_VARIANCE.titleAr, translate)}</span>
              <span className="text-[10px] text-cyan-800 font-normal mt-0.5">{presentAnalyticsText(OPERATIONAL_REPORTS_METADATA.WEIGHT_VARIANCE.descriptionAr, translate)}</span>
            </button>
          )}

          {(activeCategory === 'PRICING' || activeCategory === 'SETTLEMENT') &&
            Object.values(PRICING_REPORTS_METADATA).map((rep) => {
              const isSelected = selectedReportType === rep.type;
              return (
                <button
                  key={rep.type}
                  onClick={() => setSelectedReportType(rep.type)}
                  className={`flex flex-col items-center text-center p-2.5 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-amber-500/10 border-amber-500 text-amber-950 font-bold shadow-2xs'
                      : 'bg-stone-50/70 border-stone-200 text-stone-700 hover:bg-stone-100 hover:border-stone-300'
                  }`}
                >
                  <div className={`p-1.5 rounded-lg mb-1.5 ${isSelected ? 'bg-amber-600 text-white' : 'bg-stone-200 text-stone-600'}`}>
                    {renderReportIcon(rep.iconName, 'w-3.5 h-3.5')}
                  </div>
                  <span className="text-[11px] line-clamp-1">{presentAnalyticsText(rep.titleAr, translate)}</span>
                </button>
              );
            })}

          {activeCategory === 'INGESTION' && (
            <button
              onClick={() => setSelectedReportType('EXCEPTION_REPORT')}
              className="flex flex-col items-center text-center p-2.5 rounded-xl border bg-rose-500/10 border-rose-500 text-rose-950 font-bold shadow-2xs cursor-pointer col-span-full sm:col-span-2 md:col-span-3"
            >
              <div className="p-1.5 rounded-lg mb-1.5 bg-rose-600 text-white">
                <AlertTriangle className="w-4 h-4" />
              </div>
              <span className="text-xs">{presentAnalyticsText(OPERATIONAL_REPORTS_METADATA.EXCEPTION_REPORT.titleAr, translate)}</span>
              <span className="text-[10px] text-rose-800 font-normal mt-0.5">{presentAnalyticsText(OPERATIONAL_REPORTS_METADATA.EXCEPTION_REPORT.descriptionAr, translate)}</span>
            </button>
          )}
        </div>
      </div>

      {/* 2. Comprehensive Filter Engine Bar (Multi-Parameter Filter Engine) */}
      <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-stone-700" />
            <h2 className="text-sm font-bold text-stone-900">{translate("analytics.ui.multi_criteria_report_filters")}</h2>
            {activeFilterCount > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[11px] font-bold">
                {activeFilterCount} {" "}{translate("analytics.ui.active")}</span>
            )}
          </div>
          {activeFilterCount > 0 && (
            <button
              onClick={handleResetFilters}
              className="flex items-center gap-1.5 text-xs text-rose-600 hover:text-rose-700 font-semibold cursor-pointer"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>{translate("analytics.ui.reset_filters")}</span>
            </button>
          )}
        </div>

        {/* Mobile Accordion Toggle (< 640px) */}
        <div className="sm:hidden">
          <button
            type="button"
            onClick={() => setIsMobileFiltersOpen(!isMobileFiltersOpen)}
            className="w-full min-h-[44px] flex items-center justify-between px-3.5 py-2.5 bg-stone-100 border border-stone-200 rounded-xl text-xs font-bold text-stone-800 hover:bg-stone-200/80 transition-colors"
          >
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-amber-600" />
              <span>{translate("analytics.ui.report_filter_options")}</span>
              {activeFilterCount > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-amber-600 text-white text-[10px] font-bold">
                  {activeFilterCount}
                </span>
              )}
            </div>
            <div className="flex items-center gap-1 text-stone-500 text-[11px]">
              <span>{isMobileFiltersOpen ? translate("navigation.hide") : translate("operations.showing")}</span>
              <ChevronDown className={`w-4 h-4 transition-transform ${isMobileFiltersOpen ? 'rotate-180' : ''}`} />
            </div>
          </button>

          {!isMobileFiltersOpen && (
            <div className="flex flex-wrap gap-1.5 text-[10px] text-stone-600 mt-2 px-1">
              <span className="px-2 py-0.5 bg-stone-100 border border-stone-200 rounded-md font-mono">
                {translate("operations.project")}{" "}{filters.projectId === 'ALL' ? translate("admin_console.filter_all") : filters.projectId}
              </span>
              <span className="px-2 py-0.5 bg-stone-100 border border-stone-200 rounded-md font-mono">
                {translate("operations.carrier")}{" "}{filters.carrierId === 'ALL' ? translate("admin_console.filter_all") : filters.carrierId}
              </span>
              <span className="px-2 py-0.5 bg-stone-100 border border-stone-200 rounded-md font-mono">
                {translate("loading.labels.material_2")}{" "}{filters.materialId === 'ALL' ? translate("admin_console.filter_all") : filters.materialId}
              </span>
            </div>
          )}
        </div>

        {/* Filter Selectors Grid */}
        <div className={`grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3 ${isMobileFiltersOpen ? 'block sm:grid' : 'hidden sm:grid'}`}>
          
          {/* 1. Project */}
          <div>
            <label className="block text-[11px] font-bold text-stone-600 mb-1">{translate("analytics.ui.project")}</label>
            <select
              value={filters.projectId}
              onChange={(e) => setFilters(prev => ({ ...prev, projectId: e.target.value }))}
              className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500 text-stone-800"
            >
              <option value="ALL">{translate("analytics.ui.all_projects")}</option>
              {availableProjects.map(p => (
                <option key={p.projectId} value={p.projectId}>{p.nameAr}</option>
              ))}
            </select>
          </div>

          {/* 2. Shift Date From & To */}
          <div>
            <label className="block text-[11px] font-bold text-stone-600 mb-1">{translate("analytics.ui.operation_date_from")}</label>
            <input
              type="date"
              value={filters.shiftDateFrom || ''}
              onChange={(e) => setFilters(prev => ({ ...prev, shiftDateFrom: e.target.value }))}
              className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500 text-stone-800"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-stone-600 mb-1">{translate("analytics.ui.operation_date_to")}</label>
            <input
              type="date"
              value={filters.shiftDateTo || ''}
              onChange={(e) => setFilters(prev => ({ ...prev, shiftDateTo: e.target.value }))}
              className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500 text-stone-800"
            />
          </div>

          {/* Shift Filter */}
          <div>
            <label className="block text-[11px] font-bold text-stone-600 mb-1">{translate("analytics.ui.shift")}</label>
            <select
              value={filters.shift || 'ALL'}
              onChange={(e) => setFilters(prev => ({ ...prev, shift: e.target.value as any }))}
              className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500 text-stone-800"
            >
              <option value="ALL">{translate("analytics.ui.all_shifts")}</option>
              <option value="MORNING">{translate("analytics.ui.morning_06_00_14_00")}</option>
              <option value="EVENING">{translate("analytics.ui.evening_14_00_22_00")}</option>
              <option value="NIGHT">{translate("analytics.ui.night_22_00_06_00")}</option>
            </select>
          </div>

          {/* 3. Carrier */}
          <div>
            <label className="block text-[11px] font-bold text-stone-600 mb-1">{translate("analytics.ui.carrier")}</label>
            <select
              value={filters.carrierId}
              onChange={(e) => setFilters(prev => ({ ...prev, carrierId: e.target.value }))}
              className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500 text-stone-800"
            >
              <option value="ALL">{translate("dashboard.labels.all_carriers")}</option>
              {availableCarriers.map(c => (
                <option key={c.carrierId} value={c.carrierId}>{c.nameAr}</option>
              ))}
            </select>
          </div>

          {/* 4. Material */}
          <div>
            <label className="block text-[11px] font-bold text-stone-600 mb-1">{translate("analytics.ui.material")}</label>
            <select
              value={filters.materialId}
              onChange={(e) => setFilters(prev => ({ ...prev, materialId: e.target.value }))}
              className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500 text-stone-800"
            >
              <option value="ALL">{translate("dashboard.labels.all_materials")}</option>
              {availableMaterials.map(m => (
                <option key={m.materialId} value={m.materialId}>{m.nameAr}</option>
              ))}
            </select>
          </div>

          {/* 5. Pricing Type */}
          <div>
            <label className="block text-[11px] font-bold text-stone-600 mb-1">{translate("loading.labels.pricing_2")}</label>
            <select
              value={filters.pricingType}
              onChange={(e) => setFilters(prev => ({ ...prev, pricingType: e.target.value as any }))}
              className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500 text-stone-800 font-medium"
            >
              <option value="ALL">{translate("analytics.ui.all_pricing_models")}</option>
              <option value="PER_TON">{translate("analytics.ui.per_weight_ton_per_ton")}</option>
              <option value="PER_TRIP">{translate("analytics.ui.fixed_rate_trip_per_trip")}</option>
            </select>
          </div>

          {/* 6. Status */}
          <div>
            <label className="block text-[11px] font-bold text-stone-600 mb-1">{translate("analytics.ui.trip_status")}</label>
            <select
              value={filters.status}
              onChange={(e) => setFilters(prev => ({ ...prev, status: e.target.value as any }))}
              className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500 text-stone-800"
            >
              <option value="ALL">{translate("analytics.ui.all_statuses")}</option>
              <option value="COMPLETED">{translate("dashboard.labels.status_completed")}</option>
              <option value="IN_TRANSIT">{translate("dashboard.labels.status_in_transit")}</option>
              <option value="UNLOADING">{translate("operations.unloading_unloading")}</option>
              <option value="ARRIVED">{translate("analytics.ui.arrived_at_site_arrived")}</option>
              <option value="LOADED">{translate("dashboard.labels.download")}</option>
              <option value="RETURNED">{translate("analytics.ui.returned_or_rejected_returned")}</option>
              <option value="EXCEPTION">{translate("analytics.ui.active_exception_exception")}</option>
              <option value="DRAFT">{translate("dashboard.labels.status_draft")}</option>
            </select>
          </div>

          {/* Source Type Filter */}
          <div>
            <label className="block text-[11px] font-bold text-stone-600 mb-1">{translate("analytics.ui.operation_source")}</label>
            <select
              value={filters.sourceType || 'ALL'}
              onChange={(e) => setFilters(prev => ({ ...prev, sourceType: e.target.value as any }))}
              className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500 text-stone-800 font-medium"
            >
              <option value="ALL">{translate("analytics.ui.all_sources")}</option>
              <option value="WEIGHBRIDGE">{translate("analytics.ui.electronic_weighbridge_weighbridge")}</option>
              <option value="MANUAL">{translate("analytics.ui.manual_entry_manual")}</option>
              <option value="EXCEL">{translate("analytics.ui.excel_import_excel")}</option>
              <option value="CSV">{translate("analytics.ui.text_data_file_csv")}</option>
              <option value="GOOGLE_SHEETS">{translate("analytics.ui.google_sheets_google_sheets")}</option>
              <option value="GOOGLE_DRIVE">{translate("analytics.ui.google_drive_google_drive")}</option>
              <option value="API">{translate("analytics.ui.api_integration_api")}</option>
              <option value="MIGRATION">{translate("analytics.ui.historical_migration_migration")}</option>
            </select>
          </div>

          {/* 7. Truck */}
          <div>
            <label className="block text-[11px] font-bold text-stone-600 mb-1">{translate("other.labels.truck_5")}</label>
            <select
              value={filters.truckId}
              onChange={(e) => setFilters(prev => ({ ...prev, truckId: e.target.value }))}
              className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500 text-stone-800"
            >
              <option value="ALL">{translate("analytics.ui.all_trucks")}</option>
              {availableTrucks.map(t => (
                <option key={t.truckId} value={t.truckId}>{t.plateNumberAr}</option>
              ))}
            </select>
          </div>

          {/* 8. Driver */}
          <div>
            <label className="block text-[11px] font-bold text-stone-600 mb-1">{translate("analytics.ui.driver")}</label>
            <select
              value={filters.driverId}
              onChange={(e) => setFilters(prev => ({ ...prev, driverId: e.target.value }))}
              className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500 text-stone-800"
            >
              <option value="ALL">{translate("analytics.ui.all_drivers")}</option>
              {availableDrivers.map(d => (
                <option key={d.driverId} value={d.driverId}>{d.fullNameAr}</option>
              ))}
            </select>
          </div>

          {/* 9. Supervisor */}
          <div>
            <label className="block text-[11px] font-bold text-stone-600 mb-1">{translate("analytics.ui.supervisor_weighbridge_operator")}</label>
            <select
              value={filters.supervisorId}
              onChange={(e) => setFilters(prev => ({ ...prev, supervisorId: e.target.value }))}
              className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2 focus:ring-1 focus:ring-amber-500 text-stone-800"
            >
              <option value="ALL">{translate("analytics.ui.all_supervisors")}</option>
              {availableSupervisors.map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>

        </div>
      </div>

      {(isDataLoading||!dataError&&loadedScope!==dataScope) && (
        <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center shadow-xs">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-amber-600 mx-auto mb-4"></div>
          <h3 className="text-sm font-bold text-stone-900">{translate("analytics.ui.loading_authorized_trip_data")}</h3>
          <p className="text-xs text-stone-500 mt-1 font-sans">{translate("analytics.ui.please_wait_while_records_are_retrieved_and_access_permissions_are_securely_verified")}</p>
        </div>
      )}

      {dataError && (
        <div className="bg-rose-50 rounded-2xl border border-rose-200 p-8 text-center shadow-xs">
          <ShieldAlert className="w-10 h-10 text-rose-600 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-rose-900">{translate("analytics.ui.data_loading_failed")}</h3>
          <p className="text-xs text-rose-700 mt-1">{translate(dataError)}</p>
          <p className="text-[11px] text-stone-500 mt-2 font-sans">{translate("analytics.ui.check_your_internet_connection_and_reload_the_page_or_contact_your_system_administrato")}</p>
        </div>
      )}

      {readReady && (
        <>
          {/* 3. Authoritative Financial KPI Cards (Gross, Adjustments, Exceptions, Net) */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        
        {/* Gross Amount */}
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
          <div className="text-[11px] font-bold text-stone-500">{translate("analytics.ui.original_gross_amount")}</div>
          <div className="text-xl font-black text-stone-900 mt-1 font-mono">
            {currentDataset.summary.grossAmountSAR.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-stone-400 mt-0.5">{translate("analytics.ui.sar_pricing_snapshot")}</div>
        </div>

        {/* Adjustments */}
        <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-200 shadow-xs">
          <div className="text-[11px] font-bold text-emerald-800">{translate("analytics.ui.adjustments")}</div>
          <div className="text-xl font-black text-emerald-900 mt-1 font-mono">
            +{currentDataset.summary.adjustmentsSAR.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-emerald-700 mt-0.5">{translate("analytics.ui.sar_allowances_and_weighbridge_tolerance")}</div>
        </div>

        {/* Exceptions & Deductions */}
        <div className="bg-rose-50/60 p-4 rounded-2xl border border-rose-200 shadow-xs">
          <div className="text-[11px] font-bold text-rose-800">{translate("analytics.ui.exceptions_and_deductions")}</div>
          <div className="text-xl font-black text-rose-900 mt-1 font-mono">
            -{currentDataset.summary.exceptionsSAR.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-rose-700 mt-0.5">{translate("analytics.ui.sar_penalties_and_weight_shortages")}</div>
        </div>

        {/* Net Amount */}
        <div className="bg-amber-500/10 p-4 rounded-2xl border-2 border-amber-500 shadow-xs">
          <div className="text-[11px] font-bold text-amber-900">{translate("analytics.ui.final_net_amount_payable")}</div>
          <div className="text-2xl font-black text-amber-950 mt-1 font-mono">
            {currentDataset.summary.netAmountSAR.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-amber-800 font-bold mt-0.5">{translate("analytics.ui.sar_net_payable")}</div>
        </div>

        {/* Total Trips */}
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
          <div className="text-[11px] font-bold text-stone-500">{translate("analytics.ui.total_trips")}</div>
          <div className="text-xl font-black text-stone-900 mt-1 font-mono">
            {currentDataset.summary.totalTrips}
          </div>
          <div className="text-[10px] text-stone-400 mt-0.5">
            {currentDataset.summary.pricedTrips ?? currentDataset.summary.totalTrips} {" "}{translate("analytics.ui.approved")}{currentDataset.summary.pendingSettlementTrips ? (
              <span className="text-amber-700 font-bold ms-1">• {currentDataset.summary.pendingSettlementTrips} {" "}{translate("dashboard.labels.pending_suffix")}</span>
            ) : ''}
          </div>
        </div>

        {/* Total Metric Tons */}
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
          <div className="text-[11px] font-bold text-stone-500">{translate("analytics.ui.total_transported_weight")}</div>
          <div className="text-xl font-black text-stone-900 mt-1 font-mono">
            {currentDataset.summary.totalNetWeightTons.toLocaleString()}
          </div>
          <div className="text-[10px] text-stone-400 mt-0.5">{translate("analytics.ui.metric_tons")}</div>
        </div>

      </div>

      {/* 3.1 Pending Settlement Isolation Banner */}
      {currentDataset.summary.pendingSettlementTrips > 0 && (
        <div className="bg-amber-50 border border-amber-300 rounded-2xl p-4 text-amber-950 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-start sm:items-center gap-2.5">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5 sm:mt-0" />
            <div>
              <div className="text-xs font-bold">{translate("analytics.ui.pending_settlement_isolation")}</div>
              <div className="text-[11px] text-amber-900 mt-0.5 leading-relaxed">
                {translate("analytics.ui.there_are")}{" "}<strong className="font-mono">{currentDataset.summary.pendingSettlementTrips}</strong> {" "}{translate("analytics.ui.operationally_recorded_trips_awaiting_contract_approval_for_pricing_they_are_excluded_")}</div>
            </div>
          </div>
          <div className="shrink-0 bg-amber-200/70 border border-amber-300 text-amber-950 text-xs px-3 py-1.5 rounded-xl font-bold font-mono">
            {translate("analytics.ui.approved_final_settlement")}{" "}{currentDataset.summary.finalSettlementAmount.toLocaleString()} {" "}{translate("shared.units.sar")}</div>
        </div>
      )}

      {/* 4. Active Report Title & Actions Toolbar */}
      <div className="bg-white rounded-2xl border border-stone-200 p-5 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
              <span>{presentAnalyticsText(currentDataset.titleAr, translate)}</span>
              <span className="text-xs text-stone-400 font-mono font-normal">({currentDataset.titleEn})</span>
            </h3>
            <p className="text-xs text-stone-500 mt-0.5">{presentAnalyticsText(currentDataset.descriptionAr, translate)}</p>
          </div>

          {/* Export and Print Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5">
            <button
              id="btn-export-csv"
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-bold transition-all border border-stone-200 shadow-2xs cursor-pointer"
              title={translate("analytics.ui.export_report_data_as_csv_with_utf_8_bom_support")}
            >
              <Download className="w-3.5 h-3.5 text-stone-600" />
              <span>{translate("analytics.ui.export_csv")}</span>
            </button>

            <button
              id="btn-export-xlsx"
              onClick={handleExportXLSX}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold transition-all shadow-2xs cursor-pointer"
              title={translate("analytics.ui.export_the_official_excel_report_xlsx_with_its_original_arabic_cells_and_header")}
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>{translate("analytics.ui.export_excel_xlsx")}</span>
            </button>

            <button
              id="btn-print-pdf"
              onClick={() => {if(readReady&&scope.isCurrent())setIsPrintModalOpen(true);}}
              className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-stone-950 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
              title={translate("analytics.ui.preview_and_print_the_official_document_or_save_it_as_pdf")}
            >
              <Printer className="w-4 h-4" />
              <span>{translate("analytics.ui.preview_and_print_pdf")}</span>
            </button>
          </div>
        </div>

        <p id="ui4-table-search-scope" className="text-sm text-stone-600">{translate('ui4.table_search_scope')}</p>
        {sourceReadAt&&<p className="text-xs text-stone-600">{translate('ui4.source_read_at')}: <bdi dir="ltr">{sourceReadAt}</bdi> · {translate('ui4.generated_at')}: <bdi dir="ltr">{currentDataset.generatedAt}</bdi></p>}
        {/* Quick Search Within Current Table */}
        <div className="flex items-center justify-between gap-3 border-t border-stone-100 pt-3">
          <div className="relative w-full max-w-xs">
            <Search className="w-3.5 h-3.5 absolute right-3 rtl:right-3 ltr:left-3 ltr:right-auto top-2.5 text-stone-400" />
            <input
              type="text"
              aria-label={translate("analytics.ui.search_current_report_results")}
              aria-describedby="ui4-table-search-scope"
              placeholder={translate("analytics.ui.search_current_report_results")}
              value={tableSearch}
              onChange={(e) => setTableSearch(e.target.value)}
              className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg pr-8 pl-3 rtl:pr-8 rtl:pl-3 ltr:pl-8 ltr:pr-3 py-1.5 focus:ring-1 focus:ring-amber-500 text-stone-800"
            />
          </div>

          <div className="text-xs text-stone-500 font-mono">
            {translate("operations.showing")}{" "}{filteredRows.length} {" "}{translate("operations.of_2")}{" "}{currentDataset.rows.length} {" "}{translate("analytics.ui.records")}</div>
        </div>

        {/* Table Rendering */}
        <div className="overflow-x-auto border border-stone-200 rounded-xl">
          <table className="w-full text-right rtl:text-right ltr:text-left border-collapse text-xs">
            <thead>
              <tr className="bg-stone-50 text-stone-700 font-bold border-b border-stone-200">
                <th className="p-3 text-center w-12 text-stone-500">#</th>
                {currentDataset.columns.map((c) => (
                  <th 
                    key={c.key} 
                    className={`p-3 border-l rtl:border-l ltr:border-r border-stone-200/60 ${
                      c.align === 'center' ? 'text-center' : c.align === 'left' ? 'text-left' : 'text-right rtl:text-right ltr:text-left'
                    }`}
                  >
                    {presentAnalyticsText(c.labelAr, translate)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredRows.length === 0 ? (
                <tr>
                  <td colSpan={currentDataset.columns.length + 1} className="p-8 text-center text-stone-500">
                    <AlertTriangle className="w-6 h-6 text-amber-500 mx-auto mb-2 opacity-80" />
                    <p className="font-semibold">{translate("analytics.ui.no_records_match_the_selected_filters")}</p>
                    <p className="text-[11px] text-stone-400 mt-1">{translate("analytics.ui.change_the_filter_criteria_or_select_reset_filters")}</p>
                  </td>
                </tr>
              ) : (
                filteredRows.map((row, idx) => (
                  <tr key={idx} className="hover:bg-stone-50/80 transition-colors">
                    <td className="p-3 text-center text-stone-400 font-mono text-[11px] border-l rtl:border-l ltr:border-r border-stone-100">
                      {idx + 1}
                    </td>
                    {currentDataset.columns.map((col) => {
                      const val = row[col.key];
                      return (
                        <td 
                          key={col.key} 
                          className={`p-3 border-l rtl:border-l ltr:border-r border-stone-100 ${
                            col.align === 'center' ? 'text-center' : col.align === 'left' ? 'text-left font-mono font-semibold' : 'text-right rtl:text-right ltr:text-left'
                          }`}
                        >
                          {col.format === 'currency' && typeof val === 'number' ? (
                            <span className="text-stone-900 font-bold">
                              {val.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </span>
                          ) : col.format === 'number' && typeof val === 'number' ? (
                            <span className="font-semibold text-stone-800">
                              {val.toLocaleString()}
                            </span>
                          ) : col.format === 'badge' ? (
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              String(val).includes('مطابق') ? 'bg-emerald-100 text-emerald-800' :
                              String(val).includes('عجز') || String(val).includes('CRITICAL') || String(val).includes('BLOCKING') ? 'bg-rose-100 text-rose-800' :
                              'bg-amber-100 text-amber-800'
                            }`}>
                              {presentReportCell(col.key, val, translate)}
                            </span>
                          ) : col.format === 'percent' ? (
                            <span className="font-bold text-emerald-800">
                              {val}%
                            </span>
                          ) : (
                            <span className="text-stone-800">
                              {val !== undefined && val !== null ? presentReportCell(col.key, val, translate) : '-'}
                            </span>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Footer Notes */}
        {currentDataset.notes && (
          <div className="flex items-center gap-2 text-xs text-stone-500 bg-stone-50 p-3 rounded-xl border border-stone-200">
            <Info className="w-4 h-4 text-stone-400 shrink-0" />
            <span>{presentAnalyticsText(currentDataset.notes, translate)}</span>
          </div>
        )}
      </div>
    </>
  )}

      {/* 5. Printable PDF Modal */}
      {isPrintModalOpen && readReady && (
        <PrintableReportModal
          dataset={currentDataset}
          sourceReadAt={sourceReadAt||undefined}
          onClose={() => setIsPrintModalOpen(false)}
        />
      )}

    </div>
  );
};
