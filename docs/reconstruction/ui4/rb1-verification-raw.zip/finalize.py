from pathlib import Path
import json,hashlib,subprocess,zipfile,os,shutil,re
r=Path.cwd();o=r.parent/'ui4-rb1-evidence-20261115';d=r/'docs/reconstruction/ui4'
read=lambda p:json.loads(p.read_text(encoding='utf8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
pre=read(o/'preflight.json');commands=read(o/'command-exits.json');final=read(o/'final-command-exits.json');connected=read(o/'connected-r2/ui3-connected-connected-browser-exit.json')
assert all(x['status']==0 for x in final)
assert next(x for x in commands if x['name']=='build')['status']==0
assert next(x for x in commands if x['name']=='browser')['status']==0
assert connected['status']==0 and not connected['cleanupErrors'] and not connected['remainingListeners']
counts=lambda name:{k:read(o/name)[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']}
comparison=read(o/'failure-comparison.json');assert comparison['baselineCandidateIdentical'] and comparison['all14InheritedIdentitiesRetained']
subprocess.run(['python',str(o/'preservation-audit.py')],check=True)
preservation=read(o/'preservation.json');route=read(o/'route-probe/xlsx-multiline-probe.json');assert route['equivalent'] and route['xlsxDataRows']==2
beforeAudit=o/'independent-original-audit';beforeAudit.mkdir(exist_ok=True)
for n in ['xlsx-multiline-probe.json','xlsx-multiline-probe.log','xlsx-multiline-probe.mts','multiline-route.csv','multiline-route.xlsx']:
 shutil.copy2(r.parent/'ui4-final-source-audit-20261115'/n,beforeAudit/n)
# The immutable previous snapshots and initial failures remain evidence, not current acceptance.
archive=d/'rb1-verification-raw.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for folder,dirs,files in os.walk(o):
  dirs[:]=[x for x in dirs if x!='runner']
  for name in sorted(files):
   p=Path(folder)/name
   if p.suffix.lower() in ['.json','.log','.txt','.mjs','.mts','.py','.ts','.tsx','.md','.patch','.xlsx','.csv','.zip','.png','.pdf']:
    z.write(p,p.relative_to(o).as_posix())
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
recovery={
 'ROOT_CAUSE_VERIFIED':{'status':'PASS','source':'src/services/reportsEngine.service.ts','cause':'Quoted CSV cells containing CRLF were split as physical CSV lines, corrupting logical XLSX records. XLSX now consumes the same bounded structured export table as CSV, without reparsing CSV. Header CSV quoting is corrected too.'},
 'EXACT_CHANGED_FILES_BEFORE_AND_AFTER':{'beforeTotal':45,'beforeFiles':sorted(pre['files']),'afterTotal':49,'afterFiles':[], 'counts':{'production':9,'testsAndFixtures':8,'documentationAndEvidence':32},'addedToChangedFileScope':['src/services/reportsEngine.service.ts','src/tests/ui4ExportIntegrity.test.ts','docs/reconstruction/ui4/rb1-recovery.json','docs/reconstruction/ui4/rb1-verification-raw.zip'],'original45BytesPreservedAt':'rb1-verification-raw.zip::before/','inventory':'exact-file-inventory.json'},
 'RED_TO_GREEN_REGRESSION_EVIDENCE':{'red':counts('red-final.json'),'green':counts('green-final.json'),'redNativeExit':1,'greenNativeExit':0,'redFailureIdentities':[a['fullName'] for t in read(o/'red-final.json')['testResults'] for a in t['assertionResults'] if a['status']=='failed'],'strictFinalRerunIncludedIn':'affected-final.json','intermediatesRetained':['red.log','red-native.log','red-confirmed.log','green.log'],'explanation':'Initial CSV readback harness was corrected for BOM handling and SheetJS CSV CRLF normalization. Identical strict parser tests then ran red on unchanged HEAD exporter and green on corrected exporter. Final fixture typing was completed without weakening assertions.'},
 'CSV_XLSX_LOGICAL_PARITY':{'status':'PASS','values':'Exact character equality using an independent CSV state-machine reader and physical SheetJS XLSX readFile. SheetJS 0.18 CSV reader normalizes embedded CRLF, so it cannot prove verbatim parity.','routeProbe':route},
 'PHYSICAL_WORKBOOK_ROUNDTRIP':{'status':'PASS','unitArtifacts':'final-workbooks/ in raw archive; real XLSX files are written to disk, checked for ZIP signature, then readFile by SheetJS; only browser download boundary is captured.','connectedArtifact':'ui4-evidence-20261115/connected/multiline-route.xlsx in raw archive; actual authenticated Edge download'},
 'MULTILINE_RECORD_INTEGRITY':{'status':'PASS','originalProbe':{'records':2,'xlsxDataRows':4},'correctedProbe':{'records':2,'xlsxDataRows':2},'preserved':['CRLF','LF','CR','commas','quotes','escaped double quotes','Arabic Unicode','empty cells','column and traceability order'],'formulas':'Formula-like text remains string cells; no XLSX formula fields. Metadata rows excluded from record counts. No sanitization or rejection of valid multiline text.'},
 'UI4_REGRESSION_RESULTS':{'baseline':counts('baseline.json'),'candidate':counts('candidate.json'),'affectedFinal':counts('affected-final.json'),'nativeEdge':counts('browser.json'),'connectedEnhancedFinal':counts('connected-r2/candidate-connected.json'),'aggregateDisposition':'NOT_PASS: 14 inherited broad-suite failures retained','historicalEvidenceReused':'Original connected 16/17 and corrected 1/1 remain unchanged historical evidence, including original 1002-trip UI3 journeys. Original PDF visual QA reused because print/UI components are unchanged; newly executed Edge matrix independently rechecks actual export and print coverage.','newConnectedTimeout':'First enhanced connected run timed out at unchanged 90s, exit 1, cleanup clean. Retained. Staged follow-up uses stricter 10s action deadlines; no test skips or deadline relaxation.'},
 'BASELINE_CANDIDATE_FAILURE_IDENTITIES':comparison,
 'TYPECHECK_LINT_BUILD':{'typecheckAndLint':'PASS: npm run lint runs tsc --noEmit; final exit 0','build':'PASS: client/PWA/server production build exit 0; existing chunk-size warning retained','initialLint':'Exit 2 from missing required fields in newly added test fixture; corrected. Original output retained.','commands':commands+final},
 'DOCUMENTATION_RECONCILIATION':{'status':'PASS','priorManifestScope':'All pre-RB1 verification fields and source-contract.json refer to preserved historical source bytes. rb1-recovery.json and revised exact inventory carry current state.','files':['docs/reconstruction/UI4_OPERATIONAL_REPORTS.md','docs/reconstruction/02_PHASE_LEDGER.md','docs/reconstruction/05_DECISION_AND_DEBT_LOG.md','docs/reconstruction/ui4/README.md','docs/reconstruction/ui4/verification.json','docs/reconstruction/ui4/exact-file-inventory.json','docs/reconstruction/ui4/evidence-sha256.json']},
 'PROTECTED_WORKTREES_AND_MIGRATION_STATUS':preservation,
 'FINAL_PUBLICATION_READINESS_DECISION':{'decision':'GO_TO_OWNER_SOURCE_REVIEW_ONLY; PUBLICATION_HOLD','xlsxBlocker':'RESOLVED_AND_VERIFIED','broadSuite':'NOT_PASS_WITH_IDENTICAL_14_INHERITED_FAILURES','ownerGate':'STOP at owner review. No commit, staging, push, PR, merge, deployment, RB4 activation or SQL cutover performed.','readback':read(o/'publication-readback.json')},
 'artifactSha256':sha(archive)
}
write(d/'rb1-recovery.json',recovery)
text="""
## UI4-RB1 export row integrity recovery — 2026-11-15

This corrective record supersedes pre-recovery XLSX-integrity acceptance. The unchanged exporter reproduced the confirmed defect: two logical records with quoted CRLF text became four XLSX data rows. CSV and XLSX now share one bounded private export-table builder in the existing reports engine. CSV quotes and escapes headers and cells with UTF-8 BOM; XLSX uses structured columns/rows directly. Existing fallback values, audit ordering, string export values, metadata preamble, worksheet RTL settings, widths and filenames remain. Valid CRLF/LF/CR text is preserved verbatim. No report generation, validators, pricing, permission, source data, persistence, Workspace or dependency contract changes. Earlier statements that report services were unchanged describe the original UI4 phase; this bounded export correction is the sole new service exception.

[RB1 gate evidence](ui4/rb1-recovery.json) records red **10/12** (two failures), green **12/12**, final affected export/presentation/security/localization **168/168**, and the physical workbook cell readback. The exact independent route fixture now exports **2 records → 2 XLSX data rows** with CSV parity. CSV parity uses an independent character-preserving parser because SheetJS 0.18 normalizes CRLF in CSV input; physical XLSX is independently read using SheetJS. Formula-like values remain string cells without formula fields.

New matched baseline **310/324**, candidate **394/408**, exits **1/1**; the same 14 inherited failure identities remain, zero additions and zero skips. Broad aggregate remains **NOT PASS**. Newly executed native Edge **9/9** across AR/EN/UR and three sizes; enhanced authenticated emulator export journey **1/1**, with a real downloaded multiline XLSX workbook. Its first enhanced run timed out at the original 90-second limit and remains retained; diagnostic stage/action limits were added without increasing that limit or removing assertions. Final cleanup has zero errors and no listeners. Initial test-fixture type errors are preserved and corrected; final `npm run lint` / `tsc --noEmit` and production client/PWA/server build exit **0**. Existing chunk-size warning remains.

The original connected **16/17** failure and corrected **1/1** evidence remain historical, separately labeled; no synthetic 17/17 claim. Original PDF visual QA is reused for unchanged print components; the new Edge run rechecks export/print row and column coverage. No new visual, live Google, physical-device or assistive-technology acceptance is claimed. Prior manifest fields and original source-contract are historical snapshots, with exact original bytes retained in the [RB1 raw archive](ui4/rb1-verification-raw.zip).

Scope is now **49 files: 9 production, 8 tests/fixtures, 32 documentation/evidence**, previously 45. All original 45 files and bytes are backed up; the connected test gains additive XLSX assertions and valid multiline fixture text. The [revised inventory](ui4/exact-file-inventory.json) lists every before/after path. Twenty-one other worktrees remain protected; original RB4 nine raw hashes and unpublished/untracked migration 013 are unchanged. HEAD/branch unchanged and index empty. GitHub read-only lookup finds no published UI4 branch or PR. **GO to owner source review only; publication HOLD. STOP at owner review.**
"""
p=r/'docs/reconstruction/UI4_OPERATIONAL_REPORTS.md';p.write_text(p.read_text(encoding='utf8')+text,encoding='utf8')
p=r/'docs/reconstruction/02_PHASE_LEDGER.md';p.write_text("""## CURRENT UI4-RB1 CORRECTIVE OWNER-REVIEW GATE — 2026-11-15

XLSX multiline row blocker resolved and verified; scope 49 files (9 production / 8 tests-fixtures / 32 docs-evidence). Red 10/12 → green 12/12; affected 168/168, Edge 9/9, enhanced connected 1/1. Matched broad baseline 310/324 and candidate 394/408 retain identical 14 failures: NOT PASS. Typecheck/lint/build exit 0. Original connected 16/17 and corrected 1/1 remain historical. [Current RB1 record](ui4/rb1-recovery.json). Stop at owner review; publication HOLD, no commit/push/PR/merge/deploy/RB4/SQL action. Earlier UI4 source evidence below remains historical.

"""+p.read_text(encoding='utf8'),encoding='utf8')
p=r/'docs/reconstruction/05_DECISION_AND_DEBT_LOG.md';p.write_text("""## UI4-RB1 — Confirmed XLSX row-integrity blocker corrected — 2026-11-15

CSV physical-line splitting corrupted quoted CRLF cells. The existing reports service now owns one structured export table consumed directly by CSV and XLSX. All values and fallbacks remain; header quoting is corrected. Red/green, real workbook cells and authenticated multiline download are verified in [RB1 evidence](ui4/rb1-recovery.json). Original 14 broad-suite failure identities, original connected 16/17 and corrected 1/1, initial enhanced-journey timeout and fixture type errors are retained. No blanket PASS or environmental explanation for the timeout is asserted. Operational language, live provider, devices and assistive-technology acceptance remain open. Scope 49; original RB4/migration 013 untouched; owner source review only, publication HOLD.

"""+p.read_text(encoding='utf8'),encoding='utf8')
p=d/'README.md';p.write_text("""# Current UI4-RB1 correction evidence

[RB1 final gates](rb1-recovery.json), [current exact inventory](exact-file-inventory.json), [RB1 raw evidence and before-byte backups](rb1-verification-raw.zip). Scope 49; export blocker verified resolved; owner source review only, publication HOLD. The pre-RB1 evidence below and source-contract.json are preserved historical snapshots. The original raw archive remains byte-identical.

"""+p.read_text(encoding='utf8'),encoding='utf8')
p=d/'verification.json';v=read(p);v['preRecoveryEvidenceScope']='All original fields are preserved historical pre-RB1 evidence, not the corrected service source identity. Current correction gates and source hashes are in rb1-recovery.json.';v['UI4_RB1_CURRENT']={'record':'rb1-recovery.json','raw':'rb1-verification-raw.zip','scopeTotal':49,'decision':'GO_TO_OWNER_SOURCE_REVIEW_ONLY; PUBLICATION_HOLD'};write(p,v)
git=lambda *a:subprocess.check_output(['git',*a],text=True,encoding='utf8').strip()
files=sorted(set(git('diff','--name-only','HEAD').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()));assert len(files)==49,(len(files),files)
recovery['EXACT_CHANGED_FILES_BEFORE_AND_AFTER']['afterFiles']=files;write(d/'rb1-recovery.json',recovery)
classify=lambda f:'TEST_OR_FIXTURE' if f.startswith('src/tests/') else 'PRODUCTION' if f.startswith('src/') else 'DOCUMENTATION_OR_EVIDENCE'
write(d/'exact-file-inventory.json',{'head':pre['head'],'branch':pre['branch'],'counts':recovery['EXACT_CHANGED_FILES_BEFORE_AND_AFTER']['counts']|{'total':49},'beforeCount':45,'beforeInventory':'rb1-recovery.json::EXACT_CHANGED_FILES_BEFORE_AND_AFTER.beforeFiles','files':[{'file':f,'classification':classify(f),'sha256':sha(r/f) if f.startswith('src/') else None} for f in files]})
# Scan current changed text and every new archive text entry without printing possible secret data.
patterns={'PRIVATE_KEY':rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----','GITHUB_TOKEN':rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})','OPENAI_KEY':rb'sk-(?:proj-)?[A-Za-z0-9_-]{32,}','GOOGLE_ACCESS':rb'ya29\.[A-Za-z0-9_-]{20,}','GOOGLE_CLIENT_SECRET':rb'GOCSPX-[A-Za-z0-9_-]{20,}','AWS_ACCESS':rb'AKIA[0-9A-Z]{16}','SLACK_TOKEN':rb'xox[baprs]-[A-Za-z0-9-]{20,}','JWT':rb'eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}','GOOGLE_API_KEY':rb'AIza[A-Za-z0-9_-]{35}'}
findings=[];scanned=0
scan=lambda name,data:[{'file':name,'rule':key} for key,pat in patterns.items() if re.search(pat,data)]
for f in files:
 if Path(f).suffix not in ['.zip','.png']:findings+=scan(f,(r/f).read_bytes());scanned+=1
with zipfile.ZipFile(archive) as z:
 for n in z.namelist():
  if Path(n).suffix in ['.json','.log','.txt','.mjs','.mts','.py','.ts','.tsx','.md','.patch','.csv']:findings+=scan('rb1-raw::'+n,z.read(n));scanned+=1
assert not findings,findings
write(d/'secret-scan.json',{'status':'PASS','scope':'Current 49 changed files and decompressed RB1 text evidence; original historical raw archive unchanged and original scan retained in before snapshot.','scannedTextFilesAndEntries':scanned,'findings':[],'fixtureClassification':'Emulator-only synthetic credentials and example.invalid identities are intentional fixtures.'})
# Validate new/current UI4 links; retained historical debt sections are outside correction scope.
import urllib.parse
links=[]
for p in [r/'docs/reconstruction/UI4_OPERATIONAL_REPORTS.md',d/'README.md',r/'docs/reconstruction/02_PHASE_LEDGER.md',r/'docs/reconstruction/05_DECISION_AND_DEBT_LOG.md']:
 text=p.read_text(encoding='utf8')
 if p.name in ['02_PHASE_LEDGER.md','05_DECISION_AND_DEBT_LOG.md']:
  text=text.split('\n## ',1)[0]
 for url in re.findall(r'\[[^\]]+\]\(([^)]+)\)',text):
  if url.startswith(('https://','http://','mailto:','#')):continue
  target=urllib.parse.unquote(url.split('#')[0].strip('<>'));exists=(p.parent/target).exists();links.append({'source':p.relative_to(r).as_posix(),'target':url,'exists':exists})
assert all(x['exists'] for x in links),links
write(d/'doc-links.json',{'status':'PASS','scope':'Current UI4 implementation/evidence and new RB1 ledger/debt entries; historical sections retained.','checked':links})
res=subprocess.run(['git','diff','--check'],capture_output=True,text=True);assert res.returncode==0,res.stdout+res.stderr
assert not git('diff','--cached','--name-only')
write(d/'evidence-sha256.json',{'algorithm':'SHA256','scope':'Current UI4-RB1 49-file inventory; original hashes retained in RB1 before snapshot. Self excluded.','diffCheckNativeExit':0,'stagedFiles':0,'files':{f:sha(r/f) for f in files if f!='docs/reconstruction/ui4/evidence-sha256.json'}})
print('RB1_FINALIZED: 49 files; evidence sealed; diff check and secret scan PASS')
