from pathlib import Path
import json,hashlib,subprocess,zipfile,ast,re,io
r=Path.cwd();o=r.parent/'ui4-ci1-evidence-20261115';d=r/'docs/reconstruction/ui4'
read=lambda p:json.loads(p.read_text(encoding='utf8'))
write=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def g(folder,*a):return subprocess.check_output(['git','-c','safe.directory='+str(folder),'-C',str(folder),*a],encoding='utf8').rstrip()
pre=read(o/'preflight.json');ci1=read(d/'ci1-recovery.json');allowed=ci1['UPDATED_FILE_INVENTORY']['ci1DeltaFiles'];archive=d/'ci1-verification-raw.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(o.iterdir()):
  if p.is_file() and p.suffix in ['.json','.log','.txt','.mjs','.py','.zip']:z.write(p,p.name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
ci1['archiveSha256']=sha(archive);write(d/'ci1-recovery.json',ci1)
s=(o/'finalize.py').read_text(encoding='utf8');exec(compile(s[s.index("base='800434"):],str(o/'finalize.py')+'::resume','exec'))
