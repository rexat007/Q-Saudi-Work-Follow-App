from pathlib import Path
import json,hashlib,subprocess,zipfile,ast,re,io
r=Path.cwd();o=r.parent/'ui4-ci1-evidence-20261115';d=r/'docs/reconstruction/ui4'
read=lambda p:json.loads(p.read_text(encoding='utf8'))
write=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pre=read(o/'preflight.json')
# This script is executed only after all local gates pass.
commands=read(o/'command-exits.json');assert len(commands)==4 and all(x['status']==0 for x in commands)
assert 'Tests  16 passed (16)' in (o/'runtime-green.log').read_text(encoding='utf8')
assert 'Tests  5 failed | 11 passed (16)' in (o/'runtime-red.log').read_text(encoding='utf8')
focused=read(o/'ui4-focused.json');assert focused['numPassedTests']==focused['numTotalTests']==87 and focused['numFailedTests']==focused['numPendingTests']==0
assert sha(r/'src/tests/runtimeKeyAudit.test.ts')==pre['runtimeAuditSha256']
assert sha(r/'src/services/reportsEngine.service.ts')==pre['sharedXlsxServiceSha256']
def g(folder,*a):return subprocess.check_output(['git','-c','safe.directory='+str(folder),'-C',str(folder),*a],encoding='utf8').rstrip()
for s in pre['protected']:
 f=s['folder'];assert g(f,'rev-parse','HEAD')==s['head'] and g(f,'status','--porcelain=v1')==s['status'],f
 assert all(sha(Path(f)/n)==h for n,h in s['hashes'].items()),f
assert g(r,'rev-parse','HEAD')==pre['head'] and not g(r,'diff','--cached','--name-only')
assert [f for f,h in pre['files'].items() if sha(r/f)!=h]==['src/components/reports/operationalReportPresentation.ts']
# Collect the actual existing dictionary labels without changing any catalog.
labels={};keys=['ui4.sourceType','ui4.pricingSnapshotAt','ui4.destinationWeightSource','ui4.settlementStatus']
for locale in ['ar','en','ur']:
 text=(r/f'src/locales/{locale}/index.ts').read_text(encoding='utf8');labels[locale]={}
 for k in keys:
  match=re.search(r'"'+re.escape(k)+r'"\s*:\s*("(?:[^"\\]|\\.)*")',text);assert match,k
  labels[locale][k]=json.loads(match[1]);assert labels[locale][k] and labels[locale][k]!=k
 assert not re.search(r'[\'"]ui4\.[\'"]\s*:',text)
write(o/'resolved-labels.json',labels)
write(o/'preservation.json',{'status':'PASS','protectedWorktrees':21,'allOriginalSourceAndTestsUnchangedExcept':'src/components/reports/operationalReportPresentation.ts','runtimeAuditSha256':pre['runtimeAuditSha256'],'sharedXlsxServiceSha256':pre['sharedXlsxServiceSha256'],'dictionaryFilesUnchanged':True,'rb4OriginalNineAndMigration013Unchanged':True,'allOriginal49BytesBackedUp':'before-49.zip','originalArchivesAndNonGreenIdentityFilesUnchanged':True})
allowed=['src/components/reports/operationalReportPresentation.ts','src/tests/ui4Ci1ExportLabels.test.ts','docs/reconstruction/UI4_OPERATIONAL_REPORTS.md','docs/reconstruction/02_PHASE_LEDGER.md','docs/reconstruction/ui4/README.md','docs/reconstruction/ui4/verification.json','docs/reconstruction/ui4/exact-file-inventory.json','docs/reconstruction/ui4/evidence-sha256.json','docs/reconstruction/ui4/ci1-recovery.json','docs/reconstruction/ui4/ci1-verification-raw.zip']
summary='''## UI4-CI1 required foundation recovery — 2026-11-15

Pinned published candidate `85c648022e3669be025faa68ac4eeae35f243dd6` failed [workflow 43715381498](https://github.com/rexat007/Q-Saudi-Work-Follow-App/actions/runs/43715381498), Required foundation / Verify runtime translation keys. The unchanged `npm run test:i18n-runtime` reproduced **11/16**, with five failures caused by the statically extracted incomplete key `ui4.` from `t('ui4.' + key)` in completeReportExportColumns. The original GitHub job log and local red output are preserved in the CI1 raw archive.

The sole production change replaces that prefix concatenation with an explicit `as const` mapping of the four existing full audit-label keys, a derived ExportAuditKey union and a correspondingly typed alias record. The iteration preserves original audit ordering; row cloning, aliases, null fallback, empty/zero/false values and financial summaries are unchanged. No dictionary, runtime audit, shared XLSX exporter, historical test or other accepted UI4 behavior changes. A new independent test resolves all four real translated strings in AR/EN/UR and verifies ordering, aliases, fallback values and source immutability.

New local verification: unchanged runtime command **16/16 PASS**; focused UI4 presentation/scope/export/CI1 tests **87/87 PASS** (including unchanged XLSX integrity **12/12**); lint/TypeScript and client/PWA/server production build **exit 0**. Existing chunk-size warning retained. Historical broad baseline 310/324 and candidate 394/408 remain **NOT PASS**, with the same 14 historical identities; those broad suites are reused historical evidence, not newly rerun or relabeled. Earlier browser 9/9 and authenticated emulator 1/1 also remain explicitly historical; no new connected/browser acceptance is claimed for this four-label correction.

Current candidate scope is **52 files: 9 production, 9 tests/fixtures, 34 documentation/evidence**. CI1 adds three paths to the original 49-file scope: its independent test, recovery JSON and raw evidence ZIP. Its additive commit changes exactly ten paths (one existing production file, one new test and eight necessary current documentation/evidence paths). [CI1 verification](ui4/ci1-recovery.json), [current exact inventory](ui4/exact-file-inventory.json), and [preserved CI1 red/green evidence](ui4/ci1-verification-raw.zip) are authoritative for this local source snapshot. All original 49 bytes are backed up; original raw archives, failed/interrupted attempts and all historical non-green results remain intact.

Twenty-one protected worktrees, the original nine RB4 dirty files and unpublished migration 013 are unchanged. No dependency, validator, pricing, permission, canonical persistence, Workspace, SQL or activation contract changes. **Pre-publication decision: local gates PASS; GitHub CI PENDING on the not-yet-published corrective head. HOLD until required CI succeeds on that exact head; local tests are not CI success.** Publish only one additive commit by normal fast-forward push to existing Draft PR #105, then observe its new workflow. No new PR, amend, force push, merge, deployment, SQL cutover, RB4 activation or UI5. Stop at owner review.
'''
p=r/'docs/reconstruction/UI4_OPERATIONAL_REPORTS.md';p.write_text(p.read_text(encoding='utf8')+'\n'+summary,encoding='utf8')
p=r/'docs/reconstruction/02_PHASE_LEDGER.md';p.write_text('## CURRENT UI4-CI1 FOUNDATION RECOVERY — 2026-11-15\n\nPR #105 failing head `85c648022e3669be025faa68ac4eeae35f243dd6`: runtime audit 11/16 → 16/16 after one explicit typed four-key label mapping. Focused UI4 87/87; lint/TypeScript/build exit 0. Scope 52 files (9 production / 9 tests-fixtures / 34 docs-evidence), CI1 delta ten paths. Original audit, dictionaries, XLSX correction and historical failures unchanged; 21 protected worktrees and RB4/013 preserved. [Current CI1 local evidence](ui4/ci1-recovery.json). Remote required CI is PENDING for the upcoming corrective commit; HOLD until success is observed on its exact PR head. Publication authorization is one additive commit and normal push to existing Draft PR #105 only; stop at owner review, no merge or activation. Earlier UI4/RB1 gates below are historical snapshots.\n\n'+p.read_text(encoding='utf8'),encoding='utf8')
p=d/'README.md';p.write_text('# Current UI4-CI1 foundation recovery\n\n[CI1 local gates and original CI failure](ci1-recovery.json), [current 52-file inventory](exact-file-inventory.json), [CI1 raw red/green evidence and original 49-file backup](ci1-verification-raw.zip). Runtime 16/16, focused UI4 87/87, lint/build exit 0. Required remote CI remains PENDING in this pre-publication snapshot: HOLD until observed success on the exact new PR head. Original evidence below is retained historical state; source hashes in original RB1 records refer to pre-CI1 bytes. No historical failure is relabeled PASS.\n\n'+p.read_text(encoding='utf8'),encoding='utf8')
v=read(d/'verification.json');v['UI4_CI1_CURRENT']={'record':'ci1-recovery.json','raw':'ci1-verification-raw.zip','pinnedFailingHead':pre['head'],'failingRunId':43715381498,'scopeTotal':52,'localRuntimeAudit':'16/16 PASS','localFocused':'87/87 PASS','typecheckLintBuild':'PASS','remoteRequiredCI':'PENDING: only exact new PR-head workflow success can clear the CI hold','historicalEvidenceBoundary':'Original fields and RB1 records retain their pre-CI1 source/status snapshots. They are preserved, not a CI success claim.'};write(d/'verification.json',v)
# Verify current document links before sealing the new raw evidence.
links=[]
for p in [r/'docs/reconstruction/UI4_OPERATIONAL_REPORTS.md',r/'docs/reconstruction/02_PHASE_LEDGER.md',d/'README.md']:
 text=p.read_text(encoding='utf8')
 if p.name=='02_PHASE_LEDGER.md':text=text.split('\n## ',1)[0]
 for url in re.findall(r'\[[^\]]+\]\(([^)]+)\)',text):
  if url.startswith(('http://','https://','mailto:','#')):continue
  assert (p.parent/url.split('#')[0]).exists() or url.endswith(('ci1-recovery.json','ci1-verification-raw.zip')),url
  links.append({'source':p.relative_to(r).as_posix(),'target':url})
write(o/'doc-links.json',{'status':'PASS','checked':links})
archive=d/'ci1-verification-raw.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(o.iterdir()):
  if p.is_file() and p.suffix in ['.json','.log','.txt','.mjs','.py','.zip']:z.write(p,p.name)
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
ci1={'UI4_CI1_ROOT_CAUSE':{'source':'src/components/reports/operationalReportPresentation.ts','cause':'Static runtime audit extracts the incomplete quoted prefix ui4. from t(\'ui4.\' + key); not missing full dictionary keys.','originalGitHubRunId':43715381498,'originalHead':pre['head'],'originalConclusion':'failure','originalFoundationJobId':132815670568},'EXACT_SOURCE_CHANGE':{'file':'src/components/reports/operationalReportPresentation.ts','solution':'Explicit literal four-key mapping, derived ExportAuditKey union and typed aliases; stable iteration and unchanged row/fallback logic.','sourceSha256':sha(r/'src/components/reports/operationalReportPresentation.ts'),'actualResolvedLabels':labels},'RED_TO_GREEN_RUNTIME_AUDIT':{'unchangedCommand':'npm run test:i18n-runtime','red':{'passed':11,'failed':5,'total':16,'exit':1},'green':{'passed':16,'failed':0,'total':16,'exit':0},'auditFileUnchanged':True,'incompleteDictionaryKeyAdded':False},'UI4_AFFECTED_REGRESSIONS':{k:focused[k] for k in ['numTotalTests','numPassedTests','numFailedTests','numPendingTests']} ,'TYPECHECK_LINT_BUILD':{'commands':commands,'status':'PASS'},'UPDATED_FILE_INVENTORY':{'previousTotal':49,'total':52,'counts':{'production':9,'testsAndFixtures':9,'documentationAndEvidence':34},'ci1DeltaFiles':sorted(allowed),'ci1DeltaCount':10,'newCandidatePaths':['src/tests/ui4Ci1ExportLabels.test.ts','docs/reconstruction/ui4/ci1-recovery.json','docs/reconstruction/ui4/ci1-verification-raw.zip']},'EVIDENCE_PRESERVATION':read(o/'preservation.json'),'historicalNonGreen':{'broadBaseline':'310/324','broadCandidate':'394/408','same14Identities':True,'disposition':'NOT_PASS','notRerunForCI1':True,'originalConnected':'16/17 then separate corrected 1/1; preserved','newerConnected':'first enhanced timeout then final 1/1; preserved','sourceFiles':{f:h for f,h in pre['files'].items() if f.startswith('src/')}},'remotePublication':{'target':'existing Draft PR #105','newCommit':'PENDING at this local snapshot','newRemoteHead':'PENDING','newWorkflow':'PENDING; original failing run cannot establish corrected CI success'},'FINAL_MERGE_GATE':'HOLD pending successful required CI on exact new PR head, then owner independent review; no merge authorization','archiveSha256':sha(archive),'secretScan':{'status':'PENDING'}}
write(d/'ci1-recovery.json',ci1)
base='800434f634fb7ea5099fc12e4ec064dfb05d6df2';files=sorted(set(g(r,'diff','--name-only',base).splitlines()+g(r,'ls-files','--others','--exclude-standard').splitlines()));assert len(files)==52
actualDelta=sorted(set(g(r,'diff','--name-only','HEAD').splitlines()+g(r,'ls-files','--others','--exclude-standard').splitlines()));assert actualDelta==sorted(set(allowed)-{'docs/reconstruction/ui4/exact-file-inventory.json','docs/reconstruction/ui4/evidence-sha256.json'}),(actualDelta,allowed)
classify=lambda f:'TEST_OR_FIXTURE' if f.startswith('src/tests/') else 'PRODUCTION' if f.startswith('src/') else 'DOCUMENTATION_OR_EVIDENCE'
write(d/'exact-file-inventory.json',{'head':base,'branch':pre['branch'],'ci1PinnedFailingHead':pre['head'],'counts':ci1['UPDATED_FILE_INVENTORY']['counts']|{'total':52},'beforeCount':49,'ci1DeltaFiles':sorted(allowed),'files':[{'file':f,'classification':classify(f),'sha256':sha(r/f) if f.startswith('src/') else None} for f in files]})
# Scan all candidate text and recursively expanded archives; preserve diagnostics without printing payloads.
tree=ast.parse((r.parent/'ui4-rb1-evidence-20261115/finalize.py').read_text(encoding='utf8'));patterns=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='patterns' for t in n.targets))
findings=[];scanned=0
def scan(name,data,depth=0):
 global scanned
 suffix=Path(name).suffix.lower()
 if suffix in ['.zip','.xlsx']:
  assert depth<7
  with zipfile.ZipFile(io.BytesIO(data)) as z:
   assert z.testzip() is None
   for n in z.namelist():
    if not n.endswith('/'):scan(name+'::'+n,z.read(n),depth+1)
 elif suffix not in ['.png','.pdf']:
  scanned+=1
  for rule,pat in patterns.items():
   if re.search(pat,data):findings.append({'file':name,'rule':rule})
for f in files:scan(f,(r/f).read_bytes())
assert not findings,findings
ci1['secretScan']={'status':'PASS','textEntriesScanned':scanned,'findings':[]};ci1['docLinks']=read(o/'doc-links.json');write(d/'ci1-recovery.json',ci1)
assert all(sha(r/f)==h for f,h in pre['files'].items() if f not in allowed)
res=subprocess.run(['git','diff','--check'],capture_output=True,text=True);assert res.returncode==0,res.stdout+res.stderr
write(d/'evidence-sha256.json',{'algorithm':'SHA256','scope':'Current 52-file UI4 + RB1 + CI1 candidate; original 49-file seal retained in ci1 raw before-49.zip. Self excluded.','diffCheckNativeExit':0,'stagedFiles':0,'files':{f:sha(r/f) for f in files if f!='docs/reconstruction/ui4/evidence-sha256.json'}})
actualDelta=sorted(set(g(r,'diff','--name-only','HEAD').splitlines()+g(r,'ls-files','--others','--exclude-standard').splitlines()));assert actualDelta==sorted(allowed)
write(o/'final-local.json',{'status':'LOCAL_GATES_PASS_REMOTE_CI_PENDING','ci1DeltaFiles':actualDelta,'candidateFiles':files,'candidateCount':52,'deltaCount':10,'protectedWorktrees':21,'archiveSha256':sha(archive),'runtimeAuditUnchanged':True,'sharedXlsxUnchanged':True})
(o/'ci1-files.nul').write_bytes(b'\0'.join(f.encode() for f in actualDelta)+b'\0')
print('CI1_LOCAL_SEALED: runtime 16/16; focused 87/87; lint/build PASS; candidate52 / delta10; old evidence unchanged; required remote CI PENDING.')
